"""Central configuration values for the game."""

from typing import Final, NamedTuple


SCREEN_WIDTH: Final[int] = 1280
SCREEN_HEIGHT: Final[int] = 720
TARGET_FPS: Final[int] = 60
WINDOW_TITLE: Final[str] = "Snake Squad - 2D Prototype"
# Pixel sprite scale; assets/sprites stores frames at their original Unity sizes.
SPRITE_SCALE: Final[int] = 2
# Weapon-switch key, shared by the HUD label and game.py input handling.
WEAPON_SWITCH_KEY_LABEL: Final[str] = "F"
# Hand anchor below the eyes in the right-facing idle frame, in raw pixels; scale at runtime.
PLAYER_HAND_OFFSET: Final[tuple[float, float]] = (15.5, 11.5)

# Reduce all map dimensions by 20% using MAP_SCALE.
MAP_SCALE: Final[float] = 0.8
# Expand the arena horizontally and vertically; the world and walls follow its bounds.
ARENA_WIDTH: Final[int] = round(1696 * 1.2)    # 2035 after a 20% horizontal increase.
ARENA_HEIGHT: Final[int] = round(1536 * 1.05)  # 1613
WORLD_WIDTH: Final[int] = 800 + 32 + ARENA_WIDTH + 32   # 2899
WORLD_HEIGHT: Final[int] = 32 + ARENA_HEIGHT + 32       # 1677
GRID_SIZE: Final[int] = 80
BOUNDARY_WIDTH: Final[int] = 6

PLAYER_START: Final[tuple[float, float]] = (288.0, 800.0)
# Dungeon layout for all three levels: rest area -> corridor -> combat arena.
DUNGEON_REST_RIGHT: Final[float] = 608.0      # Right wall of the rest area.
DUNGEON_CORRIDOR_TOP: Final[float] = 704.0    # Upper edge of the corridor.
DUNGEON_CORRIDOR_BOTTOM: Final[float] = 896.0  # Lower edge of the corridor.
DUNGEON_GATE_X: Final[float] = 800.0          # Arena entrance gate.
DUNGEON_WALL_WIDTH: Final[float] = 32.0      # Dungeon wall thickness for the Soul Knight environment tiles.
DUNGEON_WALL_COLOR: Final[tuple[int, int, int]] = (56, 47, 42)
DUNGEON_WALL_EDGE_COLOR: Final[tuple[int, int, int]] = (28, 24, 22)
DUNGEON_GATE_COLOR: Final[tuple[int, int, int]] = (128, 102, 76)
DUNGEON_GATE_LOCKED_COLOR: Final[tuple[int, int, int]] = (176, 60, 48)
PLAYER_SPEED: Final[float] = 320.0
PLAYER_RADIUS: Final[float] = 28.0
PLAYER_AIM_LENGTH: Final[float] = 72.0
CAMERA_FOLLOW_SHARPNESS: Final[float] = 4.0
PLAYER_MAX_HEALTH: Final[int] = 120
class HeroCharacter(NamedTuple):
    """One selectable hero: sprites, UI art and its colour theme."""

    sprite: str           # Combat frame directory name under assets/sprites/<sprite>.
    name: str             # Display name on the character selection screen.
    idle_image: str       # Idle artwork for the lower card preview.
    avatar_image: str     # Avatar image for the circular portrait on the card.
    accent: tuple[int, int, int]   # Accent colour for the border, name and hotkey badge.
    panel: tuple[int, int, int]    # Card background colour.
    face_center: tuple[float, float] = (0.5, 0.5)  # Normalised face centre within the avatar (0 to 1).


# Selectable protagonists, with matching colours for each selection card.
PLAYER_CHARACTERS: Final[tuple[HeroCharacter, ...]] = (
    HeroCharacter(
        "player",
        "Shiveer",  # No surrounding whitespace.
        "assets/characters/hero1_idle.png",
        "assets/characters/hero1_avatar.png",
        (86, 132, 255),
        (18, 26, 52),
        (0.576, 0.750),
    ),
    HeroCharacter(
        "player2",
        "Fryee",
        "assets/characters/hero2_idle.png",
        "assets/characters/hero2_avatar.png",
        (252, 200, 60),
        (56, 40, 22),
        (0.525, 0.425),
    ),
)
PLAYER_CHARACTER_COUNT: Final[int] = len(PLAYER_CHARACTERS)

PATH_RECORD_SPACING: Final[float] = 12.0
PATH_MAX_POINTS: Final[int] = 600
PATH_MAX_LENGTH: Final[float] = 5000.0
PATH_DEBUG_COLOR: Final[tuple[int, int, int]] = (122, 220, 205)
PATH_DEBUG_POINT_COLOR: Final[tuple[int, int, int]] = (190, 255, 238)

# Start without followers; rescue waiting characters to recruit squad members.
SQUAD_TEST_MEMBER_COUNT: Final[int] = 0
SQUAD_FIRST_MEMBER_DISTANCE: Final[float] = 76.0
SQUAD_MEMBER_SPACING: Final[float] = 46.0
SQUAD_FOLLOW_SPEED: Final[float] = 430.0
SQUAD_MEMBER_RADIUS: Final[float] = 21.0
SQUAD_MEMBER_COLOR: Final[tuple[int, int, int]] = (70, 205, 122)
SQUAD_MEMBER_OUTLINE_COLOR: Final[tuple[int, int, int]] = (174, 255, 203)
SQUAD_AIM_COLOR: Final[tuple[int, int, int]] = (115, 245, 161)
SQUAD_DEAD_COLOR: Final[tuple[int, int, int]] = (88, 96, 101)
SQUAD_MAX_HEALTH: Final[int] = 70
FORMATION_SWITCH_COOLDOWN: Final[float] = 3.0
FORMATION_SNAKE_SPEED_MULTIPLIER: Final[float] = 1.5
FORMATION_WING_ROTATION_SPEED: Final[float] = PLAYER_SPEED * 2.0
# Protagonist damage multiplier for ranged and melee attacks.
PLAYER_DAMAGE_MULTIPLIER: Final[float] = 2.0
# Protagonist shield; squad members do not receive a shield.
# Default shield capacity absorbs five standard projectile hits (5 * 10 = 50).
PLAYER_SHIELD_MAX: Final[float] = 50.0
# Regenerate after the damage-free delay, until full or damaged again; use the values below.
PLAYER_SHIELD_REGEN_DELAY: Final[float] = 5.0
PLAYER_SHIELD_REGEN_RATE: Final[float] = 3.0
PLAYER_SHIELD_COLOR: Final[tuple[int, int, int]] = (96, 208, 255)
PLAYER_SHIELD_OUTLINE_COLOR: Final[tuple[int, int, int]] = (210, 245, 255)
# The equipped weapon determines the attack style; start with a pistol.
PICKUP_SWORD_COLOR: Final[tuple[int, int, int]] = (255, 165, 80)
PICKUP_PISTOL_COLOR: Final[tuple[int, int, int]] = (120, 200, 255)
WEAPON_PICKUP_RADIUS: Final[float] = 62.0
WEAPON_PICKUP_POSITIONS: Final[tuple[tuple[str, float, float], ...]] = (
    ("sword", 336.0, 688.0),   # Touch the sword station in the rest area to unlock and equip melee attacks.
    ("pistol", 336.0, 912.0),  # Touch the pistol station in the rest area to equip ranged attacks.
)

# Formation-two melee mechanics adapted from Sephiria: dash, three-hit combo and dash attack.
MELEE_MAX_DASH: Final[int] = 2
# Dash tuning increases speed and distance while keeping the duration fixed.
MELEE_DASH_SPEED: Final[float] = 1170.0  # Further 50% speed increase: 520 -> 780 -> 1170.
MELEE_DASH_DECEL: Final[float] = 600.0
MELEE_DASH_MAX_TIME: Final[float] = 0.45
MELEE_DASH_INVINCIBLE: Final[float] = 0.22  # Dash invulnerability lasts as long as dash invisibility.
MELEE_DASH_RECOVERY: Final[float] = 1.05
MELEE_DASH_ATTACK_WINDOW: Final[float] = 0.30
# Melee range increased from 80 to 240; damage uses the heavy-machine-gun value (22).
# Dash attack uses a 60-degree sector with a fixed reach matching the slash animation.
MELEE_RANGE: Final[float] = 240.0
MELEE_ARC: Final[float] = 80.0
MELEE_RANGE_CURVE: Final[float] = 0.55
MELEE_DAMAGE: Final[float] = 22.0
MELEE_STAGGER: Final[int] = 30
MELEE_COMBO_COUNT: Final[int] = 3
MELEE_COMBO_DAMAGE_MULT: Final[tuple[float, ...]] = (1.0, 1.05, 1.6)
MELEE_COMBO_WINDUP: Final[tuple[float, ...]] = (0.14, 0.12, 0.16)
MELEE_COMBO_SWING: Final[tuple[float, ...]] = (0.12, 0.12, 0.14)
MELEE_COMBO_RECOVERY: Final[tuple[float, ...]] = (0.16, 0.16, 0.24)
MELEE_ATTACK_SPEED: Final[float] = 1.0
MELEE_FINAL_HIT_RANGE_MULT: Final[float] = 1.15
MELEE_FINAL_HIT_FX_SCALE: Final[float] = 1.3
MELEE_ATTACK_MOVE_MULT: Final[float] = 1.0  # Attacking preserves the same movement speed as ranged combat.
MELEE_WINDUP: Final[float] = 0.14
MELEE_SWING: Final[float] = 0.12
MELEE_RECOVERY: Final[float] = 0.16
MELEE_DASH_ATK_WINDUP: Final[float] = 0.08
MELEE_DASH_ATK_SWING: Final[float] = 0.10
MELEE_DASH_ATK_RECOVERY: Final[float] = 0.18
MELEE_DASH_ATK_RANGE: Final[float] = 198.0
# Dash attack uses a 60-degree triangle; reach decreases linearly towards its edges.
MELEE_DASH_ATK_ARC: Final[float] = 60.0
MELEE_DASH_ATK_DAMAGE: Final[float] = 22.0
MELEE_DASH_ATK_MULT_NOCOST: Final[float] = 0.5
MELEE_DASH_ATK_IMPULSE: Final[float] = 400.0
MELEE_DASH_ATK_DIST_MULT: Final[float] = 1.5
MELEE_SLASH_FX_TIME: Final[float] = 0.22
MELEE_SPARK_TIME: Final[float] = 0.30
MELEE_SHAKE_TIME: Final[float] = 0.08
MELEE_SHAKE_MAG: Final[float] = 4.0
MELEE_SWING_LINE_LEN: Final[float] = 1.0
MELEE_SWING_TRAIL_TIME: Final[float] = 0.12
MELEE_SWING_TRAIL_SEGS: Final[int] = 4
MELEE_GHOST_INTERVAL: Final[float] = 0.05
MELEE_GHOST_TIME: Final[float] = 0.25
MELEE_SMOKE_TIME: Final[float] = 0.5
MELEE_SMOKE_RATIO: Final[float] = 0.2
MELEE_SMOKE_GROW: Final[float] = 1.6
SQUAD_SERIES_IMAGE: Final[str] = "assets/characters/squad_series.png"
SQUAD_PORTRAIT_COUNT: Final[int] = 4

RESCUE_RADIUS: Final[float] = 62.0
RESCUE_TARGET_POSITIONS: Final[tuple[tuple[float, float], ...]] = (
    (1081.0, 418.0),
    (1753.0, 502.0),
    (2425.0, 922.0),
    (1273.0, 1342.0),
)
RESCUE_WAITING_COLOR: Final[tuple[int, int, int]] = (241, 196, 65)
RESCUE_WAITING_OUTLINE_COLOR: Final[tuple[int, int, int]] = (255, 237, 153)
RESCUE_MARKER_COLOR: Final[tuple[int, int, int]] = (255, 226, 105)

SQUAD_SCAN_RANGE: Final[float] = 520.0
SQUAD_SCAN_INTERVAL: Final[float] = 0.25
SQUAD_ATTACK_RANGE: Final[float] = 500.0
# Unified projectile settings for the three ranged weapon variants.
# Rifle range, submachine-gun fire rate, medium damage and a nine-pixel projectile.
PROJECTILE_ATTACK_RANGE: Final[float] = 500.0
PROJECTILE_FIRE_INTERVAL: Final[float] = 0.24
PROJECTILE_SPEED: Final[float] = 760.0
PROJECTILE_DAMAGE: Final[int] = 10
PROJECTILE_LIFETIME: Final[float] = 1.2
PROJECTILE_RADIUS: Final[float] = 9.0
# Twenty squad members peak at about 160 concurrent projectiles at this fire rate.
# Preallocate enough capacity to avoid pool expansion during the stress benchmark.
PROJECTILE_POOL_INITIAL_SIZE: Final[int] = 192
PROJECTILE_COLOR: Final[tuple[int, int, int]] = (255, 235, 72)
WEAPON_PANEL_COLOR: Final[tuple[int, int, int, int]] = (8, 15, 23, 225)
WEAPON_BUTTON_COLOR: Final[tuple[int, int, int]] = (38, 55, 68)
WEAPON_BUTTON_HOVER_COLOR: Final[tuple[int, int, int]] = (55, 78, 94)
WEAPON_BUTTON_SELECTED_COLOR: Final[tuple[int, int, int]] = (35, 133, 181)
FRIENDLY_INK_COLOR: Final[tuple[int, int, int]] = (48, 128, 235)
# None uses a plain color. Set a project-relative or absolute PNG/JPG/BMP path
# to replace the lower map without changing projectile or reveal code.
FRIENDLY_INK_MAP_IMAGE: Final[str | None] = "assets/maps/ink_map.png"
FRIENDLY_INK_REVEAL_RADIUS: Final[float] = 15.0
FRIENDLY_INK_MARK_SPACING: Final[float] = 10.0

ENEMY_PLACEHOLDER_POSITIONS: Final[tuple[tuple[float, float], ...]] = (
    (985.0, 351.0),
    (1561.0, 418.0),
    (2041.0, 586.0),
    (2619.0, 334.0),
    (2330.0, 1090.0),
    (1273.0, 1258.0),
)
ENEMY_RADIUS: Final[float] = 26.0
# Melee minions for all three levels: straight dash with an attack-range warning.
SLIME_COUNT_PER_LEVEL: Final[int] = 2
SLIME_POSITIONS: Final[tuple[tuple[float, float], ...]] = (
    (1369.0, 502.0),
    (2137.0, 1174.0),
)
SLIME_RADIUS: Final[float] = 22.0
SLIME_MAX_HEALTH: Final[int] = 60
SLIME_CHASE_SPEED: Final[float] = 150.0
SLIME_DASH_TRIGGER_RANGE: Final[float] = 420.0
SLIME_DASH_WINDUP: Final[float] = 0.55
SLIME_DASH_SPEED: Final[float] = 950.0
SLIME_DASH_RANGE: Final[float] = 430.0
SLIME_DASH_DURATION: Final[float] = SLIME_DASH_RANGE / SLIME_DASH_SPEED
SLIME_DASH_COOLDOWN: Final[float] = 1.8
SLIME_DASH_DAMAGE: Final[int] = 12
SLIME_COLOR: Final[tuple[int, int, int]] = (208, 58, 66)
SLIME_OUTLINE_COLOR: Final[tuple[int, int, int]] = (118, 22, 32)
ENEMY_SERIES_IMAGE: Final[str] = "assets/characters/enemy_series.png"
ENEMY_PORTRAIT_COUNT: Final[int] = 2
ENEMY_COLOR: Final[tuple[int, int, int]] = (218, 70, 78)
ENEMY_OUTLINE_COLOR: Final[tuple[int, int, int]] = (255, 155, 160)
ENEMY_DETECTION_RANGE: Final[float] = 620.0
ENEMY_SCAN_INTERVAL: Final[float] = 0.3
ENEMY_MOVE_SPEED: Final[float] = 145.0
ENEMY_ATTACK_RANGE: Final[float] = 54.0
ENEMY_ATTACK_INTERVAL: Final[float] = 0.9
ENEMY_ATTACK_DAMAGE: Final[int] = 12
ENEMY_SEPARATION_DISTANCE: Final[float] = 58.0
ENEMY_SEPARATION_WEIGHT: Final[float] = 1.35
ENEMY_AIM_COLOR: Final[tuple[int, int, int]] = (255, 118, 124)
ENEMY_MAX_HEALTH: Final[int] = 60
ENEMY_RANGED_FIRE_INTERVAL: Final[float] = 5.0
ENEMY_RANGED_PROJECTILE_SPEED: Final[float] = 390.0
ENEMY_RANGED_PROJECTILE_DAMAGE: Final[int] = 8
ENEMY_RANGED_PROJECTILE_LIFETIME: Final[float] = 6.0
# Ranged minions fire two missiles; initial homing is followed by straight flight.
MISSILE_HOME_TIME: Final[float] = 2.0
MISSILE_LIFETIME: Final[float] = 9.0
MISSILE_PER_SHOT: Final[int] = 2
MISSILE_SPREAD_DEG: Final[float] = 12.0
MISSILE_RADIUS: Final[float] = 9.0

LEVEL_COUNT: Final[int] = 3
LEVEL_ONE_ENEMY_COUNT: Final[int] = 6
LEVEL_TWO_ENEMY_COUNT: Final[int] = 12
LEVEL_TWO_ELITE_COUNT: Final[int] = 2
ELITE_ENEMY_RADIUS: Final[float] = 34.0
ELITE_ENEMY_COLOR: Final[tuple[int, int, int]] = (151, 70, 204)
ELITE_ENEMY_OUTLINE_COLOR: Final[tuple[int, int, int]] = (225, 174, 255)
ELITE_ENEMY_MAX_HEALTH: Final[int] = 180
ELITE_ENEMY_MOVE_SPEED: Final[float] = 215.0
ELITE_BARRAGE_INTERVAL: Final[float] = 6.0
ELITE_BARRAGE_BULLET_COUNT: Final[int] = 16
ELITE_BARRAGE_BULLET_SPEED: Final[float] = 270.0
ELITE_BARRAGE_BULLET_DAMAGE: Final[int] = 9
ELITE_BARRAGE_BULLET_RADIUS: Final[float] = 9.0
ELITE_BARRAGE_BULLET_COLOR: Final[tuple[int, int, int]] = (255, 66, 66)

# Elite enemy bomb throwing.
ELITE_BOMB_INTERVAL: Final[float] = 3.0            # Throw interval.
ELITE_BOMB_THROW_DISTANCE: Final[float] = SLIME_DASH_RANGE * 0.4 * 2  # Range is 80% of the dash distance.
ELITE_BOMB_THROW_SPEED: Final[float] = PROJECTILE_SPEED * 1.3     # Increase the original speed by 30%.
ELITE_BOMB_FUSE_TIME: Final[float] = 4.0           # Explode four seconds after landing.
ELITE_BOMB_EXPLODE_RADIUS: Final[float] = SLIME_DASH_RANGE * 0.2  # Blast radius is 20% of the dash distance.
ELITE_BOMB_EXPLODE_DAMAGE: Final[int] = int(round(SLIME_DASH_DAMAGE * 1.5))
ELITE_BOMB_SPREAD_DEG: Final[float] = 30.0         # Empowered throw: forward and 30 degrees to either side.
ELITE_BOMB_EMPOWER_EVERY: Final[int] = 4           # Every fourth throw is empowered.
ELITE_BOMB_RADIUS: Final[float] = 12.0
ELITE_BOMB_TRAJECTORY_COLOR: Final[tuple[int, int, int]] = (255, 72, 60)
ELITE_BOMB_TRAJECTORY_WIDTH: Final[int] = 2
ELITE_BOMB_EXPLOSION_TIME: Final[float] = 0.45
ELITE_BOMB_EXPLOSION_FRAMES: Final[int] = 20

BOSS_NAME: Final[str] = "ABYSSAL SENTINEL"
BOSS_RADIUS: Final[float] = 56.0
BOSS_COLOR: Final[tuple[int, int, int]] = (120, 24, 42)
BOSS_INNER_COLOR: Final[tuple[int, int, int]] = (218, 55, 76)
BOSS_OUTLINE_COLOR: Final[tuple[int, int, int]] = (255, 164, 94)
BOSS_MAX_HEALTH: Final[int] = 1200
BOSS_MOVE_SPEED: Final[float] = 128.0
BOSS_ATTACK_RANGE: Final[float] = 82.0
BOSS_MELEE_DAMAGE: Final[int] = 18
BOSS_BARRAGE_INTERVAL: Final[float] = 7.0
BOSS_BARRAGE_RING_COUNT: Final[int] = 3
BOSS_BARRAGE_BULLETS_PER_RING: Final[int] = 32
BOSS_BARRAGE_CENTER_SPEED: Final[float] = 330.0
BOSS_BARRAGE_EXPANSION_SPEED: Final[float] = 135.0
BOSS_BARRAGE_LIFETIME: Final[float] = 12.0
BOSS_BARRAGE_DAMAGE: Final[int] = 12
# Barrage uses Soul Knight enemy projectile art; cap travel at 130% of dash distance.
BOSS_BARRAGE_BULLET_TEXTURE: Final[str] = "bullet_boss"
BOSS_BARRAGE_MAX_DISTANCE: Final[float] = SLIME_DASH_RANGE * 1.5   # 645
# After two barrages, the third attack launches three red iron balls.
BOSS_EMPOWER_EVERY: Final[int] = 3
# Normal barrage centre ball: no flashing, contact damage, 150% of empowered-ball health.
BOSS_RING_BALL_HEALTH: Final[int] = int(round(18 * 1.5))   # 27
BOSS_RING_BALL_DAMAGE: Final[int] = int(round(BOSS_BARRAGE_DAMAGE * 1.5))  # 18
IRON_BALL_HEALTH: Final[int] = int(round(SLIME_MAX_HEALTH * 0.3))   # 18
IRON_BALL_SPEED: Final[float] = SLIME_DASH_SPEED * 0.8            # 760
IRON_BALL_DISTANCE: Final[float] = SLIME_DASH_RANGE * 1.5         # 645 after a 50% increase.
IRON_BALL_RADIUS: Final[float] = 26.0
IRON_BALL_WAIT_TIME: Final[float] = 4.0   # Extend the original one-second duration by another three seconds.
IRON_BALL_BLINK_TIME: Final[float] = 2.0
IRON_BALL_COLOR: Final[tuple[int, int, int]] = (78, 82, 92)      # Silver-black.
IRON_BALL_DARK: Final[tuple[int, int, int]] = (26, 28, 34)
IRON_BALL_BLINK_COLOR: Final[tuple[int, int, int]] = (255, 58, 48)
# Green shockwave: diameter equals dash distance; clears shields or damages an unshielded player.
SHOCKWAVE_MAX_DIAMETER: Final[float] = SLIME_DASH_RANGE * 2.5      # 1075 after a 150% increase.
SHOCKWAVE_SPEED: Final[float] = SLIME_DASH_SPEED * 0.4 * 0.8       # 304 after a 20% decrease.
SHOCKWAVE_DAMAGE: Final[int] = int(round(SLIME_DASH_DAMAGE * 0.1))  # One damage when unshielded.
SHOCKWAVE_COLOR: Final[tuple[int, int, int]] = (86, 220, 118)
SHOCKWAVE_WIDTH: Final[int] = 7

HEALTH_BAR_BACKGROUND: Final[tuple[int, int, int]] = (45, 22, 27)
HEALTH_BAR_FOREGROUND: Final[tuple[int, int, int]] = (88, 220, 116)
HEALTH_BAR_OUTLINE: Final[tuple[int, int, int]] = (225, 232, 230)

VICTORY_REQUIRE_ALL_ENEMIES: Final[bool] = True
VICTORY_REQUIRE_RESCUES: Final[bool] = False
VICTORY_RESCUE_COUNT: Final[int] = 2

STRESS_SQUAD_COUNT: Final[int] = 20
STRESS_ENEMY_COUNT: Final[int] = 20
VICTORY_OVERLAY_COLOR: Final[tuple[int, int, int, int]] = (5, 36, 27, 210)
DEFEAT_OVERLAY_COLOR: Final[tuple[int, int, int, int]] = (48, 8, 14, 215)
VICTORY_TEXT_COLOR: Final[tuple[int, int, int]] = (125, 255, 174)
DEFEAT_TEXT_COLOR: Final[tuple[int, int, int]] = (255, 135, 141)

BACKGROUND_COLOR: Final[tuple[int, int, int]] = (15, 21, 29)
GROUND_COLOR: Final[tuple[int, int, int]] = (96, 98, 104)
# Apply a thin grey veil after drawing the floor to mute the initial map colours.
MAP_GREY_VEIL: Final[tuple[int, int, int, int]] = (128, 130, 136, 112)
# Hidden lower-left rest-area passage leads to level three; invisible until approached.
SECRET_PASSAGE_POSITION: Final[tuple[float, float]] = (96.0, 1585.0)
SECRET_PASSAGE_RADIUS: Final[float] = 42.0
SECRET_PASSAGE_REVEAL_RANGE: Final[float] = 190.0
SECRET_PASSAGE_TARGET_LEVEL: Final[int] = 3
SECRET_PASSAGE_COLOR: Final[tuple[int, int, int]] = (120, 240, 180)
GROUND_ALT_COLOR: Final[tuple[int, int, int]] = (29, 40, 50)
GRID_COLOR: Final[tuple[int, int, int]] = (36, 48, 58)
BOUNDARY_COLOR: Final[tuple[int, int, int]] = (103, 155, 170)
HUD_PANEL_COLOR: Final[tuple[int, int, int, int]] = (7, 11, 17, 210)
TEXT_COLOR: Final[tuple[int, int, int]] = (232, 240, 242)
ACCENT_COLOR: Final[tuple[int, int, int]] = (94, 190, 214)
PLAYER_COLOR: Final[tuple[int, int, int]] = (65, 145, 235)
PLAYER_OUTLINE_COLOR: Final[tuple[int, int, int]] = (157, 211, 255)
PLAYER_AIM_COLOR: Final[tuple[int, int, int]] = (91, 187, 255)
PAUSE_OVERLAY_COLOR: Final[tuple[int, int, int, int]] = (3, 6, 10, 165)

MAX_DELTA_TIME: Final[float] = 0.1

# Hidden fourth level: survival mode.
LEVEL_4_NUMBER: Final[int] = 4
# Level-four timeline and spawn intervals.
LEVEL_4_DURATION: Final[float] = 180.0        # Settle the result automatically after three minutes.
LEVEL_4_RANGED_INTERVAL: Final[float] = 10.0  # Spawn ranged minions every ten seconds.
LEVEL_4_MELEE_INTERVAL: Final[float] = 15.0   # Spawn melee minions every fifteen seconds.
LEVEL_4_ELITE_INTERVAL: Final[float] = 50.0   # Spawn an elite every fifty seconds.
LEVEL_4_BOSS_INTERVAL: Final[float] = 80.0    # Spawn a boss every eighty seconds.
LEVEL_4_EGG_INTERVAL: Final[float] = 7.0      # Spawn a fish egg every seven seconds.
LEVEL_4_EGG_MAX: Final[int] = 10              # Maximum carried eggs.
LEVEL_4_EGG_PICKUP_RADIUS: Final[float] = 64.0
LEVEL_4_SQUAD_EGG_COST: Final[int] = 2        # Revive a teammate at the centre when carrying more than two eggs.
LEVEL_4_SQUAD_HEAL: Final[int] = 20
LEVEL_4_CENTER_RADIUS: Final[float] = 46.0
LEVEL_4_WINDOW_RADIUS: Final[float] = 40.0
LEVEL_4_SPAWN_MARGIN: Final[float] = 120.0

# blue weapon indicator lines (ranged + melee) are hidden
PLAYER_AIM_LINE_VISIBLE: Final[bool] = False
