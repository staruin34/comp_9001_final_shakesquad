SNAKE SQUAD - COMP9001 FINAL PROJECT

MAIN SCRIPT
Run main.py from the project root. Keep game/ and assets/ beside main.py.
Do not run the files inside game/ individually.

REQUIREMENTS AND ED COMPATIBILITY
- Tested locally with Python 3.13.15 and pygame 2.6.1 on Windows.
- Third-party runtime library: pygame 2.6.1 (listed in requirements.txt).
- This is a desktop GUI game with a 1280 x 720 Pygame window.
- It loads PNG artwork and plays assets/audio/bgm_battle.mp3 through
  pygame.mixer. No video processing is used.
- The game does not use web services or networking. Internet access is needed
  only to obtain the external archive and install pygame.
- This program must be run locally outside Ed because it requires graphics
  and audio support. A keyboard and mouse are required.
- pytest is a development tool, not a runtime dependency, and is not needed
  to play. tkinter (part of standard Python installations when available)
  is used only for an optional startup-error dialog.

INSTALL AND RUN
1. Extract the full archive. Open a terminal in the folder containing main.py.
2. Install the dependency using the same Python interpreter that runs the game:
       python -m pip install -r requirements.txt
3. Start the game:
       python main.py
   On Windows, py -3.13 can replace python in both commands. The supplied
   run_game.bat is an alternative after installing the dependency.
4. Click a character card or press 1 or 2 to begin.

EXPECTED FOLDER STRUCTURE
SnakeSquad/
    main.py
    README.txt
    requirements.txt
    run_game.bat
    game/
        __init__.py
        game.py, level.py, settings.py, ...
        combat/, entities/, squad/, ui/
    assets/
        sprite_index.json
        sprites/, characters/, maps/, audio/
    AI_Usage_Statement.docx

CONTROLS AND QUICK PLAY GUIDE
W/A/S/D         Move
Mouse           Aim
Left mouse      Fire pistol / perform sword combo
Space           Dash
F               Switch weapons after obtaining the sword
Esc             Pause / resume
R               Restart the current level
N               Continue to the next level after victory (levels 1 and 2)
Tab (hold)      Show melee range preview
O               Toggle the debug parameter panel
F1              Toggle path debug drawing
Window close    Quit

Touch a weapon station in the rest area to equip that weapon. Move right
through the corridor to start combat. Rescue waiting allies to build a squad,
and defeat all enemies to clear the arena. There are three normal levels.
On level three, the top-left rest-area corner leads to a hidden three-minute
survival level. The top-right gear button opens the music volume slider.
Optional developer benchmark: python main.py --stress-test

TROUBLESHOOTING
- ModuleNotFoundError: pygame: run the installation command above using the
  same Python interpreter.
- Missing assets: extract the full archive first and confirm that assets/
  is next to main.py, not inside an extra nested assets/ folder.
- No music: check the gear-button volume slider and the system audio output.
  The game can continue without a working audio device.
- Unexpected startup errors are printed to the terminal and, where writable,
  saved beside main.py as crash_report.txt.

AI AND ASSET ATTRIBUTION
The supplied AI_Usage_Statement.docx records AI assistance with code writing,
refactoring and debugging, and with expanding character sketches into art
and animation frames. It also records the character-design references,
third-party environment placeholders and external background music.
The original asset notes are preserved in assets/README_en.md. These notes
are supplied with the project rather than a claim of independently verified
asset licences. No reusable or commercial licence is granted by this README.
