# Snake Squad — Pygame Prototype (English)

A top-down squad shooter: you drag a squad of followers through a dungeon, clear
the combat arena, rescue teammates and fight a boss. Built with Python 3.13 and
pygame 2.6.1.

## Run

```
pip install -r requirements.txt
python main.py
```

On Windows you can double-click `run_game.bat`. `python main.py --stress-test`
starts the stress benchmark instead of the normal level.

## Controls

| Key / Mouse | Action |
| --- | --- |
| `W` `A` `S` `D` | Move |
| Mouse | Aim |
| Left mouse | Fire (pistol) / melee combo (sword) |
| `Space` | Dash (sword: full distance, pistol: half distance) |
| `F` | Switch weapon (after picking up the sword) |
| `O` | Toggle the debug parameter panel |
| `1` / `2` | Pick a hero on the selection screen |
| `Esc` | Pause |
| `R` | Restart the level |
| `F1` | Toggle path debug drawing |

## Settings panel

A gear button in the **top-right corner** opens the settings panel. Drag the
slider to change the battle music volume from 0% to 100%; the value is applied
to the music immediately and stays for the session.

## Gameplay overview

- **Levels**: a rest area with weapon stations, a short corridor, then a walled
  combat arena. The gate locks behind you until every enemy is dead.
- **Weapons**: you start with a pistol (ranged). A sword station switches the
  protagonist to a three-hit melee combo plus a dash attack.
- **Shield**: the protagonist has a 50 point shield that absorbs damage first and
  regenerates 3 points per second after 5 seconds without damage. Squad members
  have no shield.
- **Squad**: rescued teammates follow you in a snake formation. During your dash
  they dash in the same direction for half the distance.
- **Enemies**: ranged minions fire two homing missiles, melee fish minions charge
  in a straight line, elites throw bombs, and the boss alternates bullet rings
  with an empowered iron-ball attack.
- **Hidden level four**: step into the top-left corner of the rest area on level
  three to enter a three minute survival arena with timed spawns and fish eggs.

## Project layout

```
main.py            entry point
game/              gameplay code (level, entities, combat, ui)
assets/            sprites, sprite index, music, portraits
README.md          original (Chinese) readme
README_en.md       this file
AI_Usage_Statement.docx  AI usage and attribution statement
```

## Asset and AI notes

The protagonist look is inspired by the Splatoon series (character design only,
non-commercial). Character and minion artwork started as hand-drawn sketches and
was expanded with ChatGPT into animation frames. See `AI_Usage_Statement.docx`
for the full statement.
