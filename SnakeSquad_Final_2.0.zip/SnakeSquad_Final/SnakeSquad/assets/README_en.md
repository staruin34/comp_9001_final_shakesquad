# assets - Asset Documentation (English)

## Source and licensing (important)

- The environment artwork comes from the third-party recreation repository
  [BlackHoleWithoutHair/Soul-Knight](https://github.com/BlackHoleWithoutHair/Soul-Knight),
  a public Unity tutorial project. The curated set lives outside this package.
- This must **not** be presented as official Soul Knight material. The rights of the
  original artwork and the licence of the recreation project have to be checked
  separately, and **no reusable or commercial licence was confirmed** for this build.
  Replace the material or obtain a licence before any release or commercial use.
- Only the minimal frames required to run the game are kept here (protagonists,
  goblin, floor tiles, walls, UI pieces, music); the rest of that repository is not
  copied.

## How the files were produced

- Sprites were exported from Unity atlases (`.meta` slice rectangles plus `.anim`
  key frames), cropped frame by frame and described by `sprite_index.json`, which
  maps every animation state to its frame list, frame rate and original size.
- The protagonist, minion, elite, boss, avatar and floor-tile sets were imported by
  small helper scripts (they live in the development repository, not in this package).

## Directory layout

```
assets/
  sprite_index.json     state -> frame list / fps / original size
  sprites/
    player/{idle,run}/    protagonist one (shiveer) frames
    player2/{idle,run}/   protagonist two (Fryee) frames
    goblin/{idle,run,die} ranged minion (jet mech)
    slime/{idle,run,dash,die} melee minion (mohawk fish)
    elite/{idle,run,die}  elite bomber
    boss/{idle,run,die}   boss
    items/                weapons, bullets, bombs, explosion frames, wall and
                          floor tiles, fish egg, counter frame, sliders
    floor_tiles/          16x16 Soul Knight floor tiles used for tiling
  characters/            selection portraits and avatars
  audio/bgm_battle.mp3   battle music
  maps/ink_map.png       ink reveal layer
```

## Characters

- **shiveer** (blue) and **Fryee** (yellow) are the two selectable protagonists.
  Each has an idle picture, a four-frame walk cycle and a defeated picture.
- Selection cards use the avatar pictures (`characters/hero1_avatar.png`,
  `characters/hero2_avatar.png`); replace those files to change the portraits
  without touching any code.
- The protagonist artwork started as hand-drawn sketches and was expanded into
  animation frames with ChatGPT assistance, then normalised to 44 px of raw height
  (88 px on screen, because SPRITE_SCALE is 2).

## Enemies

- **Ranged minion (jet mech)**: idle, four-frame walk, defeated.
- **Melee minion (mohawk fish)**: idle, four-frame swim, four-frame dash, defeated.
- **Elite bomber**: idle, four-frame walk, defeated.
- **Boss**: idle, four-frame walk, defeated (wide toppled pose).

## Items and effects

- `items/weapon_sword.png` is a hand-made 64x64 sword that replaces the library
  weapon; re-running the exporter keeps it.
- `items/bomb.png` (16x16) plus `items/explode_0..19.png` are the elite bomb and the
  twenty explosion frames.
- `items/wall_0..10.png` are 16x16 wall tiles tiled at 32 px along every dungeon wall.
- `items/fish_egg.png` and `items/egg_counter.png` belong to the hidden survival
  level (fish-egg pickups and the centre counter frame).
- `items/settings_panel.png`, `items/slider_track.png` and `items/slider_knob.png`
  are the Soul Knight pieces used by the top-right settings panel.

## Floor tiling

The floor is composited from 16x16 tiles (`sprites/floor_tiles/tile_00..20.png`,
scaled twice on screen) instead of stretching one large atlas, as recommended by the
asset pack notes.
