"""Core package for the Snake Squad prototype."""
