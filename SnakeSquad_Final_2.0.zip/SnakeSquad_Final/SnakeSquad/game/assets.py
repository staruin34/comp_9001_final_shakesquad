"""Lazy pixel-art sprite store with graceful fallback to vector art.

Frames are produced by tools/export_sprites.py into assets/sprites/ and
described by assets/sprite_index.json. Every accessor returns None when the
store is unavailable, so renderers keep their original procedural drawing.
"""
import json
import os

import pygame

from game import settings

_ROOT = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "assets"
)
_INDEX = None
_CACHE = {}
_FLOOR_CACHE = {}


def _load_index():
    global _INDEX
    if _INDEX is not None:
        return
    _INDEX = {}
    try:
        with open(
            os.path.join(_ROOT, "sprite_index.json"), encoding="utf-8"
        ) as fh:
            _INDEX = json.load(fh)
    except (OSError, ValueError):
        pass


def _ensure_pygame():
    try:
        if not pygame.get_init():
            pygame.init()
        # pygame 2 requires a display surface for convert_alpha()
        if pygame.display.get_surface() is None:
            pygame.display.set_mode((1, 1))
    except Exception:
        pass


def _scaled(surface):
    scale = int(settings.SPRITE_SCALE)
    if scale <= 1:
        return surface
    return pygame.transform.scale(
        surface,
        (surface.get_width() * scale, surface.get_height() * scale),
    )


def frame(kind, state, index):
    """Return one scaled animation frame, or None when unavailable."""
    _load_index()
    entry = (_INDEX.get(kind) or {}).get(state)
    if not entry or index >= len(entry.get("frames") or []):
        return None
    key = (kind, state, index)
    cached = _CACHE.get(key)
    if cached is not None:
        return cached
    try:
        _ensure_pygame()
        rel = entry["frames"][index].replace("\\", os.sep)
        path = os.path.join(_ROOT, "sprites", kind, rel)
        surface = pygame.image.load(path).convert_alpha()
        surface = _scaled(surface)
        _CACHE[key] = surface
        return surface
    except Exception:
        return None


def frame_count(kind, state):
    _load_index()
    entry = (_INDEX.get(kind) or {}).get(state)
    return len(entry.get("frames") or []) if entry else 0


def fps(kind, state):
    _load_index()
    entry = (_INDEX.get(kind) or {}).get(state)
    return float(entry.get("fps") or 6.0) if entry else 6.0


def item(kind):
    """Return one single-image item (weapon icon/bullet), scaled, or None."""
    _load_index()
    entry = (_INDEX.get("items") or {}).get(kind)
    if not entry:
        return None
    cached = _CACHE.get(("item", kind))
    if cached is not None:
        return cached
    try:
        _ensure_pygame()
        rel = entry["file"].replace("\\", os.sep)
        path = os.path.join(_ROOT, "sprites", rel)
        surface = pygame.image.load(path).convert_alpha()
        surface = _scaled(surface)
        _CACHE[("item", kind)] = surface
        return surface
    except Exception:
        return None


def item_raw(kind):
    """Return one single-image item at native size (no SPRITE_SCALE)."""
    _load_index()
    entry = (_INDEX.get("items") or {}).get(kind)
    if not entry:
        return None
    cached = _CACHE.get(("item_raw", kind))
    if cached is not None:
        return cached
    try:
        _ensure_pygame()
        rel = entry["file"].replace("\\", os.sep)
        path = os.path.join(_ROOT, "sprites", rel)
        surface = pygame.image.load(path).convert_alpha()
        _CACHE[("item_raw", kind)] = surface
        return surface
    except Exception:
        return None


def slash_frame(index, length, gold=False):
    """Return the pixel slash-arc frame scaled to the swing length."""
    _load_index()
    entry = (_INDEX.get("items") or {}).get("slash_%d" % index)
    if not entry:
        return None
    key = ("slash", index, int(length), bool(gold))
    cached = _CACHE.get(key)
    if cached is not None:
        return cached
    try:
        _ensure_pygame()
        rel = entry["file"].replace("\\", os.sep)
        path = os.path.join(_ROOT, "sprites", rel)
        raw = pygame.image.load(path).convert_alpha()
        width, height = raw.get_size()
        length = max(8, int(length))
        scaled = pygame.transform.scale(
            raw, (length, max(2, int(height * length / width)))
        )
        if gold:
            tint = pygame.Surface(scaled.get_size(), pygame.SRCALPHA)
            tint.fill((255, 205, 110))
            tint.blit(scaled, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
            scaled = tint
        _CACHE[key] = scaled
        return scaled
    except Exception:
        return None


def wall_tile(size, index=4):
    """Return one dungeon wall tile scaled to a square size, or None."""
    _load_index()
    entry = (_INDEX.get("items") or {}).get("wall_%d" % index)
    if not entry:
        return None
    key = ("wall", int(size), int(index))
    cached = _CACHE.get(key)
    if cached is not None:
        return cached
    try:
        _ensure_pygame()
        rel = entry["file"].replace("\\", os.sep)
        path = os.path.join(_ROOT, "sprites", rel)
        raw = pygame.image.load(path).convert_alpha()
        surface = pygame.transform.scale(raw, (int(size), int(size)))
        _CACHE[key] = surface
        return surface
    except Exception:
        return None


def bullet(kind, diameter):
    """Return a bullet sprite scaled to the requested diameter, or None."""
    _load_index()
    entry = (_INDEX.get("items") or {}).get(kind)
    if not entry:
        return None
    key = ("bullet", kind, diameter)
    cached = _CACHE.get(key)
    if cached is not None:
        return cached
    base = item(kind)
    if base is None:
        return None
    try:
        size = max(2, int(diameter))
        surface = pygame.transform.scale(base, (size, size))
        _CACHE[key] = surface
        return surface
    except Exception:
        return None


# Read individual 16x16 floor tiles; return an empty list if unavailable.
def floor_tiles():
    """Return the 16x16 floor tile surfaces (raw), or an empty list."""
    _load_index()
    _ensure_pygame()
    section = _INDEX.get("floor_tiles") or {}
    tiles = []
    for rel in section.get("tiles") or []:
        key = ("floor-tile", rel)
        cached = _CACHE.get(key)
        if cached is not None:
            tiles.append(cached)
            continue
        try:
            path = os.path.join(_ROOT, "sprites", rel.replace("\\", os.sep))
            surface = pygame.image.load(path).convert_alpha()
        except Exception:
            continue
        _CACHE[key] = surface
        tiles.append(surface)
    return tiles


# Scale 16x16 tiles and mix them into patches to reduce visible repetition.
def _floor_mosaic(size):
    """Build a mosaic of 16x16 tiles scaled by SPRITE_SCALE, if available."""
    tiles = floor_tiles()
    if not tiles:
        return None
    cell = max(16, 16 * settings.SPRITE_SCALE)
    count = max(1, size // cell)
    mosaic = pygame.Surface((count * cell, count * cell), pygame.SRCALPHA)
    for row in range(count):
        for col in range(count):
            index = (row * 7 + col * 13 + row * col * 3) % len(tiles)
            mosaic.blit(
                pygame.transform.scale(tiles[index], (cell, cell)),
                (col * cell, row * cell),
            )
    return mosaic


def floor_tile(size):
    """Return a tiled floor patch (16x16 tiles) or the legacy texture."""
    _load_index()
    cached = _FLOOR_CACHE.get(size)
    if cached is not None:
        return cached
    mosaic = _floor_mosaic(size)
    if mosaic is not None:
        _FLOOR_CACHE[size] = mosaic
        return mosaic
    entry = _INDEX.get("floor")
    if not entry:
        return None
    try:
        _ensure_pygame()
        rel = entry["file"].replace("\\", os.sep)
        path = os.path.join(_ROOT, "sprites", rel)
        surface = pygame.image.load(path).convert_alpha()
        surface = pygame.transform.scale(surface, (size, size))
        _FLOOR_CACHE[size] = surface
        return surface
    except Exception:
        return None
