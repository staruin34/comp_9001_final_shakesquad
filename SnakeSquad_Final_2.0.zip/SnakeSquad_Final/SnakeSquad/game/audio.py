# Battle music: starts with combat, stops on end/victory/defeat.
import os

import pygame

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BGM_PATH = os.path.join(PROJECT_ROOT, "assets", "audio", "bgm_battle.mp3")
_ready = False
_playing = False


def _ensure_mixer() -> bool:
    """Initialise the mixer once; tests/headless runs may not support it."""
    global _ready
    if _ready:
        return True
    try:
        if not pygame.mixer.get_init():
            pygame.mixer.init()
        pygame.mixer.music.set_volume(_volume)
        _ready = True
    except Exception:
        _ready = False
    return _ready


def play_battle_bgm() -> bool:
    """Start the battle track once (no looping)."""
    global _playing
    if _playing and is_playing():
        return True
    if not os.path.exists(BGM_PATH) or not _ensure_mixer():
        return False
    try:
        pygame.mixer.music.load(BGM_PATH)
        pygame.mixer.music.play(0)
        _playing = True
        return True
    except Exception:
        _playing = False
        return False


def stop_battle_bgm() -> None:
    """Silence the track (victory, defeat, restart or track end)."""
    global _playing
    _playing = False
    try:
        pygame.mixer.music.stop()
    except Exception:
        pass


def is_playing() -> bool:
    """True while the track is still running."""
    try:
        return bool(pygame.mixer.music.get_busy())
    except Exception:
        return False


def tick() -> None:
    """Stop the music once the file finished playing."""
    global _playing
    if _playing and not is_playing():
        _playing = False
        stop_battle_bgm()


_volume = 0.55


def set_volume(value: float) -> float:
    """Set the battle music volume (0.0 - 1.0) and return the applied value."""
    global _volume
    _volume = max(0.0, min(1.0, float(value)))
    try:
        if _ensure_mixer():
            pygame.mixer.music.set_volume(_volume)
    except Exception:
        pass
    return _volume


def get_volume() -> float:
    """Current battle music volume (0.0 - 1.0)."""
    return _volume
