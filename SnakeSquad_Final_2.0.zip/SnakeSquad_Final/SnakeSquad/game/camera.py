"""Smooth, clamped conversion between world and screen coordinates."""

import math

import pygame


class Camera:
    """Track a world-space offset for a viewport of fixed pixel size."""

    def __init__(
        self,
        viewport_size: tuple[int, int],
        world_bounds: pygame.Rect,
        follow_sharpness: float,
    ) -> None:
        self.viewport_size = pygame.Vector2(viewport_size)
        self.world_bounds = world_bounds.copy()
        self.follow_sharpness = follow_sharpness
        self.offset = pygame.Vector2()

    def snap_to(self, target_world_position: pygame.Vector2) -> None:
        """Center immediately on a target, respecting world edges."""
        self.offset = self._desired_offset(target_world_position)

    def update(self, target_world_position: pygame.Vector2, delta_time: float) -> None:
        """Follow a target smoothly with frame-rate-independent damping."""
        desired = self._desired_offset(target_world_position)
        blend = 1.0 - math.exp(-self.follow_sharpness * max(delta_time, 0.0))
        self.offset = self.offset.lerp(desired, blend)
        self._clamp_offset()

    def world_to_screen(self, world_position: pygame.Vector2) -> pygame.Vector2:
        """Convert a world-space point into screen space."""
        return pygame.Vector2(world_position) - self.offset

    def screen_to_world(self, screen_position: pygame.Vector2) -> pygame.Vector2:
        """Convert a screen-space point into world space."""
        return pygame.Vector2(screen_position) + self.offset

    def world_rect_to_screen(self, world_rect: pygame.Rect) -> pygame.Rect:
        """Convert a world-aligned rectangle into a screen rectangle."""
        return world_rect.move(-round(self.offset.x), -round(self.offset.y))

    def _desired_offset(self, target_world_position: pygame.Vector2) -> pygame.Vector2:
        desired = pygame.Vector2(target_world_position) - self.viewport_size / 2.0
        return self._clamped(desired)

    def _clamp_offset(self) -> None:
        self.offset = self._clamped(self.offset)

    def _clamped(self, offset: pygame.Vector2) -> pygame.Vector2:
        max_x = max(0.0, self.world_bounds.width - self.viewport_size.x)
        max_y = max(0.0, self.world_bounds.height - self.viewport_size.y)
        return pygame.Vector2(
            max(0.0, min(offset.x, max_x)),
            max(0.0, min(offset.y, max_y)),
        )
