"""Targeting, weapons, and projectile systems.

Combat classes are imported from their defining modules to keep package
initialization free of circular dependencies.
"""
