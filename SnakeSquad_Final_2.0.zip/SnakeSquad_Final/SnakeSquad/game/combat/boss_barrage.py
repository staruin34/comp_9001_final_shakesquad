"""Moving and expanding 32-projectile rings fired by the level-three boss."""

from dataclasses import dataclass, field
from math import cos, pi, sin
from collections.abc import Sequence

import pygame

from game import assets, settings
from game.camera import Camera
from game.damage import DamageInfo
from game.factions import Faction, is_hostile


def _segment_hits_circle(
    start: pygame.Vector2,
    end: pygame.Vector2,
    center: pygame.Vector2,
    radius: float,
) -> bool:
    segment = end - start
    if segment.length_squared() <= 0.000001:
        return start.distance_squared_to(center) <= radius**2
    fraction = max(
        0.0,
        min(1.0, (center - start).dot(segment) / segment.length_squared()),
    )
    return (start + segment * fraction).distance_squared_to(center) <= radius**2


@dataclass
class BossBarrageRing:
    """One forward-moving ring whose 32 projectiles expand around its center."""

    center: pygame.Vector2
    direction: pygame.Vector2
    owner: object
    radius: float = settings.BOSS_RADIUS + 14.0
    lifetime: float = settings.BOSS_BARRAGE_LIFETIME
    travelled: float = 0.0
    ball: object = None
    ball_hits: set = field(default_factory=set)

    def __post_init__(self) -> None:
        """Attach a damageable iron ball at the ring centre."""
        from game.entities.iron_ball import IronBall

        self.ball = IronBall(
            position=pygame.Vector2(self.center),
            direction=pygame.Vector2(self.direction),
            owner=self.owner,
            health=settings.BOSS_RING_BALL_HEALTH,
            max_health=settings.BOSS_RING_BALL_HEALTH,
            blink_enabled=False,       # normal barrage balls never blink
            shockwave_enabled=False,   # only empowered balls blast
        )
    hit_pairs: set[tuple[int, int]] = field(default_factory=set)

    def bullet_position(self, index: int) -> pygame.Vector2:
        angle = index * 2.0 * pi / settings.BOSS_BARRAGE_BULLETS_PER_RING
        radial = pygame.Vector2(cos(angle), sin(angle))
        return self.center + radial * self.radius

    def bullet_velocity(self, index: int) -> pygame.Vector2:
        angle = index * 2.0 * pi / settings.BOSS_BARRAGE_BULLETS_PER_RING
        radial = pygame.Vector2(cos(angle), sin(angle))
        return (
            self.direction * settings.BOSS_BARRAGE_CENTER_SPEED
            + radial * settings.BOSS_BARRAGE_EXPANSION_SPEED
        )

    def update(
        self,
        delta_time: float,
        targets: Sequence[object],
    ) -> None:
        """Move center and radius, then resolve target collisions."""
        previous_positions = [
            self.bullet_position(index)
            for index in range(settings.BOSS_BARRAGE_BULLETS_PER_RING)
        ]
        safe_delta = max(delta_time, 0.0)
        step = settings.BOSS_BARRAGE_CENTER_SPEED * safe_delta
        # Destroying the centre ball immediately removes its surrounding barrage.
        if self.ball is None or self.ball.health <= 0:
            # destroying the centre ball ends this whole volley early
            self.lifetime = 0.0
            return
        self.center += self.direction * step
        self.radius += settings.BOSS_BARRAGE_EXPANSION_SPEED * safe_delta
        self.travelled += step
        self.lifetime -= safe_delta
        self.ball.position = pygame.Vector2(self.center)
        self._resolve_ball_hits(targets)
        if self.travelled >= settings.BOSS_BARRAGE_MAX_DISTANCE:
            # the volley vanishes after 130% of the slime dash distance
            self.lifetime = 0.0

        for index, previous in enumerate(previous_positions):
            current = self.bullet_position(index)
            for target in tuple(targets):
                pair = (index, id(target))
                if pair in self.hit_pairs or not getattr(target, "is_alive", False):
                    continue
                combined_radius = settings.PROJECTILE_RADIUS + getattr(target, "radius", 0.0)
                if not _segment_hits_circle(
                    previous,
                    current,
                    target.position,
                    combined_radius,
                ):
                    continue
                receive_damage = getattr(target, "receive_damage", None)
                if callable(receive_damage):
                    receive_damage(
                        DamageInfo(
                            settings.BOSS_BARRAGE_DAMAGE,
                            self.owner,
                            Faction.ENEMY,
                            current.copy(),
                            "boss_barrage",
                        )
                    )
                self.hit_pairs.add(pair)

    def _resolve_ball_hits(self, targets) -> None:
        """The centre ball deals contact damage once per target."""
        for target in tuple(targets):
            target_id = id(target)
            if target_id in self.ball_hits or not getattr(target, "is_alive", False):
                continue
            faction = getattr(target, "faction", Faction.NEUTRAL)
            if not is_hostile(Faction.ENEMY, faction):
                continue
            reach = self.ball.radius + getattr(target, "radius", 0.0)
            if self.center.distance_to(target.position) > reach:
                continue
            receive = getattr(target, "receive_damage", None)
            if callable(receive):
                receive(
                    DamageInfo(
                        settings.BOSS_RING_BALL_DAMAGE,
                        self.owner,
                        Faction.ENEMY,
                        self.center.copy(),
                        "ring_ball",
                    )
                )
            self.ball_hits.add(target_id)

    @property
    def is_expired(self) -> bool:
        return self.lifetime <= 0.0


class BossBarrage:
    """Own the three-ring boss volleys and their bounded lifetime."""

    def __init__(self) -> None:
        self.rings: list[BossBarrageRing] = []
        self.volleys: int = 0

    def next_volley_is_empowered(self) -> bool:
        """Every third volley is the empowered iron-ball attack."""
        self.volleys += 1
        if self.volleys % settings.BOSS_EMPOWER_EVERY == 0:
            self.volleys = 0
            return True
        return False

    @staticmethod
    def volley_directions(
        origin: pygame.Vector2, aimed_position: pygame.Vector2
    ) -> tuple[pygame.Vector2, ...]:
        """The aimed direction plus the two 45-degree ring directions."""
        aimed = pygame.Vector2(aimed_position) - pygame.Vector2(origin)
        if aimed.length_squared() <= 0.000001:
            aimed = pygame.Vector2(1.0, 0.0)
        aimed.normalize_ip()
        return (aimed.rotate(45.0), aimed, aimed.rotate(-45.0))

    def spawn_three_rings(
        self,
        origin: pygame.Vector2,
        aimed_position: pygame.Vector2,
        owner: object,
    ) -> None:
        """Spawn aimed, left-45-degree, and right-45-degree moving rings."""
        aimed = aimed_position - origin
        if aimed.length_squared() <= 0.000001:
            aimed = pygame.Vector2(1.0, 0.0)
        aimed.normalize_ip()
        directions = (aimed.rotate(45.0), aimed, aimed.rotate(-45.0))
        self.rings.extend(
            BossBarrageRing(pygame.Vector2(origin), direction, owner)
            for direction in directions
        )

    def update(
        self,
        delta_time: float,
        targets: Sequence[object],
    ) -> None:
        for ring in self.rings:
            ring.update(delta_time, targets)
        self.rings = [ring for ring in self.rings if not ring.is_expired]

    @property
    def ring_balls(self) -> list:
        """Damageable centre balls of the live volleys."""
        return [
            ring.ball for ring in self.rings
            if ring.ball is not None and ring.ball.health > 0
        ]

    def render(self, surface: pygame.Surface, camera: Camera) -> None:
        visible = surface.get_rect().inflate(30, 30)
        for ring in self.rings:
            if ring.ball is not None and ring.ball.health > 0:
                ring.ball.render(surface, camera)
            for index in range(settings.BOSS_BARRAGE_BULLETS_PER_RING):
                position = camera.world_to_screen(ring.bullet_position(index))
                center = (round(position.x), round(position.y))
                if not visible.collidepoint(center):
                    continue
                sprite = assets.bullet(
                    settings.BOSS_BARRAGE_BULLET_TEXTURE,
                    round(settings.PROJECTILE_RADIUS * 2.6),
                )
                if sprite is None:
                    pygame.draw.circle(
                        surface,
                        settings.ELITE_BARRAGE_BULLET_COLOR,
                        center,
                        round(settings.PROJECTILE_RADIUS),
                    )
                else:
                    surface.blit(sprite, sprite.get_rect(center=center))

    @property
    def bullet_count(self) -> int:
        return settings.BOSS_BARRAGE_BULLETS_PER_RING * len(self.rings)
