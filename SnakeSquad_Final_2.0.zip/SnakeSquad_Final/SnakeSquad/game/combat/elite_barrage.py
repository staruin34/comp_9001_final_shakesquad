"""Permanent expanding radial bullet rings fired by elite enemies."""

from dataclasses import dataclass, field
from math import cos, pi, sin
from collections.abc import Sequence

import pygame

from game import assets, settings
from game.camera import Camera
from game.damage import DamageInfo
from game.factions import Faction


@dataclass
class EliteBarrageBullet:
    """A permanent radial bullet that can damage each target only once."""

    position: pygame.Vector2
    direction: pygame.Vector2
    owner: object
    speed: float = settings.ELITE_BARRAGE_BULLET_SPEED
    damage: int = settings.ELITE_BARRAGE_BULLET_DAMAGE
    radius: float = settings.ELITE_BARRAGE_BULLET_RADIUS
    hit_target_ids: set[int] = field(default_factory=set)

    def update(self, delta_time: float, targets: Sequence[object]) -> None:
        """Expand forever and apply at most one hit to each living target."""
        self.position += self.direction * self.speed * max(delta_time, 0.0)
        self.resolve_hits(targets)

    def resolve_hits(self, targets: Sequence[object]) -> None:
        """Apply this bullet to valid overlapping targets once each."""
        for target in tuple(targets):
            target_id = id(target)
            if target_id in self.hit_target_ids or not getattr(target, "is_alive", False):
                continue
            target_position = getattr(target, "position", None)
            target_radius = getattr(target, "radius", 0.0)
            if target_position is None:
                continue
            radius_sum = self.radius + target_radius
            if self.position.distance_squared_to(target_position) > radius_sum**2:
                continue
            receive_damage = getattr(target, "receive_damage", None)
            if callable(receive_damage):
                receive_damage(
                    DamageInfo(
                        self.damage,
                        self.owner,
                        Faction.ENEMY,
                        self.position.copy(),
                        "elite_barrage",
                    )
                )
            self.hit_target_ids.add(target_id)


class EliteBarrage:
    """Own all non-expiring elite bullets for the current level."""

    def __init__(self) -> None:
        self.bullets: list[EliteBarrageBullet] = []

    def spawn_ring(
        self,
        origin: pygame.Vector2,
        aimed_position: pygame.Vector2,
        owner: object,
    ) -> None:
        """Spawn 16 evenly spaced bullets with one aimed at the player."""
        aim = aimed_position - origin
        base_angle = aim.as_polar()[1] * pi / 180.0 if aim.length_squared() else 0.0
        for index in range(settings.ELITE_BARRAGE_BULLET_COUNT):
            angle = base_angle + index * 2.0 * pi / settings.ELITE_BARRAGE_BULLET_COUNT
            direction = pygame.Vector2(cos(angle), sin(angle))
            self.bullets.append(
                EliteBarrageBullet(
                    pygame.Vector2(origin),
                    direction,
                    owner,
                )
            )

    def update(
        self,
        delta_time: float,
        targets: Sequence[object],
    ) -> None:
        """Expand every permanent bullet and resolve its target hits."""
        for bullet in self.bullets:
            bullet.update(delta_time, targets)

    def render(self, surface: pygame.Surface, camera: Camera) -> None:
        """Draw visible portions of every permanent expanding ring."""
        margin = settings.ELITE_BARRAGE_BULLET_RADIUS
        visible = surface.get_rect().inflate(round(margin * 2), round(margin * 2))
        for bullet in self.bullets:
            screen_position = camera.world_to_screen(bullet.position)
            center = (round(screen_position.x), round(screen_position.y))
            if not visible.collidepoint(center):
                continue
            sprite = assets.bullet("bullet_enemy", round(bullet.radius * 2))
            if sprite is None:
                pygame.draw.circle(
                    surface,
                    settings.ELITE_BARRAGE_BULLET_COLOR,
                    center,
                    round(bullet.radius),
                )
            else:
                surface.blit(sprite, sprite.get_rect(center=center))

    @property
    def bullet_count(self) -> int:
        """Return the permanent bullet count for HUD and tests."""
        return len(self.bullets)
