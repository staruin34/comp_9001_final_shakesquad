"""Manager for elite bombs: throwing, flight, blinking and blasts."""

from collections.abc import Sequence

import pygame

from game import assets, settings
from game.camera import Camera
from game.entities.bomb import Bomb


class EliteBombs:
    """Owns every live bomb thrown by elite enemies."""

    def __init__(self) -> None:
        self.bombs: list[Bomb] = []

    @property
    def count(self) -> int:
        return len(self.bombs)

    def throw(
        self,
        origin: pygame.Vector2,
        direction: pygame.Vector2,
        owner: object,
    ) -> Bomb:
        """Throw one bomb toward a direction at the configured speed."""
        heading = pygame.Vector2(direction)
        if heading.length_squared() <= 0.000001:
            heading = pygame.Vector2(1.0, 0.0)
        bomb = Bomb(
            position=pygame.Vector2(origin),
            direction=heading.normalize(),
            owner=owner,
            origin=pygame.Vector2(origin),
        )
        self.bombs.append(bomb)
        return bomb

    def update(self, delta_time: float, targets: Sequence[object]) -> None:
        """Advance every bomb and drop the ones whose blast finished."""
        for bomb in self.bombs:
            bomb.update(delta_time, targets)
        self.bombs = [bomb for bomb in self.bombs if not bomb.finished]

    def render(self, surface: pygame.Surface, camera: Camera) -> None:
        """Draw trajectories, blinking bombs and explosion frames."""
        for bomb in self.bombs:
            bomb_sprite = assets.item("bomb")
            if bomb.exploded:
                self._render_explosion(surface, camera, bomb)
                continue
            screen = camera.world_to_screen(bomb.position)
            # Draw a thin red trail in flight; remove it when the bomb lands.
            if bomb.show_trajectory:
                start = camera.world_to_screen(bomb.origin)
                end = camera.world_to_screen(bomb.landing)
                pygame.draw.line(
                    surface,
                    settings.ELITE_BOMB_TRAJECTORY_COLOR,
                    (round(start.x), round(start.y)),
                    (round(end.x), round(end.y)),
                    settings.ELITE_BOMB_TRAJECTORY_WIDTH,
                )
            if bomb_sprite is None:
                pygame.draw.circle(
                    surface, (40, 40, 52),
                    (round(screen.x), round(screen.y)), round(bomb.radius),
                )
                continue
            alpha = bomb.blink_alpha()
            if alpha < 255:
                bomb_sprite = bomb_sprite.copy()
                bomb_sprite.set_alpha(alpha)
            surface.blit(
                bomb_sprite,
                bomb_sprite.get_rect(center=(round(screen.x), round(screen.y))),
            )

    def _render_explosion(
        self, surface: pygame.Surface, camera: Camera, bomb: Bomb
    ) -> None:
        elapsed = settings.ELITE_BOMB_EXPLOSION_TIME - max(
            0.0, bomb.explosion_timer
        )
        progress = max(0.0, min(0.999, elapsed / settings.ELITE_BOMB_EXPLOSION_TIME))
        index = int(progress * settings.ELITE_BOMB_EXPLOSION_FRAMES)
        sprite = assets.item("explode_%d" % index)
        diameter = max(16, round(settings.ELITE_BOMB_EXPLODE_RADIUS * 2))
        screen = camera.world_to_screen(bomb.position)
        if sprite is None:
            pygame.draw.circle(
                surface, (255, 150, 60),
                (round(screen.x), round(screen.y)),
                max(2, round(diameter * progress)),
                max(1, round(6 * (1.0 - progress))),
            )
            return
        scaled = pygame.transform.scale(sprite, (diameter, diameter))
        surface.blit(
            scaled,
            scaled.get_rect(center=(round(screen.x), round(screen.y))),
        )
