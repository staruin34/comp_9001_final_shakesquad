"""Homing enemy missiles fired by ranged minions (2 per shot)."""

from dataclasses import dataclass, field

import pygame

from game import assets, settings
from game.camera import Camera
from game.damage import DamageInfo
from game.factions import Faction, is_hostile


@dataclass
class EnemyMissile:
    """Tracks the protagonist for 4 seconds, then flies straight."""

    position: pygame.Vector2
    direction: pygame.Vector2
    owner: object
    radius: float = settings.MISSILE_RADIUS
    age: float = 0.0
    active: bool = True

    def update(self, delta_time: float, targets, aim_position) -> None:
        """Home for the configured window, then keep the heading."""
        if not self.active:
            return
        safe_delta = max(delta_time, 0.0)
        self.age += safe_delta
# Turn towards the player during homing; freeze direction after the homing window.
        if self.age <= settings.MISSILE_HOME_TIME and aim_position is not None:
            steer = pygame.Vector2(aim_position) - self.position
            if steer.length_squared() > 0.000001:
                self.direction = steer.normalize()
        self.position += (
            self.direction * settings.ENEMY_RANGED_PROJECTILE_SPEED * safe_delta
        )
        for target in tuple(targets):
            if not getattr(target, "is_alive", False):
                continue
            if not is_hostile(Faction.ENEMY, getattr(target, "faction", Faction.NEUTRAL)):
                continue
            reach = self.radius + getattr(target, "radius", 0.0)
            if self.position.distance_to(target.position) > reach:
                continue
            receive = getattr(target, "receive_damage", None)
            if callable(receive):
                receive(
                    DamageInfo(
                        settings.ENEMY_RANGED_PROJECTILE_DAMAGE,
                        self.owner,
                        Faction.ENEMY,
                        self.position.copy(),
                        "missile",
                    )
                )
            self.active = False
            return
        if self.age >= settings.MISSILE_LIFETIME:
            self.active = False


class MissileField:
    """Owns every missile fired by ranged minions."""

    def __init__(self) -> None:
        self.missiles: list[EnemyMissile] = []

    @property
    def count(self) -> int:
        return len(self.missiles)

    def fire(self, origin: pygame.Vector2, aim: pygame.Vector2, owner) -> None:
        """Fire two missiles fanned around the aim direction."""
        heading = pygame.Vector2(aim) - pygame.Vector2(origin)
        if heading.length_squared() <= 0.000001:
            heading = pygame.Vector2(1.0, 0.0)
        heading = heading.normalize()
        spread = settings.MISSILE_SPREAD_DEG
        for offset in (-spread, spread):
            self.missiles.append(
                EnemyMissile(
                    position=pygame.Vector2(origin)
                    + heading.rotate(offset) * 8.0,
                    direction=heading.rotate(offset),
                    owner=owner,
                )
            )

    def update(self, delta_time: float, targets, aim_position) -> None:
        for missile in self.missiles:
            missile.update(delta_time, targets, aim_position)
        self.missiles = [m for m in self.missiles if m.active]

    def render(self, surface: pygame.Surface, camera: Camera) -> None:
        sprite = assets.item("missile")
        for missile in self.missiles:
            screen = camera.world_to_screen(missile.position)
            center = (round(screen.x), round(screen.y))
            if sprite is None:
                pygame.draw.circle(
                    surface, (255, 120, 90), center, round(missile.radius)
                )
                continue
            angle = pygame.Vector2(missile.direction).angle_to(
                pygame.Vector2(1.0, 0.0)
            )
            rotated = pygame.transform.rotate(sprite, angle)
            surface.blit(rotated, rotated.get_rect(center=center))
