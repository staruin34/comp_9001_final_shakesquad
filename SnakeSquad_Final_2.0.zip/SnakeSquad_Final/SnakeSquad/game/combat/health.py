"""Reusable health component with one-shot death notification."""

from collections.abc import Callable

from game.damage import DamageInfo


DamageCallback = Callable[[DamageInfo], None]


class Health:
    """Own clamped hit points and notify registered callbacks."""

    def __init__(self, max_health: int) -> None:
        if max_health <= 0:
            raise ValueError("max_health must be greater than zero")
        self.max_health = int(max_health)
        self.current_health = int(max_health)
        self._damaged_callbacks: list[DamageCallback] = []
        self._death_callbacks: list[DamageCallback] = []
        self._death_notified = False

    def take_damage(self, damage: DamageInfo) -> bool:
        """Apply positive damage once while alive and report success."""
        if self.is_dead or damage.amount <= 0:
            return False

        self.current_health = max(0, self.current_health - int(damage.amount))
        for callback in tuple(self._damaged_callbacks):
            callback(damage)

        if self.is_dead and not self._death_notified:
            self._death_notified = True
            for callback in tuple(self._death_callbacks):
                callback(damage)
        return True

    def heal(self, amount: int) -> None:
        """Restore health without exceeding maximum or reviving the dead."""
        if amount > 0 and not self.is_dead:
            self.current_health = min(
                self.max_health,
                self.current_health + int(amount),
            )

    def add_damaged_callback(self, callback: DamageCallback) -> None:
        """Register a callback for each successfully applied damage event."""
        if callback not in self._damaged_callbacks:
            self._damaged_callbacks.append(callback)

    def add_death_callback(self, callback: DamageCallback) -> None:
        """Register a callback for the single transition to zero health."""
        if callback not in self._death_callbacks:
            self._death_callbacks.append(callback)

    @property
    def is_dead(self) -> bool:
        """Return whether current health has reached zero."""
        return self.current_health <= 0

    @property
    def ratio(self) -> float:
        """Return normalized health for rendering."""
        return self.current_health / self.max_health
