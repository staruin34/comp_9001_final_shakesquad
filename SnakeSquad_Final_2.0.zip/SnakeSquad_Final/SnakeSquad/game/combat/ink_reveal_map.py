"""Permanent projectile-driven reveals for a configurable lower map."""

from pathlib import Path

import pygame

from game import settings
from game.camera import Camera


class InkRevealMap:
    """Store permanent lower-layer reveals in a fixed-size world texture."""

    def __init__(self, world_size: tuple[int, int]) -> None:
        self._bottom_layer = self._create_bottom_layer(world_size)
        self._reveal_mask = pygame.Surface(world_size, pygame.SRCALPHA)
        self._reveal_mask.fill((255, 255, 255, 0))
        self._reveal_count = 0

    def reveal(self, position: pygame.Vector2) -> None:
        """Permanently open a circular area in the upper-map mask."""
        center = (round(position.x), round(position.y))
        radius = round(settings.FRIENDLY_INK_REVEAL_RADIUS)
        pygame.draw.circle(
            self._reveal_mask,
            (255, 255, 255, 255),
            center,
            radius,
        )
        self._reveal_count += 1

    def render(self, target: pygame.Surface, camera: Camera) -> None:
        """Draw revealed lower-map pixels between the ground and world objects."""
        offset_x = round(camera.offset.x)
        offset_y = round(camera.offset.y)
        visible_rect = pygame.Rect(
            offset_x,
            offset_y,
            target.get_width(),
            target.get_height(),
        ).clip(self._bottom_layer.get_rect())
        if visible_rect.width <= 0 or visible_rect.height <= 0:
            return

        revealed = self._bottom_layer.subsurface(visible_rect).copy()
        revealed.blit(
            self._reveal_mask.subsurface(visible_rect),
            (0, 0),
            special_flags=pygame.BLEND_RGBA_MULT,
        )
        target.blit(
            revealed,
            (visible_rect.x - offset_x, visible_rect.y - offset_y),
        )

    def is_revealed(self, position: pygame.Vector2) -> bool:
        """Return whether a world pixel has exposed the lower map layer."""
        x, y = round(position.x), round(position.y)
        if not (
            0 <= x < self._reveal_mask.get_width()
            and 0 <= y < self._reveal_mask.get_height()
        ):
            return False
        return self._reveal_mask.get_at((x, y)).a > 0

    def set_bottom_image(self, image_path: str | Path) -> None:
        """Replace the solid lower map with a PNG/JPG/BMP image."""
        loaded = pygame.image.load(str(image_path))
        self._bottom_layer = pygame.transform.smoothscale(
            loaded,
            self._bottom_layer.get_size(),
        )

    @staticmethod
    def _create_bottom_layer(world_size: tuple[int, int]) -> pygame.Surface:
        layer = pygame.Surface(world_size, pygame.SRCALPHA)
        layer.fill((*settings.FRIENDLY_INK_COLOR, 255))
        if settings.FRIENDLY_INK_MAP_IMAGE:
            image_path = Path(settings.FRIENDLY_INK_MAP_IMAGE)
            if not image_path.is_absolute():
                image_path = Path(__file__).resolve().parents[2] / image_path
            loaded = pygame.image.load(str(image_path))
            layer = pygame.transform.smoothscale(loaded, world_size)
        return layer

    @property
    def reveal_count(self) -> int:
        """Return the number of reveal stamps applied for diagnostics."""
        return self._reveal_count

    @property
    def storage_size(self) -> tuple[int, int]:
        """Return the fixed texture dimensions used for permanent storage."""
        return self._reveal_mask.get_size()
