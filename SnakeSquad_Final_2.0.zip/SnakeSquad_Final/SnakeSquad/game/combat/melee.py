"""Formation-2 melee kit: dash, three-hit combo, and dash attack.

Ported from the sephiria mechanics package (an original reimplementation of a
reverse-engineered behavior spec). The kit is only driven while the squad is
in the WING formation; formations 1 and 3 keep the original ranged controls.

Damage is delivered through the shared DamageInfo pipeline; visuals are
published through the attack_events hook list plus the fx pool so the art
layer can replace the primitive drawing later.
"""

from math import atan2, degrees, radians
from random import uniform

import pygame

from game import settings
from game.damage import DamageInfo
from game.factions import Faction


class MeleeKit:
    """Dash + combo state machine attached to the player (wing only)."""

    def __init__(self, player: object) -> None:
        self.player = player

        # Dash (spec section 2)
        self.used_dashes = 0
        self.dashing = False
        self.dash_dir = pygame.Vector2(1.0, 0.0)
        self.dash_speed = 0.0
        self.dash_timer = 0.0
        self.dash_traveled = 0.0
        self.dash_distance_multiplier = 1.0
        self.dash_distance_limit = 0.0
        self.dash_cooldown = 1.0
        self.invincible = 0.0
        self.dash_window = 0.0
        self.dash_cost_paid = True
        self.planned_dash_dist = 0.0
        self._ghost_timer = 0.0

        # Melee / dash attack (spec sections 3 and 4)
        self.attack: str | None = None
        self.attack_phase: str | None = None
        self.attack_timer = 0.0
        self.attack_dir = pygame.Vector2(1.0, 0.0)
        self.pending_mult = 1.0
        self.dash_atk_impulse = 0.0
        self.combo_idx = 0
        self.combo_buffered = False
        self.is_final_hit = False
        self.block_move = 0
        self.blade_angle = 0.0
        self.swing_trail: list[list] = []

        # Art hooks and effects
        self.attack_events: list[dict] = []
        self.events: list[str] = []
        self.fx: list[dict] = []
        self.shake = 0.0
        self.input_vec = pygame.Vector2()
        self.members: list = []

    # ---------------- queries ----------------
    @property
    def movement_active(self) -> bool:
        """Whether the kit owns the player velocity this frame.

        Only dashes and the dash-attack lunge own the velocity; ordinary
        melee attacks leave movement to the normal walk speed so melee and
        ranged movement feel identical.
        """
        if self.dashing:
            return True
        return (
            self.attack == "dash_attack"
            and self.dash_atk_impulse > 0.0
            and self.attack_phase in ("windup", "swing")
        )

    @property
    def stealth_active(self) -> bool:
        """Whether the dasher's body is hidden (exactly the i-frame window).

        The stealth duration IS the i-frame duration (both use
        MELEE_DASH_INVINCIBLE), so the body reappears before the dash ends.
        """
        return self.dashing and self.invincible > 0.0

    def dash_remaining(self) -> int:
        return settings.MELEE_MAX_DASH - self.used_dashes

    def melee_range_at(self, angle_deg: float) -> float:
        """Parabola reach: longest straight ahead, shrinking to the sides."""
        half = settings.MELEE_ARC / 2.0
        t = max(-1.0, min(1.0, angle_deg / half))
        return settings.MELEE_RANGE * (
            1.0 - settings.MELEE_RANGE_CURVE * t * t
        )

    def attack_range_at(self, angle_deg: float) -> float:
        if self.attack == "dash_attack":
            # 60-degree sector matching the sweep animation: the sword
            # covers the full reach across the whole arc and nothing
            # outside it.
            half = settings.MELEE_DASH_ATK_ARC / 2.0
            if abs(angle_deg) > half:
                return 0.0
            return settings.MELEE_DASH_ATK_RANGE
        return self.melee_range_at(angle_deg)

    def attack_arc(self) -> float:
        if self.attack == "dash_attack":
            return settings.MELEE_DASH_ATK_ARC
        return settings.MELEE_ARC

    @staticmethod
    def _signed_angle_deg(
        reference: pygame.Vector2, target: pygame.Vector2
    ) -> float:
        """Signed angle from reference to target in degrees, [-180, 180]."""
        delta = degrees(
            atan2(target.y, target.x) - atan2(reference.y, reference.x)
        )
        return (delta + 180.0) % 360.0 - 180.0

    def attack_color(self) -> tuple[int, int, int]:
        if self.attack == "dash_attack":
            return (255, 150, 80)
        return (110, 200, 255)

    def attack_alpha(self) -> int:
        if self.attack_phase == "windup":
            return 55
        if self.attack_phase == "swing":
            total = (
                settings.MELEE_DASH_ATK_SWING
                if self.attack == "dash_attack"
                else settings.MELEE_SWING
            )
            t = 1.0 - max(0.0, self.attack_timer / total)
            return int(55 + (1.0 - t) * 140)
        return 0

    # ---------------- lifecycle ----------------
    def reset(self) -> None:
        """Abort active actions; used whenever the wing formation is left."""
        self.dashing = False
        self.attack = None
        self.attack_phase = None
        self.attack_timer = 0.0
        self.combo_idx = 0
        self.combo_buffered = False
        self.is_final_hit = False
        self.block_move = 0
        self.dash_atk_impulse = 0.0
        self.dash_traveled = 0.0
        self.dash_distance_limit = 0.0
        self.swing_trail.clear()
        self.invincible = 0.0
        self.player.melee_invincible = 0.0
        for member in self.members:
            member.melee_invincible = 0.0

    def update(
        self,
        delta_time: float,
        move_direction: pygame.Vector2,
        aim_direction: pygame.Vector2,
        attack_pressed: bool,
        dash_pressed: bool,
        enemies: list,
        members: list | None = None,
    ) -> None:
        safe_delta = max(delta_time, 0.0)
        self.members = list(members) if members else []
        self.events.clear()
        self._decay(safe_delta)
        self.input_vec = pygame.Vector2(move_direction)

        # Attack input is buffered for the whole attack (spec section 3).
# Buffer attack input during a swing to queue the next combo hit.
        if attack_pressed:
            if self.attack == "melee" and self.attack_phase is not None:
                self.combo_buffered = True
            elif self.attack_phase is None:
                if self.dash_window > 0.0:
                    self._start_dash_attack(aim_direction)
                elif not self.dashing:
                    self._start_melee(aim_direction)

        if dash_pressed and self.attack_phase is None:
            self._try_dash(aim_direction)

        if self.dashing:
            self._dash_physics(safe_delta)

        self._dash_cooldown(safe_delta)

        if self.attack_phase is not None:
            self._attack_update(safe_delta, enemies)

        # Members dash with the leader but do not get the dash i-frames.
        for member in self.members:
            if getattr(member, "melee_invincible", 0.0) > 0.0:
                pass  # members never gain dash invincibility

        for fx in self.fx:
            fx["t"] += safe_delta
        self.fx = [f for f in self.fx if f["t"] < f["dur"]]
        self.shake = max(0.0, self.shake - safe_delta)
        if len(self.attack_events) > 500:
            del self.attack_events[: len(self.attack_events) - 500]

    # ---------------- dash ----------------
    def _try_dash(self, aim_direction: pygame.Vector2) -> None:
        if self.used_dashes >= settings.MELEE_MAX_DASH:
            self.events.append("dash_denied")
            return
        if self.dashing:
            return
        self.used_dashes += 1
        self.dash_cost_paid = True
        if self.input_vec.length_squared() > 0.01:
            self.dash_dir = self.input_vec.normalize()
        else:
            direction = pygame.Vector2(aim_direction)
            self.dash_dir = (
                direction.normalize()
                if direction.length_squared() > 0.0001
                else pygame.Vector2(1.0, 0.0)
            )
        self.dashing = True
        self.dash_speed = settings.MELEE_DASH_SPEED
        self.dash_timer = settings.MELEE_DASH_MAX_TIME
        self.dash_traveled = 0.0
        self._ghost_timer = 0.0
        full_time = min(
            settings.MELEE_DASH_SPEED / settings.MELEE_DASH_DECEL,
            settings.MELEE_DASH_MAX_TIME,
        )
        self.planned_dash_dist = (
            settings.MELEE_DASH_SPEED * full_time
            - 0.5 * settings.MELEE_DASH_DECEL * full_time * full_time
        )
        # Ranged dashes travel half the melee distance at the same speed:
        # the identical speed curve just stops at the shorter distance.
        self.dash_distance_limit = (
            self.planned_dash_dist * max(0.05, self.dash_distance_multiplier)
        )
        self.invincible = settings.MELEE_DASH_INVINCIBLE
        self.player.melee_invincible = self.invincible
        # The squad bursts along with the leader at half the distance,
        # without i-frames and without disappearing.
        squad_distance = self.dash_distance_limit * 0.5
        for member in self.members:
            if not getattr(member, "is_alive", False):
                continue
            start = getattr(member, "start_dash", None)
            if callable(start):
                start(
                    self.dash_dir,
                    settings.MELEE_DASH_SPEED,
                    settings.MELEE_DASH_MAX_TIME,
                    squad_distance,
                )
        self.dash_window = settings.MELEE_DASH_ATTACK_WINDOW
        self.events.append("dash")

    def _dash_physics(self, delta_time: float) -> None:
        # Dash is steerable: movement input overrides the direction.
        if self.input_vec.length_squared() > 0.01:
            self.dash_dir = self.input_vec.normalize()
        self.dash_speed = max(
            0.0, self.dash_speed - settings.MELEE_DASH_DECEL * delta_time
        )
        self.player.velocity = self.dash_dir * self.dash_speed
# Accumulate dash travel; ranged dashes stop early without changing speed.
        self.dash_traveled += self.dash_speed * delta_time
        self.dash_timer -= delta_time

        # Afterimages and white smoke on a fixed interval, for the whole
        # squad: every member dashes in sync with the player.
        self._ghost_timer -= delta_time
        if self._ghost_timer <= 0.0:
            self._ghost_timer = settings.MELEE_GHOST_INTERVAL
            units = [self.player]
            units.extend(
                member
                for member in self.members
                if getattr(member, "is_alive", False)
            )
            for unit in units:
                # dash circles (ghost rings) were removed on request
                offset = pygame.Vector2(
                    uniform(-6.0, 6.0), uniform(-6.0, 6.0)
                )
                self.fx.append({
                    "type": "smoke",
                    "pos": unit.position.copy() + offset,
                    "t": 0.0,
                    "dur": settings.MELEE_SMOKE_TIME,
                    "r": unit.radius * settings.MELEE_SMOKE_RATIO,
                })
        if (
            self.dash_speed <= 0.0
            or self.dash_timer <= 0.0
            or self.dash_traveled >= self.dash_distance_limit
        ):
            self.dashing = False
            self.player.velocity *= 0.2
            self.events.append("dash_end")

    def _dash_cooldown(self, delta_time: float) -> None:
        # Charges return one grid cell at a time.
        if self.used_dashes > 0:
            self.dash_cooldown -= delta_time / settings.MELEE_DASH_RECOVERY
            if self.dash_cooldown <= 0.0:
                self.used_dashes -= 1
                self.dash_cooldown = 1.0
                self.events.append("dash_recovered")
        else:
            self.dash_cooldown = 1.0

    # ---------------- melee combo / dash attack ----------------
    def _attack_direction(self, aim_direction: pygame.Vector2) -> pygame.Vector2:
        """Melee attacks point at the mouse, exactly like ranged attacks.

        The aim direction always wins while moving; the movement input is
        only a fallback for zero-length aims (e.g. synthetic tests).
        """
        direction = pygame.Vector2(aim_direction)
        if direction.length_squared() > 0.0001:
            return direction.normalize()
        if self.input_vec.length_squared() > 0.01:
            return self.input_vec.normalize()
        return pygame.Vector2(1.0, 0.0)

    def _combo_dur(self, which: int) -> float:
        seq = (
            settings.MELEE_COMBO_WINDUP,
            settings.MELEE_COMBO_SWING,
            settings.MELEE_COMBO_RECOVERY,
        )[which]
        index = min(self.combo_idx, settings.MELEE_COMBO_COUNT - 1)
        return seq[index] / settings.MELEE_ATTACK_SPEED

    def _start_melee(self, aim_direction: pygame.Vector2) -> None:
        self.attack = "melee"
        self.combo_idx = 0
        self.combo_buffered = False
        self._begin_combo_hit(aim_direction)

    def _begin_combo_hit(self, aim_direction: pygame.Vector2) -> None:
        self.attack_phase = "windup"
        self.attack_timer = self._combo_dur(0)
        self.attack_dir = self._attack_direction(aim_direction)
        self.block_move += 1
        self.swing_trail.clear()
        self.blade_angle = -radians(self.attack_arc() * 0.55)
        self.is_final_hit = self.combo_idx == settings.MELEE_COMBO_COUNT - 1
        self.events.append(
            ("final " if self.is_final_hit else "")
            + "combo %d" % (self.combo_idx + 1)
        )
        self.attack_events.append({
            "name": "attack_start",
            "index": self.combo_idx + 1,
            "final": self.is_final_hit,
            "dir": (self.attack_dir.x, self.attack_dir.y),
        })

    def _start_dash_attack(self, aim_direction: pygame.Vector2) -> None:
        # StopDash, then a straight displacement pulse, then the swing.
        self.dashing = False
        self.player.velocity *= 0.3
        self.combo_idx = 0
        self.combo_buffered = False
        self.is_final_hit = False
        self.attack_events.append({"name": "dash_attack_start", "dir": None})
        cost_paid = self.dash_cost_paid
        self.dash_cost_paid = True
        self.attack = "dash_attack"
        self.attack_phase = "windup"
        self.attack_timer = settings.MELEE_DASH_ATK_WINDUP
        self.attack_dir = self._attack_direction(aim_direction)
        self.block_move += 1
        self.pending_mult = (
            1.0 if cost_paid else settings.MELEE_DASH_ATK_MULT_NOCOST
        )
        self.dash_window = 0.0
        distance = self.planned_dash_dist * settings.MELEE_DASH_ATK_DIST_MULT
        self.dash_atk_impulse = distance / settings.MELEE_DASH_ATK_IMPULSE
        self.swing_trail.clear()
        self.blade_angle = -radians(self.attack_arc() * 0.55)
        self.events.append("dash_attack" + ("" if cost_paid else "_nocost"))

    def _attack_update(self, delta_time: float, enemies: list) -> None:
        self.attack_timer -= delta_time
        arc_rad = radians(self.attack_arc())

        if self.attack_phase == "windup":
            self.blade_angle = -arc_rad * 0.55
        elif self.attack_phase == "swing":
            total = (
                self._combo_dur(1)
                if self.attack == "melee"
                else settings.MELEE_DASH_ATK_SWING
            )
            t = 1.0 - max(0.0, self.attack_timer / total)
            self.blade_angle = arc_rad * (t - 0.5)
            self.swing_trail.append([
                self.blade_angle,
                self.attack_dir.copy(),
                self.player.position.copy(),
                1.0,
            ])
        for segment in self.swing_trail:
            segment[3] -= delta_time / settings.MELEE_SWING_TRAIL_TIME
        self.swing_trail = [s for s in self.swing_trail if s[3] > 0]
        if len(self.swing_trail) > settings.MELEE_SWING_TRAIL_SEGS:
            self.swing_trail = self.swing_trail[
                -settings.MELEE_SWING_TRAIL_SEGS:
            ]

        if self.attack_phase == "windup" and self.attack_timer <= 0.0:
            self.attack_phase = "swing"
            self.attack_timer = (
                self._combo_dur(1)
                if self.attack == "melee"
                else settings.MELEE_DASH_ATK_SWING
            )
            self._do_swing(enemies)
        elif self.attack_phase == "swing" and self.attack_timer <= 0.0:
            self.attack_phase = "recovery"
            self.attack_timer = (
                self._combo_dur(2)
                if self.attack == "melee"
                else settings.MELEE_DASH_ATK_RECOVERY
            )
        elif self.attack_phase == "recovery" and self.attack_timer <= 0.0:
            # Each finished segment releases one movement-lock layer; a
            # buffered input chains the next segment (which re-adds one).
            self.block_move = max(0, self.block_move - 1)
            if (
                self.attack == "melee"
                and self.combo_buffered
                and self.combo_idx < settings.MELEE_COMBO_COUNT - 1
            ):
                self.combo_idx += 1
                self.combo_buffered = False
                self._begin_combo_hit(self.attack_dir)
            else:
                self.attack_phase = None
                self.combo_idx = 0
                self.combo_buffered = False
                self.events.append("attack_end")
                self.attack_events.append({"name": "attack_end"})

        # Movement while attacking: dash attack pulses forward, melee slides.
        if self.attack == "dash_attack":
            self.dash_atk_impulse -= delta_time
            if (
                self.dash_atk_impulse > 0.0
                and self.attack_phase in ("windup", "swing"),
            ):
                self.player.velocity = (
                    self.attack_dir * settings.MELEE_DASH_ATK_IMPULSE
                )
            elif self.attack_phase == "recovery":
                self.player.velocity *= 0.85
        else:
            if self.input_vec.length_squared() > 0.000001:
                self.player.velocity = (
                    self.input_vec.normalize()
                    * self.player.move_speed
                    * settings.MELEE_ATTACK_MOVE_MULT
                )
            else:
                self.player.velocity *= 0.90

    def _do_swing(self, enemies: list) -> None:
        """Resolve one swing frame for the player and every squad member."""
        if self.attack == "melee":
            mult = settings.MELEE_COMBO_DAMAGE_MULT[
                min(self.combo_idx, settings.MELEE_COMBO_COUNT - 1)
            ]
            damage = settings.MELEE_DAMAGE * mult
            rng = settings.MELEE_RANGE
            arc = settings.MELEE_ARC
            if self.is_final_hit:
                rng *= settings.MELEE_FINAL_HIT_RANGE_MULT
            color = (255, 200, 110) if self.is_final_hit else (110, 200, 255)
            shape = "parabola"
        else:
            damage = settings.MELEE_DASH_ATK_DAMAGE * self.pending_mult
            rng = settings.MELEE_DASH_ATK_RANGE
            arc = settings.MELEE_DASH_ATK_ARC
            color = (255, 150, 80)
            shape = "sector"

        fx_scale = settings.MELEE_FINAL_HIT_FX_SCALE if self.is_final_hit else 1.0

        # In formation 2 every squad member has the same melee ability as
        # the player: the swing resolves once per attacker with identical
        # stats, range shape, and direction.
        attackers: list[tuple] = []
        if getattr(self.player, "is_alive", True):
            attackers.append((self.player, Faction.PLAYER, "player"))
        for index, member in enumerate(self.members):
            if getattr(member, "is_alive", False):
                attackers.append(
                    (member, Faction.PLAYER_SQUAD, "member%d" % (index + 1))
                )

        def attack_origin(attacker) -> pygame.Vector2:
            """The protagonist swings from the weapon hand; members center."""
            if attacker is self.player:
                origin = getattr(attacker, "attack_origin", None)
                if callable(origin):
                    return origin()
            return attacker.position

        for attacker, _faction, _label in attackers:
            self.fx.append({
                "type": "slash",
                "pos": pygame.Vector2(attack_origin(attacker)),
                "dir": self.attack_dir.copy(),
                "range": rng * fx_scale,
                "arc": arc,
                "t": 0.0,
                "dur": settings.MELEE_SLASH_FX_TIME,
                "color": color,
                "shape": shape,
                "final": self.is_final_hit,
            })
        self.shake = settings.MELEE_SHAKE_TIME

# Resolve each attacker's damage independently, including the protagonist multiplier.
        for attacker, faction, label in attackers:
            # The protagonist deals doubled melee damage.
            attacker_damage = damage * (
                settings.PLAYER_DAMAGE_MULTIPLIER
                if attacker is self.player
                else 1.0
            )
            for enemy in tuple(enemies):
                if not getattr(enemy, "is_alive", False):
                    continue
                to_enemy = enemy.position - attack_origin(attacker)
                # atan2-based signed angle: pygame's Vector2.angle_to returns
                # unreliable values on some inputs (observed 1044 degrees).
                angle = self._signed_angle_deg(self.attack_dir, to_enemy)
                if abs(angle) > arc / 2.0:
                    continue
                reach = self.attack_range_at(angle) + enemy.radius
                if to_enemy.length() > reach:
                    continue
                enemy.receive_damage(
                    DamageInfo(
                        round(attacker_damage),
                        attacker,
                        faction,
                        enemy.position.copy(),
                        "melee",
                    )
                )
                self.fx.append({
                    "type": "spark",
                    "pos": enemy.position.copy(),
                    "t": 0.0,
                    "dur": settings.MELEE_SPARK_TIME,
                    "r": 7,
                    "color": (255, 240, 150),
                })
                self.events.append("hit %.0f" % attacker_damage)
                self.attack_events.append({
                    "name": "hit",
                    "index": self.combo_idx + 1 if self.attack == "melee" else 0,
                    "final": self.is_final_hit,
                    "damage": round(attacker_damage, 1),
                    "attacker": label,
                })

    # ---------------- timers ----------------
    def _decay(self, delta_time: float) -> None:
        self.invincible = max(0.0, self.invincible - delta_time)
        self.player.melee_invincible = self.invincible
        self.dash_window = max(0.0, self.dash_window - delta_time)