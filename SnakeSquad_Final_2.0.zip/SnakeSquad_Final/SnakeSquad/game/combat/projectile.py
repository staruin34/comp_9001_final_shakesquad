"""Reusable moving projectile data and behavior."""

from dataclasses import dataclass, field
from typing import Any

import pygame

from game.factions import Faction


@dataclass
class Projectile:
    """A pooled projectile that can be activated many times."""

    position: pygame.Vector2 = field(default_factory=pygame.Vector2)
    direction: pygame.Vector2 = field(
        default_factory=lambda: pygame.Vector2(1.0, 0.0)
    )
    speed: float = 0.0
    damage: int = 0
    lifetime: float = 0.0
    radius: float = 3.0
    owner: Any | None = None
    owner_faction: Faction = Faction.NEUTRAL
    active: bool = False
    distance_traveled: float = 0.0
    next_ink_distance: float = 0.0
    ink_reveal_distance: float = 0.0

    def activate(
        self,
        position: pygame.Vector2,
        direction: pygame.Vector2,
        speed: float,
        damage: int,
        lifetime: float,
        radius: float,
        owner: Any,
        owner_faction: Faction,
        ink_reveal_distance: float = 0.0,
    ) -> None:
        """Initialize this projectile for one shot."""
        self.position = pygame.Vector2(position)
        self.direction = direction.normalize()
        self.speed = speed
        self.damage = damage
        self.lifetime = lifetime
        self.radius = radius
        self.owner = owner
        self.owner_faction = owner_faction
        self.distance_traveled = 0.0
        self.next_ink_distance = 0.0
        self.ink_reveal_distance = max(0.0, ink_reveal_distance)
        self.active = True

    def update(self, delta_time: float, world_bounds: pygame.Rect) -> None:
        """Move and expire the projectile without performing collision."""
        if not self.active:
            return
        movement_distance = self.speed * max(delta_time, 0.0)
        self.position += self.direction * movement_distance
        self.distance_traveled += movement_distance
        self.lifetime -= delta_time
        if self.lifetime <= 0.0 or not world_bounds.collidepoint(self.position):
            self.active = False

    def deactivate(self) -> None:
        """Make the projectile available for pool reuse."""
        self.active = False
        self.owner = None
