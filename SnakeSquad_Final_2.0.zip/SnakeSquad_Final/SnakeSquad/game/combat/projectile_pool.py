"""Bounded-reuse projectile storage and collision processing."""

from collections.abc import Sequence

import pygame

from game import assets, settings
from game.camera import Camera
from game.combat.ink_reveal_map import InkRevealMap
from game.combat.projectile import Projectile
from game.combat.target_scanner import Targetable
from game.damage import DamageInfo
from game.factions import Faction, is_hostile

class ProjectilePool:
    """Reuse inactive projectiles instead of allocating every shot."""

    def __init__(self, initial_size: int = 64) -> None:
        self._projectiles = [Projectile() for _ in range(initial_size)]
        self.ink_map = InkRevealMap(
            (settings.WORLD_WIDTH, settings.WORLD_HEIGHT)
        )

    def acquire(self) -> Projectile:
        """Return an inactive projectile, growing only when all are active."""
        for projectile in self._projectiles:
            if not projectile.active:
                return projectile
        projectile = Projectile()
        self._projectiles.append(projectile)
        return projectile

    def release(self, projectile: Projectile) -> None:
        """Deactivate a projectile for later reuse."""
        projectile.deactivate()

    def update(
        self,
        delta_time: float,
        world_bounds: pygame.Rect,
        targets: Sequence[Targetable],
        walls: Sequence[pygame.Rect] = (),
    ) -> None:
        """Move active shots, stop them at walls, then resolve one hit."""
        for projectile in self._projectiles:
            if not projectile.active:
                continue
            previous_position = projectile.position.copy()
            previous_distance = projectile.distance_traveled
            projectile.update(delta_time, world_bounds)
            self._emit_friendly_ink(
                projectile,
                previous_position,
                previous_distance,
            )
            if not projectile.active:
                self.release(projectile)
                continue
# Destroy projectiles on wall contact so they cannot hit targets behind walls.
            if walls and self._hits_wall(projectile, walls):
                self.release(projectile)
                continue

            for target in tuple(targets):
                if target is projectile.owner or not target.is_alive:
                    continue
                if not is_hostile(projectile.owner_faction, target.faction):
                    continue
                radius_sum = projectile.radius + target.radius
                if projectile.position.distance_squared_to(target.position) > (
                    radius_sum * radius_sum
                ):
                    continue
                receive_damage = getattr(target, "receive_damage", None)
                if callable(receive_damage):
                    receive_damage(
                        DamageInfo(
                            projectile.damage,
                            projectile.owner,
                            projectile.owner_faction,
                            projectile.position.copy(),
                            "projectile",
                        )
                    )
                else:
                    receive_hit = getattr(target, "receive_projectile_hit", None)
                    if callable(receive_hit):
                        receive_hit(projectile.damage)
                self.release(projectile)
                break

    @staticmethod
    def _hits_wall(
        projectile: Projectile, walls: Sequence[pygame.Rect]
    ) -> bool:
        """Return whether the projectile circle overlaps any wall rect."""
        radius = projectile.radius
        position = projectile.position
        for rect in walls:
            closest_x = min(max(position.x, rect.left), rect.right)
            closest_y = min(max(position.y, rect.top), rect.bottom)
            dx = position.x - closest_x
            dy = position.y - closest_y
            if dx * dx + dy * dy <= radius * radius:
                return True
        return False

    def render(self, surface: pygame.Surface, camera: Camera) -> None:
        """Draw every active projectile in screen coordinates."""
        for projectile in self._projectiles:
            if not projectile.active:
                continue
            screen_position = camera.world_to_screen(projectile.position)
            center = (round(screen_position.x), round(screen_position.y))
            kind = (
                "bullet_enemy"
                if projectile.owner_faction is Faction.ENEMY
                else "bullet_friendly"
            )
            sprite = assets.bullet(kind, round(projectile.radius * 2))
            if sprite is None:
                color = (
                    settings.ELITE_BARRAGE_BULLET_COLOR
                    if projectile.owner_faction is Faction.ENEMY
                    else settings.PROJECTILE_COLOR
                )
                pygame.draw.circle(
                    surface, color, center, round(projectile.radius)
                )
                continue
            angle = -pygame.math.Vector2(projectile.direction).angle_to(
                pygame.Vector2(1.0, 0.0)
            )
            rotated = pygame.transform.rotate(sprite, angle)
            surface.blit(rotated, rotated.get_rect(center=center))

    @property
    def active_count(self) -> int:
        """Return the number of projectiles currently in flight."""
        return sum(projectile.active for projectile in self._projectiles)

    @property
    def capacity(self) -> int:
        """Return the number of reusable projectile instances."""
        return len(self._projectiles)

    def active_projectiles(self) -> tuple[Projectile, ...]:
        """Return active shots for read-only diagnostics and tests."""
        return tuple(
            projectile
            for projectile in self._projectiles
            if projectile.active
        )

    @property
    def ink_reveal_count(self) -> int:
        """Return the number of permanent lower-layer reveal stamps."""
        return self.ink_map.reveal_count

    def render_ink_layer(self, surface: pygame.Surface, camera: Camera) -> None:
        """Render permanent reveals before grid lines and entities."""
        self.ink_map.render(surface, camera)

    def _emit_friendly_ink(
        self,
        projectile: Projectile,
        previous_position: pygame.Vector2,
        previous_distance: float,
    ) -> None:
        if projectile.owner_faction not in (
            Faction.PLAYER,
            Faction.PLAYER_SQUAD,
        ):
            return

        trail_end = min(
            projectile.distance_traveled,
            projectile.ink_reveal_distance,
        )
        segment_distance = projectile.distance_traveled - previous_distance
        while projectile.next_ink_distance <= trail_end:
            if segment_distance > 0.0:
                fraction = (
                    projectile.next_ink_distance - previous_distance
                ) / segment_distance
                fraction = max(0.0, min(1.0, fraction))
                position = previous_position.lerp(projectile.position, fraction)
            else:
                position = previous_position.copy()
            self.ink_map.reveal(position)
            projectile.next_ink_distance += settings.FRIENDLY_INK_MARK_SPACING
