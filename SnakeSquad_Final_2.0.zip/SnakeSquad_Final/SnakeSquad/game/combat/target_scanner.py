"""Interval-based nearest-hostile target selection."""

from typing import Protocol, Sequence

import pygame

from game.factions import Faction, is_hostile


class Targetable(Protocol):
    """Minimal interface required by scanners and projectiles."""

    position: pygame.Vector2
    radius: float
    faction: Faction

    @property
    def is_alive(self) -> bool: ...


class TargetScanner:
    """Retain the nearest valid hostile and rescan at a fixed interval."""

    def __init__(self, scan_range: float, scan_interval: float) -> None:
        self.scan_range = scan_range
        self.scan_interval = scan_interval
        self.current_target: Targetable | None = None
        self._time_until_scan = 0.0

    def update(
        self,
        source_position: pygame.Vector2,
        source_faction: Faction,
        candidates: Sequence[Targetable],
        delta_time: float,
    ) -> Targetable | None:
        """Validate the current target and periodically select the nearest."""
        self._time_until_scan -= max(delta_time, 0.0)
        if not self._is_valid(
            self.current_target,
            source_position,
            source_faction,
        ):
            self.current_target = None
            self._time_until_scan = 0.0

        if self._time_until_scan > 0.0:
            return self.current_target

        self._time_until_scan = self.scan_interval
        range_squared = self.scan_range * self.scan_range
        nearest_distance = range_squared
        nearest: Targetable | None = None

        for candidate in tuple(candidates):
            if not candidate.is_alive or not is_hostile(
                source_faction,
                candidate.faction,
            ):
                continue
            distance_squared = source_position.distance_squared_to(
                candidate.position
            )
            if distance_squared <= nearest_distance:
                nearest_distance = distance_squared
                nearest = candidate

        self.current_target = nearest
        return nearest

    def clear(self) -> None:
        """Discard a retained target immediately."""
        self.current_target = None
        self._time_until_scan = 0.0

    def _is_valid(
        self,
        target: Targetable | None,
        source_position: pygame.Vector2,
        source_faction: Faction,
    ) -> bool:
        if target is None or not target.is_alive:
            return False
        if not is_hostile(source_faction, target.faction):
            return False
        return source_position.distance_squared_to(target.position) <= (
            self.scan_range * self.scan_range
        )
