"""Single unified squad weapon (medium machine-gun style bullet)."""

from dataclasses import dataclass

import pygame

from game import settings
from game.combat.projectile_pool import ProjectilePool
from game.combat.target_scanner import Targetable
from game.entities.base_entity import BaseEntity


@dataclass
class Weapon:
    """Fire the one unified bullet profile defined in settings.

    The three selectable weapons (rifle / SMG / heavy) were merged into a
    single bullet: size PROJECTILE_RADIUS, fire rate PROJECTILE_FIRE_INTERVAL
    (SMG rate), range PROJECTILE_ATTACK_RANGE (default), and damage
    PROJECTILE_DAMAGE (medium machine gun).
    """

    attack_range: float = settings.PROJECTILE_ATTACK_RANGE
    fire_interval: float = settings.PROJECTILE_FIRE_INTERVAL
    projectile_speed: float = settings.PROJECTILE_SPEED
    projectile_damage: int = settings.PROJECTILE_DAMAGE
    projectile_lifetime: float = settings.PROJECTILE_LIFETIME
    projectile_radius: float = settings.PROJECTILE_RADIUS
    cooldown: float = 0.0

    def update(self, delta_time: float) -> None:
        """Advance the weapon cooldown."""
        self.cooldown = max(0.0, self.cooldown - max(delta_time, 0.0))

    def try_fire(
        self,
        owner: BaseEntity,
        target: Targetable,
        pool: ProjectilePool,
    ) -> bool:
        """Fire toward a living in-range target when cooldown permits."""
        if self.cooldown > 0.0 or not target.is_alive:
            return False
        difference = target.position - owner.position
        distance_squared = difference.length_squared()
        if distance_squared <= 0.000001 or distance_squared > self.attack_range**2:
            return False

        direction = difference.normalize()
        muzzle = owner.position + direction * (owner.radius + 6.0)
        projectile = pool.acquire()
        projectile.activate(
            muzzle,
            direction,
            self.projectile_speed,
            self.projectile_damage,
            self.projectile_lifetime,
            self.projectile_radius,
            owner,
            owner.faction,
            self.attack_range,
        )
        self.cooldown = self.fire_interval
        return True

    def try_fire_direction(
        self,
        owner: BaseEntity,
        direction: pygame.Vector2,
        pool: ProjectilePool,
    ) -> bool:
        """Fire along an explicit aim direction when cooldown permits."""
        if self.cooldown > 0.0 or direction.length_squared() <= 0.000001:
            return False

        safe_direction = direction.normalize()
        # fire from the weapon pivot (the hand), not the body centre
        # Spawn projectiles at the weapon's hand-grip pivot instead of the body centre.
        origin = getattr(owner, "attack_origin", None)
        base_position = origin() if callable(origin) else owner.position
        muzzle = pygame.Vector2(base_position) + safe_direction * 6.0
        projectile = pool.acquire()
        projectile.activate(
            muzzle,
            safe_direction,
            self.projectile_speed,
            self.projectile_damage,
            self.projectile_lifetime,
            self.projectile_radius,
            owner,
            owner.faction,
            self.attack_range,
        )
        self.cooldown = self.fire_interval
        return True
