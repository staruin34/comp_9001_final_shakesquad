"""Shared immutable description of one damage event."""

from dataclasses import dataclass, field
from typing import Any

import pygame

from game.factions import Faction


@dataclass(frozen=True)
class DamageInfo:
    """Carry damage amount, ownership, faction, position, and type."""

    amount: int
    attacker: Any | None
    attacker_faction: Faction
    hit_position: pygame.Vector2 = field(default_factory=pygame.Vector2)
    damage_type: str = "projectile"
