"""World entity package.

Entity classes are imported from their defining modules to avoid eager
cross-package imports during application startup.
"""
