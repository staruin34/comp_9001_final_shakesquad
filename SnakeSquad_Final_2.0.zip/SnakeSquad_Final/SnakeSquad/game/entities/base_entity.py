"""Shared spatial data for world entities."""

from dataclasses import dataclass, field

import pygame

from game.factions import Faction


@dataclass
class BaseEntity:
    """Store the world-space position and collision radius of an entity."""

    position: pygame.Vector2 = field(default_factory=pygame.Vector2)
    radius: float = 1.0
    faction: Faction = Faction.NEUTRAL

    @property
    def is_alive(self) -> bool:
        """Return whether this entity can currently be targeted."""
        return True

    def clamp_to_bounds(self, bounds: pygame.Rect) -> None:
        """Keep the entity's collision circle fully inside world bounds."""
        self.position.x = max(
            bounds.left + self.radius,
            min(self.position.x, bounds.right - self.radius),
        )
        self.position.y = max(
            bounds.top + self.radius,
            min(self.position.y, bounds.bottom - self.radius),
        )
