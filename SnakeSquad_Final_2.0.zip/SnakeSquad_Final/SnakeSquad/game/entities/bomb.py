"""Explosive thrown by elite enemies: fly, land, blink, explode."""

from dataclasses import dataclass, field

import pygame

from game import settings
from game.damage import DamageInfo
from game.factions import Faction, is_hostile


@dataclass
class Bomb:
    """A thrown bomb that travels its range, waits, then blasts a circle."""

    position: pygame.Vector2
    direction: pygame.Vector2
    owner: object
    origin: pygame.Vector2
    radius: float = settings.ELITE_BOMB_RADIUS
    travel_remaining: float = settings.ELITE_BOMB_THROW_DISTANCE
    fuse: float = settings.ELITE_BOMB_FUSE_TIME
    landed: bool = False
    exploded: bool = False
    explosion_timer: float = 0.0
    age: float = 0.0
    hit_count: int = field(default=0)

    @property
    def landing(self) -> pygame.Vector2:
        """Where this bomb will come to rest."""
        return self.origin + self.direction * settings.ELITE_BOMB_THROW_DISTANCE

    @property
    def show_trajectory(self) -> bool:
        """The red trajectory line disappears once the bomb lands."""
        return not self.landed and not self.exploded

    @property
    def finished(self) -> bool:
        """True once the explosion effect has played out."""
        return self.exploded and self.explosion_timer <= 0.0

    def update(self, delta_time: float, targets) -> None:
        """Advance flight, fuse and explosion; resolve blast damage once."""
        safe_delta = max(delta_time, 0.0)
        self.age += safe_delta
        if self.exploded:
            self.explosion_timer -= safe_delta
            return
# Fly at a constant speed and land after travelling the configured range.
        if not self.landed:
            step = min(
                self.travel_remaining,
                settings.ELITE_BOMB_THROW_SPEED * safe_delta,
            )
            self.position += self.direction * step
            self.travel_remaining -= step
            if self.travel_remaining <= 0.0001:
                self.landed = True
                self.position = self.landing.copy()
            return
        # Count down the fuse after landing, then explode.
        self.fuse -= safe_delta
        if self.fuse <= 0.0:
            self.explode(targets)

    def explode(self, targets) -> None:
        """Damage every hostile target inside the blast circle, once."""
        if self.exploded:
            return
        self.exploded = True
        self.fuse = 0.0
        self.explosion_timer = settings.ELITE_BOMB_EXPLOSION_TIME
        for target in tuple(targets):
            if not getattr(target, "is_alive", False):
                continue
            faction = getattr(target, "faction", Faction.NEUTRAL)
            if not is_hostile(Faction.ENEMY, faction):
                continue
            target_position = getattr(target, "position", None)
            if target_position is None:
                continue
            reach = settings.ELITE_BOMB_EXPLODE_RADIUS + getattr(
                target, "radius", 0.0
            )
            if self.position.distance_to(target_position) > reach:
                continue
            receive = getattr(target, "receive_damage", None)
            if callable(receive):
                receive(
                    DamageInfo(
                        settings.ELITE_BOMB_EXPLODE_DAMAGE,
                        self.owner,
                        Faction.ENEMY,
                        self.position.copy(),
                        "explosion",
                    )
                )
                self.hit_count += 1

    def blink_alpha(self) -> int:
        """Blink faster as the fuse burns down (steady while flying)."""
        if not self.landed or self.exploded:
            return 255
        ratio = max(0.0, min(1.0, self.fuse / settings.ELITE_BOMB_FUSE_TIME))
        period = 0.18 + 0.5 * ratio
        phase = (self.age / period) % 1.0
        return 255 if phase < 0.55 else 70
