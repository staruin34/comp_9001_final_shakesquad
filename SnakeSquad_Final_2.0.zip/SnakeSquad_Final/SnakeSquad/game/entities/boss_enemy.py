"""Level-three boss with full-map player tracking and triple-ring barrages."""

from dataclasses import dataclass, field
from collections.abc import Sequence

import pygame

from game import assets, settings
from game.camera import Camera
from game.combat.boss_barrage import BossBarrage
from game.combat.health import Health
from game.combat.target_scanner import Targetable
from game.entities.enemy import Enemy, EnemyState
from game.ui.health_bar import draw_health_bar


@dataclass
class BossEnemy(Enemy):
    """A large enemy that ignores scan range and always follows the player."""

    radius: float = settings.BOSS_RADIUS
    move_speed: float = settings.BOSS_MOVE_SPEED
    attack_range: float = settings.BOSS_ATTACK_RANGE
    attack_damage: int = settings.BOSS_MELEE_DAMAGE
    health: Health = field(default_factory=lambda: Health(settings.BOSS_MAX_HEALTH))
    barrage_cooldown: float = settings.BOSS_BARRAGE_INTERVAL

    def update(
        self,
        delta_time: float,
        candidates: Sequence[Targetable],
        other_enemies: Sequence[Enemy],
        world_bounds: pygame.Rect,
    ) -> None:
        """Chase the player across the entire map without scanner range limits."""
        del other_enemies
        if not self.is_alive:
            self.state = EnemyState.DEAD
            self.velocity.update(0.0, 0.0)
            return
        self.attack_cooldown = max(0.0, self.attack_cooldown - max(delta_time, 0.0))
        target = candidates[0] if candidates and candidates[0].is_alive else None
        if target is None:
            self.velocity.update(0.0, 0.0)
            return
        difference = target.position - self.position
        distance = difference.length()
        if distance > 0.0001:
            self.aim_direction = difference / distance
        if distance <= self.attack_range:
            self.state = EnemyState.ATTACK
            self.velocity.update(0.0, 0.0)
            self._try_attack(target)
            return
        self.state = EnemyState.CHASE
        travel = min(
            self.move_speed * max(delta_time, 0.0),
            max(0.0, distance - self.attack_range),
        )
        self.position += self.aim_direction * travel
        self.velocity = self.aim_direction * (travel / delta_time) if delta_time > 0 else pygame.Vector2()
        self.clamp_to_bounds(world_bounds)

    def update_barrage(
        self,
        delta_time: float,
        player_position: pygame.Vector2,
        barrage: BossBarrage,
        iron_balls=None,
    ) -> None:
        """Fires volleys; every third volley launches three iron balls."""
        if not self.is_alive:
            return
        self.barrage_cooldown -= max(delta_time, 0.0)
        while self.barrage_cooldown <= 0.0:
            self.barrage_cooldown += settings.BOSS_BARRAGE_INTERVAL
# Every third barrage becomes an empowered attack with three iron-ball directions.
            if barrage.next_volley_is_empowered():
                if iron_balls is not None:
                    for direction in barrage.volley_directions(
                        self.position, player_position
                    ):
                        iron_balls.spawn(self.position, direction, self)
                continue
            barrage.spawn_three_rings(self.position, player_position, self)

    def _sprite(self) -> pygame.Surface | None:
        """Return the boss animation frame (run while moving)."""
        state = "run" if self.velocity.length_squared() > 1.0 else "idle"
        count = assets.frame_count("boss", state)
        if count == 0:
            return None
        frame_ms = max(1, int(1000 / assets.fps("boss", state)))
        index = (pygame.time.get_ticks() // frame_ms) % count
        return assets.frame("boss", state, index)

    def render(self, surface: pygame.Surface, camera: Camera) -> None:
        screen_position = camera.world_to_screen(self.position)
        center = (round(screen_position.x), round(screen_position.y))
        sprite = self._sprite() if self.is_alive else assets.frame("boss", "die", 0)
        if sprite is not None and not self.is_alive:
            width = max(1, round(sprite.get_width() * 0.8))
            height = max(1, round(sprite.get_height() * 0.8))
            sprite = pygame.transform.scale(sprite, (width, height))
        if sprite is not None:
            if self.aim_direction.x < -0.001:
                sprite = pygame.transform.flip(sprite, True, False)
            if self.is_alive:
                surface.blit(sprite, sprite.get_rect(center=center))
            else:
                surface.blit(
                    sprite,
                    sprite.get_rect(
                        midbottom=(
                            center[0],
                            center[1] + round(self.radius),
                        )
                    ),
                )
            draw_health_bar(
                surface, screen_position, self.health, 100, self.radius + 10
            )
            return
        color = settings.SQUAD_DEAD_COLOR if not self.is_alive else settings.BOSS_COLOR
        pygame.draw.circle(surface, color, center, round(self.radius))
        pygame.draw.circle(surface, settings.BOSS_INNER_COLOR, center, round(self.radius * 0.62))
        pygame.draw.circle(
            surface,
            settings.BOSS_OUTLINE_COLOR,
            center,
            round(self.radius),
            5,
        )
        draw_health_bar(surface, screen_position, self.health, 100, self.radius + 10)
