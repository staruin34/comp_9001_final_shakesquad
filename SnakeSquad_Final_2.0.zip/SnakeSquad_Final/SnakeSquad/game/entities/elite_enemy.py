"""Pure-color elite enemy with a timed permanent radial barrage."""

from dataclasses import dataclass, field

import pygame

from game import assets, settings
from game.camera import Camera
from game.combat.elite_barrage import EliteBarrage
from game.combat.health import Health
from game.entities.enemy import Enemy, EnemyState
from game.ui.health_bar import draw_health_bar


@dataclass
class EliteEnemy(Enemy):
    """A faster, tougher enemy that emits a radial ring every six seconds."""

    radius: float = settings.ELITE_ENEMY_RADIUS
    move_speed: float = settings.ELITE_ENEMY_MOVE_SPEED
    health: Health = field(
        default_factory=lambda: Health(settings.ELITE_ENEMY_MAX_HEALTH)
    )
    barrage_cooldown: float = settings.ELITE_BARRAGE_INTERVAL
    bomb_cooldown: float = settings.ELITE_BOMB_INTERVAL
    bomb_throws: int = 0

    def update_barrage(
        self,
        delta_time: float,
        player_position: pygame.Vector2,
        barrage: EliteBarrage,
    ) -> None:
        """Emit complete rings at a stable six-second cadence while alive."""
        if not self.is_alive:
            return
        self.barrage_cooldown -= max(delta_time, 0.0)
        while self.barrage_cooldown <= 0.0:
            barrage.spawn_ring(self.position, player_position, self)
            self.barrage_cooldown += settings.ELITE_BARRAGE_INTERVAL

    def update_bombs(
        self,
        delta_time: float,
        player_position: pygame.Vector2,
        bombs,
    ) -> None:
        """Throw a bomb every interval; every 4th throw is a 3-way spread."""
        if not self.is_alive:
            return
        self.bomb_cooldown -= max(delta_time, 0.0)
        while self.bomb_cooldown <= 0.0:
            self.bomb_cooldown += settings.ELITE_BOMB_INTERVAL
            heading = pygame.Vector2(player_position) - self.position
            if heading.length_squared() <= 0.000001:
                heading = pygame.Vector2(1.0, 0.0)
            heading = heading.normalize()
            self.bomb_throws += 1
# Every fourth throw launches three bombs: forward and 30 degrees to either side.
            if self.bomb_throws % settings.ELITE_BOMB_EMPOWER_EVERY == 0:
                # empowered throw: forward plus left/right 30 degrees
                spread = settings.ELITE_BOMB_SPREAD_DEG
                for offset in (-spread, 0.0, spread):
                    bombs.throw(self.position, heading.rotate(offset), self)
                self.bomb_throws = 0
            else:
                bombs.throw(self.position, heading, self)

    def _sprite(self) -> pygame.Surface | None:
        """Return the elite animation frame (run while moving)."""
        state = "run" if self.velocity.length_squared() > 1.0 else "idle"
        count = assets.frame_count("elite", state)
        if count == 0:
            return None
        frame_ms = max(1, int(1000 / assets.fps("elite", state)))
        index = (pygame.time.get_ticks() // frame_ms) % count
        return assets.frame("elite", state, index)

    def render(self, surface: pygame.Surface, camera: Camera) -> None:
        """Draw the elite sprite (bomb carrier) with fallback circles."""
        if self.state is EnemyState.DEAD:
            sprite = assets.frame("elite", "die", 0)
            if sprite is not None:
                # slightly smaller and anchored at the feet so it stays low
                width = max(1, round(sprite.get_width() * 0.8))
                height = max(1, round(sprite.get_height() * 0.8))
                sprite = pygame.transform.scale(sprite, (width, height))
        else:
            sprite = self._sprite()
        screen_position = camera.world_to_screen(self.position)
        if sprite is not None:
            if self.aim_direction.x < -0.001:
                sprite = pygame.transform.flip(sprite, True, False)
            rect = sprite.get_rect(
                midbottom=(
                    round(screen_position.x),
                    round(screen_position.y + self.radius),
                )
            )
            surface.blit(sprite, rect)
            draw_health_bar(
                surface, screen_position, self.health, 62, self.radius + 8
            )
            return
        center = (round(screen_position.x), round(screen_position.y))
        aim_end = screen_position + self.aim_direction * 44.0
        color = (
            settings.SQUAD_DEAD_COLOR
            if self.state is EnemyState.DEAD
            else settings.ELITE_ENEMY_COLOR
        )
        if self.state is not EnemyState.DEAD:
            pygame.draw.line(
                surface,
                settings.ELITE_ENEMY_OUTLINE_COLOR,
                center,
                (round(aim_end.x), round(aim_end.y)),
                4,
            )
        pygame.draw.circle(surface, color, center, round(self.radius))
        pygame.draw.circle(
            surface,
            settings.ELITE_ENEMY_OUTLINE_COLOR,
            center,
            round(self.radius),
            4,
        )
        draw_health_bar(surface, screen_position, self.health, 62, self.radius + 8)
