"""Direct-chasing melee enemy state machine."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Sequence

import pygame

from game import assets, settings
from game.camera import Camera
from game.combat.health import Health
from game.combat.target_scanner import Targetable, TargetScanner
from game.damage import DamageInfo
from game.entities.base_entity import BaseEntity
from game.factions import Faction
from game.ui.health_bar import draw_health_bar


class EnemyState(Enum):
    """Behavior states for a basic melee enemy."""

    IDLE = auto()
    CHASE = auto()
    ATTACK = auto()
    DEAD = auto()


@dataclass
class Enemy(BaseEntity):
    """A hostile that scans, directly chases, separates, and attacks."""

    faction: Faction = Faction.ENEMY
    state: EnemyState = EnemyState.IDLE
    move_speed: float = settings.ENEMY_MOVE_SPEED
    attack_range: float = settings.ENEMY_ATTACK_RANGE
    attack_interval: float = settings.ENEMY_ATTACK_INTERVAL
    attack_damage: int = settings.ENEMY_ATTACK_DAMAGE
    velocity: pygame.Vector2 = field(default_factory=pygame.Vector2)
    aim_direction: pygame.Vector2 = field(
        default_factory=lambda: pygame.Vector2(-1.0, 0.0)
    )
    scanner: TargetScanner = field(
        default_factory=lambda: TargetScanner(
            settings.ENEMY_DETECTION_RANGE,
            settings.ENEMY_SCAN_INTERVAL,
        )
    )
    attack_cooldown: float = 0.0
    hit_count: int = 0
    successful_attacks: int = 0
    ranged_fire_cooldown: float = settings.ENEMY_RANGED_FIRE_INTERVAL
    health: Health = field(
        default_factory=lambda: Health(settings.ENEMY_MAX_HEALTH)
    )
    portrait_id: int = 0
    awake_avatar: pygame.Surface | None = field(
        default=None,
        repr=False,
        compare=False,
    )
    defeated_avatar: pygame.Surface | None = field(
        default=None,
        repr=False,
        compare=False,
    )

    def __post_init__(self) -> None:
        """Connect health death to the enemy state machine once."""
        self.health.add_death_callback(self._on_death)

    @property
    def is_alive(self) -> bool:
        """Return whether this enemy may move, attack, or be targeted."""
        return self.state is not EnemyState.DEAD and not self.health.is_dead

    def update(
        self,
        delta_time: float,
        candidates: Sequence[Targetable],
        other_enemies: Sequence[Enemy],
        world_bounds: pygame.Rect,
    ) -> None:
        """Select a target and execute one state-machine update."""
        if self.state is EnemyState.DEAD:
            self.velocity.update(0.0, 0.0)
            self.scanner.clear()
            return

        self.attack_cooldown = max(
            0.0,
            self.attack_cooldown - max(delta_time, 0.0),
        )
        target = self.scanner.update(
            self.position,
            self.faction,
            candidates,
            delta_time,
        )
        if target is None:
            self.state = EnemyState.IDLE
            self.velocity.update(0.0, 0.0)
            return

        difference = target.position - self.position
        distance = difference.length()
        if distance > 0.0001:
            self.aim_direction = difference / distance

        if distance <= self.attack_range:
            self.state = EnemyState.ATTACK
            self.velocity.update(0.0, 0.0)
            self._try_attack(target)
            return

        self.state = EnemyState.CHASE
        separation = self._separation_vector(other_enemies)
        movement_direction = (
            self.aim_direction
            + separation * settings.ENEMY_SEPARATION_WEIGHT
        )
        if movement_direction.length_squared() > 0.000001:
            movement_direction.normalize_ip()

        travel_distance = min(
            self.move_speed * max(delta_time, 0.0),
            max(0.0, distance - self.attack_range),
        )
        self.position += movement_direction * travel_distance
        self.velocity = (
            movement_direction * (travel_distance / delta_time)
            if delta_time > 0.0
            else pygame.Vector2()
        )
        self.clamp_to_bounds(world_bounds)

    def receive_projectile_hit(self, damage: int) -> None:
        """Compatibility wrapper for direct projectile-hit callers."""
        if damage > 0 and self.is_alive:
            self.receive_damage(
                DamageInfo(
                    damage,
                    None,
                    Faction.PLAYER_SQUAD,
                    self.position.copy(),
                )
            )

    def update_ranged_fire(
        self,
        delta_time: float,
        player_position: pygame.Vector2,
        projectile_pool: object,
        missiles: object | None = None,
    ) -> bool:
        """Fire two homing missiles (or a bullet when no missile field)."""
        if not self.is_alive:
            return False
        self.ranged_fire_cooldown -= max(delta_time, 0.0)
        if self.ranged_fire_cooldown > 0.0:
            return False
        self.ranged_fire_cooldown += settings.ENEMY_RANGED_FIRE_INTERVAL
# Fire two homing missiles when a missile field exists; otherwise use legacy projectiles.
        if missiles is not None:
            missiles.fire(self.position, player_position, self)
            return True
        direction = player_position - self.position
        if direction.length_squared() <= 0.000001:
            direction = self.aim_direction
        direction = direction.normalize()
        acquire = getattr(projectile_pool, "acquire")
        projectile = acquire()
        projectile.activate(
            self.position + direction * (self.radius + 8.0),
            direction,
            settings.ENEMY_RANGED_PROJECTILE_SPEED,
            settings.ENEMY_RANGED_PROJECTILE_DAMAGE,
            settings.ENEMY_RANGED_PROJECTILE_LIFETIME,
            settings.PROJECTILE_RADIUS,
            self,
            self.faction,
            0.0,
        )
        return True

    def receive_damage(self, damage: DamageInfo) -> bool:
        """Apply damage and preserve a projectile hit statistic."""
        if damage.damage_type == "projectile" and self.is_alive:
            self.hit_count += 1
        return self.health.take_damage(damage)

    def render(self, surface: pygame.Surface, camera: Camera) -> None:
        """Draw the enemy, facing line, and placeholder hit ticks."""
        screen_position = camera.world_to_screen(self.position)
        center = (round(screen_position.x), round(screen_position.y))
        aim_end = screen_position + self.aim_direction * 39.0
        color = (
            settings.SQUAD_DEAD_COLOR
            if self.state is EnemyState.DEAD
            else settings.ENEMY_COLOR
        )

        if self.state is not EnemyState.DEAD:
            pygame.draw.line(
                surface,
                settings.ENEMY_AIM_COLOR,
                center,
                (round(aim_end.x), round(aim_end.y)),
                3,
            )
        sprite = self._sprite_frame()
        if sprite is None:
            pygame.draw.circle(surface, color, center, round(self.radius))
            avatar = (
                self.defeated_avatar
                if self.state is EnemyState.DEAD
                else self.awake_avatar
            )
            if avatar is not None:
                surface.blit(avatar, avatar.get_rect(center=center))
            pygame.draw.circle(
                surface,
                settings.ENEMY_OUTLINE_COLOR,
                center,
                round(self.radius),
                3,
            )
        else:
            if self.aim_direction.x < -0.001:
                sprite = pygame.transform.flip(sprite, True, False)
            surface.blit(sprite, sprite.get_rect(center=center))
        self._render_hit_ticks(surface, center)
        draw_health_bar(
            surface,
            screen_position,
            self.health,
            50,
            self.radius + 8,
        )

    def _sprite_frame(self) -> pygame.Surface | None:
        """Pick the pixel-art animation frame, or None for vector fallback."""
        if self.state is EnemyState.DEAD:
            state = "die"
        elif self.state is EnemyState.CHASE:
            state = "run"
        else:
            state = "idle"
        count = assets.frame_count("goblin", state)
        if count == 0:
            return None
        frame_ms = max(1, int(1000 / assets.fps("goblin", state)))
        index = (pygame.time.get_ticks() // frame_ms) % count
        return assets.frame("goblin", state, index)

    def _render_hit_ticks(self, surface: pygame.Surface, center) -> None:
        """Draw the placeholder damage ticks above the enemy."""
        for index in range(min(self.hit_count, 5)):
            x = center[0] - 10 + index * 5
            pygame.draw.line(
                surface,
                settings.ENEMY_OUTLINE_COLOR,
                (x, center[1] - 5),
                (x, center[1] + 5),
                2,
            )

    def _try_attack(self, target: Targetable) -> None:
        if self.attack_cooldown > 0.0 or not target.is_alive:
            return
        receive_hit = getattr(target, "receive_melee_hit", None)
        if callable(receive_hit):
            receive_hit(self.attack_damage, self)
            self.successful_attacks += 1
        self.attack_cooldown = self.attack_interval

    def _separation_vector(
        self,
        other_enemies: Sequence[Enemy],
    ) -> pygame.Vector2:
        separation = pygame.Vector2()
        range_squared = settings.ENEMY_SEPARATION_DISTANCE**2
        for other in tuple(other_enemies):
            if other is self or not other.is_alive:
                continue
            difference = self.position - other.position
            distance_squared = difference.length_squared()
            if distance_squared <= 0.000001:
                separation.x += 1.0
            elif distance_squared < range_squared:
                distance = distance_squared**0.5
                strength = (
                    1.0
                    - distance / settings.ENEMY_SEPARATION_DISTANCE
                )
                separation += difference / distance * strength
        if separation.length_squared() > 1.0:
            separation.normalize_ip()
        return separation

    def _on_death(self, damage: DamageInfo) -> None:
        """Stop movement, targeting, and attacks after one death event."""
        del damage
        self.state = EnemyState.DEAD
        self.velocity.update(0.0, 0.0)
        self.scanner.clear()
