"""Boss empowered attack: red iron balls and green shockwaves."""

from dataclasses import dataclass, field

import pygame

from game import assets, settings
from game.camera import Camera
from game.factions import Faction


class IronBallState:
    """Simple state machine for one thrown iron ball."""

    MOVING = "moving"
    WAITING = "waiting"
    BLINKING = "blinking"
    DONE = "done"


@dataclass
class IronBall:
    """A damageable red sphere that ends in a green shockwave."""

    position: pygame.Vector2
    direction: pygame.Vector2
    owner: object
    # hostile faction so player shots can target the ball
    faction: Faction = Faction.ENEMY
    radius: float = settings.IRON_BALL_RADIUS
    health: int = settings.IRON_BALL_HEALTH
    max_health: int = settings.IRON_BALL_HEALTH
    state: str = IronBallState.MOVING
    age: float = 0.0
    travelled: float = 0.0
    timer: float = 0.0
    spawn_shockwave: bool = False
    blink_enabled: bool = True      # ring balls never blink
    shockwave_enabled: bool = True  # ring balls release no shockwave

    @property
    def is_alive(self) -> bool:
        return self.state != IronBallState.DONE

    @property
    def invincible(self) -> bool:
        """Blinking iron balls cannot be damaged."""
        return self.state == IronBallState.BLINKING

    def receive_damage(self, damage) -> bool:
        if not self.is_alive or self.invincible:
            return False
        amount = int(getattr(damage, "amount", damage))
        self.health = max(0, self.health - amount)
        if self.health <= 0:
            # killed iron balls simply vanish (no shockwave)
            self.state = IronBallState.DONE
            self.spawn_shockwave = self.shockwave_enabled and self.spawn_shockwave
        return True

    def update(self, delta_time: float, bounds: pygame.Rect) -> None:
        safe_delta = max(delta_time, 0.0)
        self.age += safe_delta
# States: move -> stay -> flash (invulnerable) -> disappear and release a shockwave.
        if self.state == IronBallState.MOVING:
            step = settings.IRON_BALL_SPEED * safe_delta
            self.position += self.direction * step
            self.travelled += step
            if not bounds.collidepoint(self.position):
                self.position.x = max(bounds.left, min(self.position.x, bounds.right))
                self.position.y = max(bounds.top, min(self.position.y, bounds.bottom))
                self._stop()
            elif self.travelled >= settings.IRON_BALL_DISTANCE:
                self._stop()
        elif self.state == IronBallState.WAITING:
            self.timer -= safe_delta
            if self.timer <= 0.0:
                self.state = IronBallState.BLINKING
                self.timer = settings.IRON_BALL_BLINK_TIME
        elif self.state == IronBallState.BLINKING:
            self.timer -= safe_delta
            if self.timer <= 0.0:
                self.state = IronBallState.DONE
                self.spawn_shockwave = True

    def _stop(self) -> None:
        self.state = IronBallState.WAITING
        self.timer = settings.IRON_BALL_WAIT_TIME

    def blink_visible(self) -> bool:
        if not self.blink_enabled:
            return True
        if self.state != IronBallState.BLINKING:
            return True
        return (self.age * 10.0) % 1.0 < 0.55

    def render(self, surface: pygame.Surface, camera: Camera) -> None:
        if self.state == IronBallState.DONE or not self.blink_visible():
            return
        screen = camera.world_to_screen(self.position)
        center = (round(screen.x), round(screen.y))
        radius = round(self.radius)
        blink = self.state == IronBallState.BLINKING
        body = (
            settings.IRON_BALL_BLINK_COLOR if blink else settings.IRON_BALL_COLOR
        )
        # bomb silhouette: cap + body, silver-black with a bright highlight
        pygame.draw.rect(
            surface,
            settings.IRON_BALL_DARK,
            pygame.Rect(
                center[0] - max(2, radius // 3),
                center[1] - radius - max(2, radius // 3),
                max(4, (radius // 3) * 2),
                max(3, radius // 3),
            ),
        )
        pygame.draw.circle(surface, body, center, radius)
        pygame.draw.circle(surface, settings.IRON_BALL_DARK, center, radius, 4)
        highlight = pygame.Vector2(-0.35, -0.42) * radius
        pygame.draw.circle(
            surface,
            (200, 206, 218),
            (center[0] + round(highlight.x), center[1] + round(highlight.y)),
            max(2, round(radius * 0.26)),
        )
        pygame.draw.circle(
            surface,
            (246, 250, 255),
            (center[0] + round(highlight.x) - 1, center[1] + round(highlight.y) - 1),
            max(1, round(radius * 0.12)),
        )
        # health bar is always visible so the ball reads as damageable
        ratio = max(0.0, self.health / max(1, self.max_health))
        bar = pygame.Rect(
            center[0] - 22, center[1] - round(self.radius) - 24, 44, 6
        )
        pygame.draw.rect(surface, settings.HEALTH_BAR_BACKGROUND, bar)
        fill = bar.copy()
        fill.width = max(0, round(bar.width * ratio))
        if fill.width > 0:
            pygame.draw.rect(surface, settings.IRON_BALL_BLINK_COLOR, fill)
        pygame.draw.rect(surface, (22, 22, 26), bar, 1)


@dataclass
class GreenShockwave:
    """Expanding ring: clears the shield or chips health without a shield."""

    position: pygame.Vector2
    radius: float = 0.0
    owner: object = None
    age: float = 0.0
    hit_ids: set = field(default_factory=set)

    @property
    def finished(self) -> bool:
        return self.radius >= settings.SHOCKWAVE_MAX_DIAMETER / 2.0

    def update(self, delta_time: float, players) -> None:
        safe_delta = max(delta_time, 0.0)
        self.age += safe_delta
        self.radius = min(
            settings.SHOCKWAVE_MAX_DIAMETER / 2.0,
            self.radius + settings.SHOCKWAVE_SPEED * safe_delta,
        )
        for player in tuple(players):
            if not getattr(player, "is_alive", False) or id(player) in self.hit_ids:
                continue
            reach = self.radius + getattr(player, "radius", 0.0)
            if self.position.distance_to(player.position) > reach:
                continue
            self.hit_ids.add(id(player))
            self._apply(player)

    @staticmethod
    def _apply(player) -> None:
        """Shielded players lose the whole shield instead of health."""
        shield = getattr(player, "shield", 0.0)
        if shield and shield > 0.0:
            player.shield = 0.0
            player.shield_regen_timer = settings.PLAYER_SHIELD_REGEN_DELAY
            return
        health = getattr(player, "health", None)
        if health is not None and not health.is_dead:
            from game.damage import DamageInfo
            from game.factions import Faction
            player.receive_damage(
                DamageInfo(
                    settings.SHOCKWAVE_DAMAGE, None, Faction.ENEMY,
                    player.position.copy(), "shockwave",
                )
            )

    def render(self, surface: pygame.Surface, camera: Camera) -> None:
        screen = camera.world_to_screen(self.position)
        center = (round(screen.x), round(screen.y))
        alpha = max(40, 220 - round(self.age * 140))
        layer = pygame.Surface(surface.get_size(), pygame.SRCALPHA)
        pygame.draw.circle(
            layer, (*settings.SHOCKWAVE_COLOR, alpha), center,
            max(2, round(self.radius)), settings.SHOCKWAVE_WIDTH,
        )
        surface.blit(layer, (0, 0))


class IronBallField:
    """Owns iron balls and the shockwaves their deaths release."""

    def __init__(self) -> None:
        self.balls: list[IronBall] = []
        self.shockwaves: list[GreenShockwave] = []

    def spawn(
        self,
        origin: pygame.Vector2,
        direction: pygame.Vector2,
        owner: object,
    ) -> IronBall:
        heading = pygame.Vector2(direction)
        if heading.length_squared() <= 0.000001:
            heading = pygame.Vector2(1.0, 0.0)
        ball = IronBall(
            position=pygame.Vector2(origin),
            direction=heading.normalize(),
            owner=owner,
        )
        self.balls.append(ball)
        return ball

    @property
    def count(self) -> int:
        return len(self.balls)

    def update(
        self, delta_time: float, bounds: pygame.Rect, players
    ) -> None:
        """Advance balls and shockwaves, releasing explosions on death."""
        for ball in self.balls:
            ball.update(delta_time, bounds)
        for ball in self.balls:
            if ball.spawn_shockwave:
                ball.spawn_shockwave = False
                self.shockwaves.append(
                    GreenShockwave(position=ball.position.copy(), owner=ball.owner)
                )
        self.balls = [b for b in self.balls if b.state != IronBallState.DONE]
        for wave in self.shockwaves:
            wave.update(delta_time, players)
        self.shockwaves = [w for w in self.shockwaves if not w.finished]

    def render(self, surface: pygame.Surface, camera: Camera) -> None:
        for wave in self.shockwaves:
            wave.render(surface, camera)
        for ball in self.balls:
            ball.render(surface, camera)
