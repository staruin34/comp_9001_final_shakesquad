"""Player movement, aiming, and placeholder rendering."""

from dataclasses import dataclass, field
from math import cos, radians, sin

import pygame

from game import assets, settings
from game.camera import Camera
from game.combat.health import Health
from game.combat.weapon import Weapon
from game.damage import DamageInfo
from game.entities.base_entity import BaseEntity
from game.factions import Faction
from game.ui.health_bar import draw_health_bar


def hand_anchor(
    center: pygame.Vector2,
    facing: pygame.Vector2,
    offset: tuple[float, float] = settings.PLAYER_HAND_OFFSET,
) -> pygame.Vector2:
    """Return the protagonist's hand position for the sprite's facing.

    The body sprite only mirrors left/right (it never rotates for up/down
    aims), so the hand stays below the eyes on the facing side and the
    weapon rotates around this anchor. The offset is expressed in raw
    right-facing pixels and scales with SPRITE_SCALE.
    """
    side = 1.0 if facing.x >= -0.001 else -1.0
    raw = pygame.Vector2(offset) * settings.SPRITE_SCALE
    return pygame.Vector2(center) + pygame.Vector2(raw.x * side, raw.y)


def rotate_about_pivot(
    sprite: pygame.Surface,
    angle_deg: float,
    pivot: pygame.Vector2,
) -> tuple[pygame.Surface, pygame.Vector2]:
    """Rotate a sprite about pivot (grip offset from the sprite center).

    Returns the rotated surface and the offset to add to the pivot's world
    position, so the weapon spins around the grip held in the hand.
    """
    rotated = pygame.transform.rotate(sprite, angle_deg)
    angle_rad = radians(angle_deg)
    rotated_pivot = pygame.Vector2(
        pivot.x * cos(angle_rad) + pivot.y * sin(angle_rad),
        -pivot.x * sin(angle_rad) + pivot.y * cos(angle_rad),
    )
    return rotated, -rotated_pivot


def weapon_grip_position(
    hand: pygame.Vector2,
    angle_deg: float,
    flipped: bool,
    grip_local: pygame.Vector2,
) -> pygame.Vector2:
    """Return the sprite center that places the grip pixel on the hand."""
    angle_rad = radians(angle_deg)
    rotated_grip = pygame.Vector2(
        grip_local.x * cos(angle_rad) + grip_local.y * sin(angle_rad),
        -grip_local.x * sin(angle_rad) + grip_local.y * cos(angle_rad),
    )
    if flipped:
        rotated_grip.x = -rotated_grip.x
    return pygame.Vector2(hand) - rotated_grip


def weapon_orientation(aim: pygame.Vector2) -> tuple[bool, float]:
    """Return (flip_x, degrees) orienting a right-facing sprite along aim.

    Empirical pygame convention: Vector2.angle_to uses screen coordinates,
    so rotate(surface, +angle_to(Vector2(1, 0))) turns a right-facing
    sprite toward the aim direction. Left-half aims mirror horizontally
    first, which keeps the weapon's grip on the correct side.
    """
    flipped = aim.x < -0.001
    effective = pygame.Vector2(-aim.x, aim.y) if flipped else pygame.Vector2(aim)
    angle = pygame.Vector2(effective).angle_to(pygame.Vector2(1.0, 0.0))
    return flipped, angle


@dataclass
class Player(BaseEntity):
    """A player that moves and aims independently in world space."""

    faction: Faction = Faction.PLAYER
    # which sprite set the selected hero uses ("player" / "player2")
    sprite_kind: str = "player"
    move_speed: float = settings.PLAYER_SPEED
    velocity: pygame.Vector2 = field(default_factory=pygame.Vector2)
    aim_direction: pygame.Vector2 = field(
        default_factory=lambda: pygame.Vector2(1.0, 0.0)
    )
    melee_hit_count: int = 0
    health: Health = field(
        default_factory=lambda: Health(settings.PLAYER_MAX_HEALTH)
    )
    avatar: pygame.Surface | None = field(default=None, repr=False, compare=False)
    melee_invincible: float = 0.0
    weapon: Weapon = field(default_factory=Weapon)
    # The shield absorbs damage before health; shield capacity is configured in settings.
    # Only the protagonist regenerates a shield after the damage-free delay.
    shield: float = settings.PLAYER_SHIELD_MAX
    shield_regen_timer: float = 0.0
    # Equipped weapon determines attack style: pistol (default, ranged) or sword (melee).
    weapon_kind: str = "pistol"
    # Unlock the sword by collecting it; the pistol is available from the start.
    has_sword: bool = False

    def __post_init__(self) -> None:
        """The protagonist deals doubled damage with the shared weapon."""
        self.weapon.projectile_damage = round(
            settings.PROJECTILE_DAMAGE * settings.PLAYER_DAMAGE_MULTIPLIER
        )

    @property
    def is_alive(self) -> bool:
        """Return whether the player can move, rescue, or be targeted."""
        return not self.health.is_dead

    def receive_melee_hit(self, damage: int, attacker: object | None = None) -> None:
        """Convert a melee strike into shared damage data."""
        if damage > 0:
            self.melee_hit_count += 1
            attacker_faction = getattr(attacker, "faction", Faction.ENEMY)
            self.receive_damage(
                DamageInfo(
                    damage,
                    attacker,
                    attacker_faction,
                    self.position.copy(),
                    "melee",
                )
            )

    def update_shield(self, delta_time: float) -> None:
        """Regenerate shield after PLAYER_SHIELD_REGEN_DELAY unhurt seconds.

        When the delay expires partway through a tick, the remainder of
        that tick already regenerates (no lost regen time).
        """
        if self.shield_regen_timer > 0.0:
            self.shield_regen_timer -= delta_time
            if self.shield_regen_timer > 0.0:
                return
            delta_time = -self.shield_regen_timer
            self.shield_regen_timer = 0.0
        if self.shield < settings.PLAYER_SHIELD_MAX:
            self.shield = min(
                settings.PLAYER_SHIELD_MAX,
                self.shield + settings.PLAYER_SHIELD_REGEN_RATE * delta_time,
            )

    def receive_damage(self, damage: DamageInfo) -> bool:
        """Shield absorbs damage first; damage never overflows to health."""
        if self.melee_invincible > 0.0:
            return False
        if not self.is_alive:
            return False
        amount = int(damage.amount)
        if amount <= 0:
            return False
        self.shield_regen_timer = settings.PLAYER_SHIELD_REGEN_DELAY
# Draw the shield bar above the player only while a shield remains.
        if self.shield > 0.0:
            # Shield damage never spills into health, even when a hit exceeds the remaining shield.
            self.shield = max(0.0, self.shield - amount)
            return True
        return self.health.take_damage(damage)
        return self.health.take_damage(damage)

    @staticmethod
    def movement_direction(
        left: bool,
        right: bool,
        up: bool,
        down: bool,
    ) -> pygame.Vector2:
        """Build a normalized movement vector from directional input."""
        direction = pygame.Vector2(float(right) - float(left), float(down) - float(up))
        if direction.length_squared() > 0.0:
            direction.normalize_ip()
        return direction

    def update_movement(
        self,
        direction: pygame.Vector2,
        delta_time: float,
        world_bounds: pygame.Rect,
    ) -> None:
        """Move by pixels per second and remain inside the map."""
        if direction.length_squared() > 0.0:
            safe_direction = direction.normalize()
        else:
            safe_direction = pygame.Vector2()

        self.velocity = safe_direction * self.move_speed
        self.position += self.velocity * delta_time
        self.clamp_to_bounds(world_bounds)

    def attack_origin(self) -> pygame.Vector2:
        """Return the world-space melee origin at the held weapon."""
        return hand_anchor(self.position, self._sprite_facing())

    def update_aim(self, mouse_world_position: pygame.Vector2) -> None:
        """Aim toward a world point while preserving a valid direction."""
        difference = mouse_world_position - self.position
        if difference.length_squared() > 0.000001:
            self.aim_direction = difference.normalize()

    def render(
        self, surface: pygame.Surface, camera: Camera, melee_kit=None
    ) -> None:
        """Draw the player sprite (or vector fallback) plus aim indicator."""
        screen_position = camera.world_to_screen(self.position)
        center = (round(screen_position.x), round(screen_position.y))
        aim_end = screen_position + self.aim_direction * settings.PLAYER_AIM_LENGTH

        if settings.PLAYER_AIM_LINE_VISIBLE:
            pygame.draw.line(
                surface,
                settings.PLAYER_AIM_COLOR,
                center,
                (round(aim_end.x), round(aim_end.y)),
                4,
            )
        # Dash stealth: the body vanishes for exactly the dash i-frame
        # window and reappears before the dash itself ends.
        stealth = (
            melee_kit is not None
            and melee_kit.dashing
            and melee_kit.invincible > 0.0
        )
# Hide the body during dash invulnerability; show it immediately afterwards.
        if stealth:
            sprite = None  # body hidden; bars and aim line still draw
        else:
            sprite = self._sprite_frame()
        if stealth:
            pass
        elif sprite is None:
            pygame.draw.circle(
                surface, settings.PLAYER_COLOR, center, round(self.radius)
            )
            if self.avatar is not None:
                avatar_rect = self.avatar.get_rect(center=center)
                surface.blit(self.avatar, avatar_rect)
            pygame.draw.circle(
                surface,
                settings.PLAYER_OUTLINE_COLOR,
                center,
                round(self.radius),
                3,
            )
        else:
            if self._sprite_facing().x < -0.001:
                sprite = pygame.transform.flip(sprite, True, False)
            surface.blit(sprite, sprite.get_rect(center=center))
            self._render_weapon_layer(surface, camera, center, melee_kit)
        if self.shield > 0.0:
            bar_width = 54
            bar_rect = pygame.Rect(
                center[0] - bar_width // 2,
                center[1] - round(self.radius) - 22,
                bar_width,
                6,
            )
            ratio = max(0.0, min(1.0, self.shield / settings.PLAYER_SHIELD_MAX))
            fill = bar_rect.copy()
            fill.width = round(bar_rect.width * ratio)
            pygame.draw.rect(surface, settings.HEALTH_BAR_BACKGROUND, bar_rect)
            pygame.draw.rect(surface, settings.PLAYER_SHIELD_COLOR, fill)
            pygame.draw.rect(
                surface, settings.PLAYER_SHIELD_OUTLINE_COLOR, bar_rect, 1
            )
        draw_health_bar(
            surface,
            screen_position,
            self.health,
            54,
            self.radius + 8,
        )

    def _sprite_frame(self) -> pygame.Surface | None:
        """Pick the pixel-art animation frame, or None for vector fallback."""
        state = "run" if self.velocity.length_squared() > 1.0 else "idle"
        kind = self.sprite_kind
        count = assets.frame_count(kind, state)
        if count == 0:
            return None
        frame_ms = max(1, int(1000 / assets.fps(kind, state)))
        index = (pygame.time.get_ticks() // frame_ms) % count
        return assets.frame(kind, state, index)

    def _render_weapon_layer(self, surface, camera, center, melee_kit=None) -> None:
        """Overlay the held weapon at the hand anchor, rotated to aim.

        The pistol uses the scaled library sprite; the sword uses the
        custom 64px user sprite at native size (its blade points right,
        matching the weapon_orientation convention). Both rotate toward
        the aim direction; left aims mirror horizontally. During a melee
        windup/swing the hand pose is skipped: the fx layer sweeps the
        sword across the full attack range instead.
        """
        if self.weapon_kind == "sword":
            # the sweeping weapon animation was removed: the sword stays in
            # the character's hand for the whole attack
            sprite = assets.item_raw("weapon_sword")
            # pivot = grip point relative to the sprite center (right-facing)
            grip_local = pygame.Vector2(-14.0, 2.0)
        elif self.weapon_kind == "pistol":
            sprite = assets.item("weapon_pistol")
            grip_local = pygame.Vector2(-10.0, 7.5)
        else:
            return
        if sprite is None:
            return
# Rotate towards the aim direction; mirror horizontally after rotating when aiming left.
        flipped, angle = weapon_orientation(pygame.Vector2(self.aim_direction))
        # The weapon rotates about its grip point, which sits on the hand:
        # the sprite center is offset so the pivot stays exactly on the hand.
# Rotate the weapon around its grip so the pivot stays at the hand anchor.
        rotated, offset = rotate_about_pivot(sprite, angle, grip_local)
        if flipped:
            # Rotate first, then mirror: flipping a rotated surface keeps the
            # rotation direction consistent with the aim (verified empirically).
            rotated = pygame.transform.flip(rotated, True, False)
            offset.x = -offset.x
        hand = hand_anchor(pygame.Vector2(center), self._sprite_facing())
        position = hand + offset
        surface.blit(
            rotated,
            rotated.get_rect(center=(round(position.x), round(position.y))),
        )

    def _sprite_facing(self) -> pygame.Vector2:
        """Return the horizontal facing used for sprite mirroring."""
        direction = (
            self.velocity
            if self.velocity.length_squared() > 1.0
            else self.aim_direction
        )
        return pygame.Vector2(direction.x, 0.0)
