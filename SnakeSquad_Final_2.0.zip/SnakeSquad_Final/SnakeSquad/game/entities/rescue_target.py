"""Waiting friendly unit that can join the player's squad."""

from dataclasses import dataclass

import pygame

from game import settings
from game.camera import Camera
from game.entities.squad_member import SquadMember, SquadMemberState
from game.factions import Faction


@dataclass
class RescueTarget(SquadMember):
    """A friendly squad member waiting for one successful rescue."""

    faction: Faction = Faction.NEUTRAL
    rescue_radius: float = settings.RESCUE_RADIUS
    rescued: bool = False

    def try_rescue(
        self,
        player_position: pygame.Vector2,
        player_alive: bool = True,
    ) -> bool:
        """Mark this target rescued once when a living player is nearby."""
        if (
            self.rescued
            or not player_alive
            or self.state is not SquadMemberState.WAITING
        ):
            return False

        rescue_distance_squared = self.rescue_radius * self.rescue_radius
        if self.position.distance_squared_to(player_position) > rescue_distance_squared:
            return False

        self.rescued = True
        return True

    def render_waiting(self, surface: pygame.Surface, camera: Camera) -> None:
        """Draw a yellow waiting unit and a simple rescue marker."""
        if self.rescued or self.state is not SquadMemberState.WAITING:
            return

        screen_position = camera.world_to_screen(self.position)
        center = (round(screen_position.x), round(screen_position.y))
        pygame.draw.circle(
            surface,
            settings.RESCUE_WAITING_COLOR,
            center,
            round(self.radius),
        )
        if self.neutral_avatar is not None:
            surface.blit(
                self.neutral_avatar,
                self.neutral_avatar.get_rect(center=center),
            )
        pygame.draw.circle(
            surface,
            settings.RESCUE_WAITING_OUTLINE_COLOR,
            center,
            round(self.radius),
            2,
        )

        marker_center = (center[0], center[1] - round(self.radius) - 17)
        pygame.draw.circle(surface, settings.RESCUE_MARKER_COLOR, marker_center, 9, 2)
        pygame.draw.line(
            surface,
            settings.RESCUE_MARKER_COLOR,
            (marker_center[0], marker_center[1] - 4),
            (marker_center[0], marker_center[1] + 2),
            2,
        )
        pygame.draw.circle(
            surface,
            settings.RESCUE_MARKER_COLOR,
            (marker_center[0], marker_center[1] + 5),
            1,
        )
