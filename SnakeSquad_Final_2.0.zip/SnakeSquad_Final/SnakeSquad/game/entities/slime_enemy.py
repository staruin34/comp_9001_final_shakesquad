"""Red slime minion: chases, telegraphs, then dashes in a straight line."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum, auto
from math import sin
from typing import Sequence

import pygame

from game import assets, settings
from game.camera import Camera
from game.combat.health import Health
from game.damage import DamageInfo
from game.entities.base_entity import BaseEntity
from game.factions import Faction
from game.ui.health_bar import draw_health_bar


class SlimeState(Enum):
    """Slime state machine: idle, chase, telegraph, dash, cooldown, dead."""

    IDLE = auto()
    CHASE = auto()
    TELEGRAPH = auto()
    DASH = auto()
    COOLDOWN = auto()
    DEAD = auto()


@dataclass
class SlimeEnemy(BaseEntity):
    """A red slime that charges the player along a locked straight line.

    Before the dash the slime stands still and shows the charge corridor;
    the direction locks at telegraph start, so players can sidestep it.
    """

    position: pygame.Vector2 = field(default_factory=pygame.Vector2)
    radius: float = settings.SLIME_RADIUS
    # BaseEntity defaults to NEUTRAL, which the damage pipeline skips;
    # the slime must be ENEMY or projectiles pass straight through it.
    faction: Faction = Faction.ENEMY
    health: Health = field(
        default_factory=lambda: Health(settings.SLIME_MAX_HEALTH)
    )
    state: SlimeState = SlimeState.IDLE
    aim_direction: pygame.Vector2 = field(
        default_factory=lambda: pygame.Vector2(1.0, 0.0)
    )
    successful_attacks: int = 0
    velocity: pygame.Vector2 = field(default_factory=pygame.Vector2)
    dash_dir: pygame.Vector2 = field(
        default_factory=lambda: pygame.Vector2(1.0, 0.0)
    )
    dash_traveled: float = 0.0
    dash_hit: set = field(default_factory=set)
    _timer: float = 0.0
    _dash_cooldown: float = 0.0

    def __post_init__(self) -> None:
        self.health.add_death_callback(self._on_death)

    def _on_death(self, _damage: DamageInfo) -> None:
        self.state = SlimeState.DEAD
        self.velocity.update(0.0, 0.0)

    @property
    def is_alive(self) -> bool:
        """Return whether the slime may move, dash, or be targeted."""
        return self.state is not SlimeState.DEAD and not self.health.is_dead

    def update(
        self,
        delta_time: float,
        candidates: Sequence,
        other_enemies: Sequence,
        world_bounds: pygame.Rect,
    ) -> None:
        """Advance the chase -> telegraph -> dash -> cooldown machine."""
        if self.state is SlimeState.DEAD:
            self.velocity.update(0.0, 0.0)
            return
        self._dash_cooldown = max(0.0, self._dash_cooldown - delta_time)

        if self.state is SlimeState.TELEGRAPH:
            self.velocity.update(0.0, 0.0)
            self._timer -= delta_time
            if self._timer <= 0.0:
                self.state = SlimeState.DASH
                self.dash_traveled = 0.0
                self.dash_hit.clear()
                self._timer = settings.SLIME_DASH_DURATION
            return
        if self.state is SlimeState.DASH:
            self._dash_move(delta_time, candidates, world_bounds)
            return
# Approach again during the second half of cooldown to keep the movement animation active.
        if self.state is SlimeState.COOLDOWN:
            self._timer -= delta_time
            if self._timer <= 0.0:
                self.state = SlimeState.IDLE
                self.velocity.update(0.0, 0.0)
                return
            # close in again during the second half of the cooldown so the
            # movement animation actually plays between dashes
            if self._timer <= settings.SLIME_DASH_COOLDOWN * 0.5:
                target = self._nearest_living(candidates)
                if target is not None:
                    difference = target.position - self.position
                    distance = difference.length()
                    if distance > 0.0001:
                        self.aim_direction = difference / distance
                        self.velocity = (
                            self.aim_direction * settings.SLIME_CHASE_SPEED
                        )
                        self.position += self.velocity * delta_time
                        self.clamp_to_bounds(world_bounds)
                        return
            self.velocity.update(0.0, 0.0)
            return

        target = self._nearest_living(candidates)
        if target is None:
            self.state = SlimeState.IDLE
            self.velocity.update(0.0, 0.0)
            return
        difference = target.position - self.position
        distance = difference.length()
        if distance > 0.0001:
            self.aim_direction = difference / distance
        if (
            self._dash_cooldown <= 0.0
            and distance <= settings.SLIME_DASH_TRIGGER_RANGE
        ):
            # lock the charge direction and show the dash corridor
            self.state = SlimeState.TELEGRAPH
            self.dash_dir = self.aim_direction.copy()
            self._timer = settings.SLIME_DASH_WINDUP
            self.velocity.update(0.0, 0.0)
            return
        self.state = SlimeState.CHASE
        self.velocity = self.aim_direction * settings.SLIME_CHASE_SPEED
        self.position += self.velocity * delta_time
        self.clamp_to_bounds(world_bounds)

    def _dash_move(
        self,
        delta_time: float,
        candidates: Sequence,
        world_bounds: pygame.Rect,
    ) -> None:
        """Slide along the locked direction, damaging targets once each."""
        step = settings.SLIME_DASH_SPEED * delta_time
        self.position += self.dash_dir * step
        self.dash_traveled += step
        self.velocity = self.dash_dir * settings.SLIME_DASH_SPEED
        for target in candidates:
            if not getattr(target, "is_alive", False):
                continue
            key = id(target)
            if key in self.dash_hit:
                continue
            if self.position.distance_squared_to(target.position) <= (
                self.radius + getattr(target, "radius", 0.0)
            ) ** 2:
                receive = getattr(target, "receive_damage", None)
                if callable(receive):
                    receive(
                        DamageInfo(
                            settings.SLIME_DASH_DAMAGE,
                            self,
                            Faction.ENEMY,
                            target.position.copy(),
                            "melee",
                        )
                    )
                self.dash_hit.add(key)
                self.successful_attacks += 1
        self.clamp_to_bounds(world_bounds)
        self._timer -= delta_time
        if (
            self.dash_traveled >= settings.SLIME_DASH_RANGE
            or self._timer <= 0.0
        ):
            self.state = SlimeState.COOLDOWN
            self._timer = settings.SLIME_DASH_COOLDOWN
            self._dash_cooldown = settings.SLIME_DASH_COOLDOWN
            self.velocity.update(0.0, 0.0)

    def _nearest_living(self, candidates: Sequence):
        best = None
        best_distance = None
        for candidate in candidates:
            if not getattr(candidate, "is_alive", False):
                continue
            distance = self.position.distance_squared_to(candidate.position)
            if best_distance is None or distance < best_distance:
                best = candidate
                best_distance = distance
        return best

    def receive_damage(self, damage: DamageInfo) -> bool:
        """Apply damage through the shared health component."""
        return self.health.take_damage(damage)

    def facing(self) -> pygame.Vector2:
        """Facing used for mirroring, following the actual movement."""
        if self.state in (SlimeState.TELEGRAPH, SlimeState.DASH):
            return self.dash_dir
        if self.velocity.length_squared() > 1.0:
            return self.velocity
        return self.aim_direction

    def _oriented_sprite(self, sprite: pygame.Surface) -> pygame.Surface:
        """Mirror the right-facing art whenever the facing points left."""
        if self.facing().x < -0.001:
            return pygame.transform.flip(sprite, True, False)
        return sprite

    def render(self, surface: pygame.Surface, camera: Camera) -> None:
        """Draw the telegraph corridor, sprite and health bar."""
        if self.state is SlimeState.TELEGRAPH:
            self._render_dash_range(surface, camera)
        screen_position = camera.world_to_screen(self.position)
        center = (round(screen_position.x), round(screen_position.y))
        sprite = self._sprite_frame()
        if sprite is None:
            pygame.draw.circle(
                surface, settings.SLIME_COLOR, center, round(self.radius)
            )
            pygame.draw.circle(
                surface,
                settings.SLIME_OUTLINE_COLOR,
                center,
                round(self.radius),
                3,
            )
        else:
            sprite = self._oriented_sprite(sprite)
            surface.blit(sprite, sprite.get_rect(center=center))
        # same health bar as the other minions
        draw_health_bar(
            surface,
            screen_position,
            self.health,
            50,
            self.radius + 8,
        )

    def _render_dash_range(self, surface: pygame.Surface, camera: Camera) -> None:
        """Show the locked charge corridor before the dash fires."""
        start = camera.world_to_screen(self.position)
        end = camera.world_to_screen(
            self.position + self.dash_dir * settings.SLIME_DASH_RANGE
        )
        pulse = 0.5 + 0.5 * sin(pygame.time.get_ticks() / 130.0)
        alpha = int(70 + 85 * pulse)
        width = max(8, round(self.radius * 2))
        layer = pygame.Surface(surface.get_size(), pygame.SRCALPHA)
        pygame.draw.line(
            layer,
            (255, 84, 74, alpha),
            (round(start.x), round(start.y)),
            (round(end.x), round(end.y)),
            width,
        )
        pygame.draw.line(
            layer,
            (255, 150, 140, min(255, alpha + 60)),
            (round(start.x), round(start.y)),
            (round(end.x), round(end.y)),
            2,
        )
        surface.blit(layer, (0, 0))

# Select animation from actual movement, rather than only the simulation state.
    def sprite_state(self) -> str:
        """Map the sim state to an animation set (run while actually moving)."""
        if self.state is SlimeState.DEAD:
            return "die"
        if self.state is SlimeState.DASH:
            return "dash"
        if self.state is SlimeState.TELEGRAPH:
            # charging pose: hold the first dash frame while winding up
            return "dash"
        if self.velocity.length_squared() > 1.0:
            return "run"
        if self.state is SlimeState.CHASE:
            return "run"
        return "idle"

    def _sprite_frame(self) -> pygame.Surface | None:
        """Pick the slime animation frame, or None for the vector fallback."""
        state_name = self.sprite_state()
        if self.state is SlimeState.TELEGRAPH:
            count = assets.frame_count("slime", state_name)
            return assets.frame("slime", state_name, 0) if count else None
        count = assets.frame_count("slime", state_name)
        if count == 0:
            return None
        frame_ms = max(1, int(1000 / assets.fps("slime", state_name)))
        index = (pygame.time.get_ticks() // frame_ms) % count
        return assets.frame("slime", state_name, index)
