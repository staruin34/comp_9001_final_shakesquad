"""Path-following squad member entity."""

from dataclasses import dataclass, field
from enum import Enum, auto
from math import atan2, cos, degrees, radians, sin

import pygame

from game import settings
from game.camera import Camera
from game.combat.projectile_pool import ProjectilePool
from game.combat.health import Health
from game.combat.weapon import Weapon
from game.entities.base_entity import BaseEntity
from game.damage import DamageInfo
from game.factions import Faction
from game.ui.health_bar import draw_health_bar


class SquadMemberState(Enum):
    """Lifecycle states available to a squad member."""

    WAITING = auto()
    FOLLOWING = auto()
    DEAD = auto()


@dataclass
class SquadMember(BaseEntity):
    """A friendly unit that follows a distance-indexed path target."""

    faction: Faction = Faction.PLAYER_SQUAD
    state: SquadMemberState = SquadMemberState.WAITING
    queue_index: int = -1
    follow_speed: float = settings.SQUAD_FOLLOW_SPEED
    velocity: pygame.Vector2 = field(default_factory=pygame.Vector2)
    aim_direction: pygame.Vector2 = field(
        default_factory=lambda: pygame.Vector2(1.0, 0.0)
    )
    weapon: Weapon = field(default_factory=Weapon)
    melee_hit_count: int = 0
    melee_invincible: float = 0.0
    # Squad dash: follows the leader's dash direction for half the
    # distance, with no i-frames and no disappearing.
    dash_dir: pygame.Vector2 = field(
        default_factory=lambda: pygame.Vector2(1.0, 0.0)
    )
    dash_speed: float = 0.0
    dash_timer: float = 0.0
    dash_traveled: float = 0.0
    dash_distance_limit: float = 0.0
    health: Health = field(
        default_factory=lambda: Health(settings.SQUAD_MAX_HEALTH)
    )
    portrait_id: int = 0
    avatar: pygame.Surface | None = field(default=None, repr=False, compare=False)
    neutral_avatar: pygame.Surface | None = field(
        default=None,
        repr=False,
        compare=False,
    )

    def __post_init__(self) -> None:
        """Connect health death to the member lifecycle once."""
        self.health.add_death_callback(self._on_death)

    @property
    def is_alive(self) -> bool:
        """Return whether the member can participate in combat."""
        return (
            self.state is not SquadMemberState.DEAD
            and not self.health.is_dead
        )

    @property
    def dashing(self) -> bool:
        """Return whether the squad dash burst is currently moving."""
        return self.dash_timer > 0.0 and self.dash_speed > 0.0

    def start_dash(
        self,
        direction: pygame.Vector2,
        speed: float,
        duration: float,
        distance_limit: float,
    ) -> None:
        """Burst along the leader's dash direction (no i-frames)."""
        if distance_limit <= 0.0:
            return
        heading = pygame.Vector2(direction)
        if heading.length_squared() <= 0.000001:
            heading = pygame.Vector2(1.0, 0.0)
        self.dash_dir = heading.normalize()
        self.dash_speed = float(speed)
        self.dash_timer = float(duration)
        self.dash_traveled = 0.0
        self.dash_distance_limit = float(distance_limit)

    def _update_dash(self, delta_time: float) -> bool:
        """Advance the squad dash; return True while it owns the movement."""
        if not self.dashing:
            return False
        safe_delta = max(delta_time, 0.0)
        self.dash_speed = max(
            0.0, self.dash_speed - settings.MELEE_DASH_DECEL * safe_delta
        )
        remaining = self.dash_distance_limit - self.dash_traveled
        step = min(self.dash_speed * safe_delta, max(0.0, remaining))
        self.position += self.dash_dir * step
        self.dash_traveled += step
        self.dash_timer -= safe_delta
        self.velocity = self.dash_dir * self.dash_speed
        if (
            self.dash_traveled >= self.dash_distance_limit - 0.001
            or self.dash_timer <= 0.0
            or self.dash_speed <= 0.0
        ):
            self.dash_timer = 0.0
            self.dash_speed = 0.0
        return True

    def update_follow(
        self,
        target_position: pygame.Vector2,
        delta_time: float,
        fallback_aim_direction: pygame.Vector2,
        speed: float | None = None,
    ) -> None:
        """Move toward a sampled path point without overshooting it."""
        if self.state is not SquadMemberState.FOLLOWING:
            self.velocity.update(0.0, 0.0)
            return
        if self._update_dash(delta_time):
            return  # the squad dash owns movement while it lasts

        follow_speed = self.follow_speed if speed is None else max(0.0, speed)
        difference = pygame.Vector2(target_position) - self.position
        distance = difference.length()
        if distance <= 0.0001:
            self.position = pygame.Vector2(target_position)
            self.velocity.update(0.0, 0.0)
            self._use_fallback_aim(fallback_aim_direction)
            return

        direction = difference / distance
        travel_distance = min(distance, follow_speed * max(delta_time, 0.0))
        self.position += direction * travel_distance
        self.velocity = direction * (travel_distance / delta_time) if delta_time > 0 else pygame.Vector2()
        self.aim_direction = direction

    def update_formation_slot(
        self,
        player_position: pygame.Vector2,
        player_velocity: pygame.Vector2,
        target_offset: pygame.Vector2,
        delta_time: float,
        rotation_speed: float,
        fallback_aim_direction: pygame.Vector2,
    ) -> None:
        """Follow the leader and rotate around it toward the wing slot.

        Translation mirrors the leader exactly; the remaining motion is a
        rotation around the leader plus radial convergence to the slot ring,
        both capped by rotation_speed so members swing around the player at
        up to that linear speed instead of cutting through it.
        """
        if self.state is not SquadMemberState.FOLLOWING:
            self.velocity.update(0.0, 0.0)
            return
        if self._update_dash(delta_time):
            return  # the squad dash owns movement while it lasts

        safe_delta = max(delta_time, 0.0)
        previous = pygame.Vector2(self.position)
        leader = pygame.Vector2(player_position)

        # Translation: share the leader's velocity exactly.
        self.position += pygame.Vector2(player_velocity) * safe_delta

        # Rotation around the leader and radial convergence to the slot.
        offset = self.position - leader
        target = pygame.Vector2(target_offset)
        if offset.length_squared() <= 0.000001:
            self.position = leader + target
        else:
            step_distance = max(0.0, rotation_speed) * safe_delta
            current_radius = offset.length()
            current_angle = degrees(atan2(offset.y, offset.x))
            target_angle = degrees(atan2(target.y, target.x))
            angle_delta = (target_angle - current_angle + 180.0) % 360.0 - 180.0
            max_angle = degrees(
                step_distance / max(current_radius, 0.0001)
            )
            applied_angle = max(-max_angle, min(max_angle, angle_delta))
            new_angle = radians(current_angle + applied_angle)
            offset = pygame.Vector2(
                cos(new_angle), sin(new_angle)
            ) * current_radius

            radius_delta = target.length() - offset.length()
            if radius_delta != 0.0:
                radius_step = max(
                    -step_distance, min(step_distance, radius_delta)
                )
                new_radius = max(0.0, offset.length() + radius_step)
                if new_radius > 0.0:
                    offset = offset.normalize() * new_radius
                else:
                    offset = pygame.Vector2()
            self.position = leader + offset

        if safe_delta > 0.0:
            self.velocity = (self.position - previous) / safe_delta
        else:
            self.velocity = pygame.Vector2(player_velocity)

        movement = self.position - previous
        if movement.length_squared() > 0.000001:
            self.aim_direction = movement.normalize()
        else:
            self._use_fallback_aim(fallback_aim_direction)

    def render(self, surface: pygame.Surface, camera: Camera) -> None:
        """Draw the member and its current facing direction."""
        screen_position = camera.world_to_screen(self.position)
        center = (round(screen_position.x), round(screen_position.y))
        color = (
            settings.SQUAD_DEAD_COLOR
            if self.state is SquadMemberState.DEAD
            else settings.SQUAD_MEMBER_COLOR
        )
        aim_end = screen_position + self.aim_direction * 38.0

        if self.state is not SquadMemberState.DEAD:
            pygame.draw.line(
                surface,
                settings.SQUAD_AIM_COLOR,
                center,
                (round(aim_end.x), round(aim_end.y)),
                3,
            )
        pygame.draw.circle(surface, color, center, round(self.radius))
        if self.avatar is not None and self.state is not SquadMemberState.DEAD:
            surface.blit(self.avatar, self.avatar.get_rect(center=center))
        pygame.draw.circle(
            surface,
            settings.SQUAD_MEMBER_OUTLINE_COLOR,
            center,
            round(self.radius),
            2,
        )
        draw_health_bar(
            surface,
            screen_position,
            self.health,
            46,
            self.radius + 7,
        )

    def update_combat(
        self,
        delta_time: float,
        player_aim_direction: pygame.Vector2,
        projectile_pool: ProjectilePool,
        firing: bool,
    ) -> None:
        """Face and continuously fire along the player's mouse aim."""
        if self.state is not SquadMemberState.FOLLOWING:
            return

        self.weapon.update(delta_time)
        if player_aim_direction.length_squared() > 0.000001:
            self.aim_direction = player_aim_direction.normalize()
            if firing:
                self.weapon.try_fire_direction(
                    self,
                    self.aim_direction,
                    projectile_pool,
                )

    def receive_melee_hit(self, damage: int, attacker: object | None = None) -> None:
        """Convert a melee strike into shared damage data."""
        if damage > 0 and self.is_alive:
            self.melee_hit_count += 1
            attacker_faction = getattr(attacker, "faction", Faction.ENEMY)
            self.receive_damage(
                DamageInfo(
                    damage,
                    attacker,
                    attacker_faction,
                    self.position.copy(),
                    "melee",
                )
            )

    def receive_damage(self, damage: DamageInfo) -> bool:
        """Apply damage through the shared health component."""
        if self.melee_invincible > 0.0:
            return False
        return self.health.take_damage(damage)

    def _on_death(self, damage: DamageInfo) -> None:
        """Stop all behavior when health reaches zero."""
        del damage
        self.state = SquadMemberState.DEAD
        self.velocity.update(0.0, 0.0)

    def _use_fallback_aim(self, fallback: pygame.Vector2) -> None:
        if fallback.length_squared() > 0.000001:
            self.aim_direction = fallback.normalize()
