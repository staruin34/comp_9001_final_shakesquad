"""Rest-area weapon stations that equip the protagonist's attack style."""

from dataclasses import dataclass

import pygame

from game import assets, settings


@dataclass
class WeaponPickup:
    """A persistent weapon station in the rest area.

    The player walks onto a station to select a weapon: the sword station
    grants sword ownership on first touch (the melee kit) and equips it;
    the pistol station equips the always-owned pistol. Stations are never
    consumed, so the rest area stays a reusable prep zone.
    """

    kind: str
    position: pygame.Vector2
    radius: float = settings.WEAPON_PICKUP_RADIUS

    @property
    def is_alive(self) -> bool:
        """Stations never expire."""
        return True

    def update(self, player) -> bool:
        """Equip the station's weapon when the living player touches it."""
        if not player.is_alive:
            return False
        if player.position.distance_squared_to(self.position) <= self.radius ** 2:
            if self.kind == "sword":
                player.has_sword = True
            if player.weapon_kind != self.kind:
                player.weapon_kind = self.kind
                return True
        return False

    def render(self, surface: pygame.Surface, camera, selected: bool = False) -> None:
        """Draw the waiting station as a colored ring with a core dot."""
        screen_position = camera.world_to_screen(self.position)
        center = (round(screen_position.x), round(screen_position.y))
        color = (
            settings.PICKUP_SWORD_COLOR
            if self.kind == "sword"
            else settings.PICKUP_PISTOL_COLOR
        )
        pygame.draw.circle(surface, color, center, round(self.radius), 3)
        pygame.draw.circle(surface, color, center, 7)
        icon = assets.item("weapon_" + self.kind)
        if icon is not None:
            icon = pygame.transform.scale(icon, (26, 26))
            surface.blit(icon, icon.get_rect(center=center))
        if selected:
            pygame.draw.circle(
                surface,
                settings.ACCENT_COLOR,
                center,
                round(self.radius) + 5,
                2,
            )
