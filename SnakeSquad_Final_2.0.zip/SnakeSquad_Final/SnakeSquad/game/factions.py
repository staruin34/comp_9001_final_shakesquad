"""Central faction definitions and hostility rules."""

from enum import Enum, auto


class Faction(Enum):
    """Combat allegiance assigned to every targetable entity."""

    NEUTRAL = auto()
    PLAYER = auto()
    PLAYER_SQUAD = auto()
    ENEMY = auto()


def is_hostile(source: Faction, target: Faction) -> bool:
    """Return whether source may damage target with friendly fire disabled."""
    if source is Faction.NEUTRAL or target is Faction.NEUTRAL:
        return False
    player_side = {Faction.PLAYER, Faction.PLAYER_SQUAD}
    return (source in player_side and target is Faction.ENEMY) or (
        source is Faction.ENEMY and target in player_side
    )
