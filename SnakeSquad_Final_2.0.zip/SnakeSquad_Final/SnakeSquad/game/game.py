"""Main application coordinator and the single Pygame loop."""

import random

import pygame

from game import assets, settings
from game.input_state import InputState
from game.level import Level
from game.audio import play_battle_bgm, stop_battle_bgm, tick as bgm_tick
from game.states import GameState
from game.ui.settings_ui import SettingsUI
from game.ui.hud import HUD
from game.ui.character_select import CharacterSelectScreen


class Game:
    """Coordinate input, simulation state, and rendering."""

    def __init__(self, stress_test: bool = False) -> None:
        pygame.init()
        pygame.display.set_caption(settings.WINDOW_TITLE)
        self.screen = pygame.display.set_mode(
            (settings.SCREEN_WIDTH, settings.SCREEN_HEIGHT)
        )
        self.world_surface = pygame.Surface(settings.WORLD_VIEW_SIZE).convert()
        pygame.display.flip()
        self._bring_window_to_front()
        self.clock = pygame.time.Clock()
        self.stress_test = stress_test
        self.current_level_number = 1
        self.level = Level(
            stress_test=stress_test,
            level_number=self.current_level_number,
        )
        self.hud = HUD()
        self.character_select = CharacterSelectScreen()
        self.selected_character: int | None = None
        self.input_state = InputState()
        self.state = (
            GameState.PLAYING if stress_test else GameState.CHARACTER_SELECT
        )
        self.debug_visible = False
        self.running = True
        self._melee_attack_queued = False
        self._melee_dash_queued = False
        self._melee_preview = False
        # the big parameter panel is hidden until O is pressed
        self.params_visible = False
        self.settings_ui = SettingsUI()

    @staticmethod
    def _bring_window_to_front() -> None:
        """Request foreground focus so keyboard input works immediately.

        Best-effort: Windows may refuse under foreground-lock rules, in
        which case the focus-gained resync in InputState still recovers.
        """
        try:
            window_info = pygame.display.get_wm_info()
            handle = window_info.get("window")
            if handle:
                import ctypes

                ctypes.windll.user32.SetForegroundWindow(handle)
        except Exception:
            pass

    def run(self) -> None:
        """Run the only event/update/render loop in the application."""
        try:
            while self.running:
                delta_time = min(
                    self.clock.tick(settings.TARGET_FPS) / 1000.0,
                    settings.MAX_DELTA_TIME,
                )
                self.handle_events()
                self.update(delta_time)
                self.render()
                pygame.display.flip()
        finally:
            pygame.quit()

    def handle_events(self) -> None:
        """Process window and application-level keyboard events."""
        for event in pygame.event.get():
            self.input_state.handle_event(event)
            if event.type == pygame.QUIT:
                self.running = False
            elif self.state is GameState.CHARACTER_SELECT:
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    selected = self.character_select.character_at_position(event.pos)
                    if selected is not None:
                        self._select_character(selected)
                elif event.type == pygame.KEYDOWN and event.key in (
                    pygame.K_1,
                    pygame.K_2,
                ):
                    self._select_character(event.key - pygame.K_1)
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                self._toggle_pause()
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_F1:
                self.debug_visible = not self.debug_visible
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_r:
                self.restart_level()
            elif (
                self.state is GameState.PLAYING
                and self.settings_ui.handle_event(event)
            ):
                pass  # the settings panel consumed this mouse event
            elif (
                event.type == pygame.KEYDOWN
                and event.key == pygame.K_o
                and self.state is GameState.PLAYING
            ):
                self.params_visible = not self.params_visible
            elif (
                event.type == pygame.KEYDOWN
                and event.key == pygame.K_j
                and self.state is GameState.PLAYING
            ):
                self._melee_attack_queued = True
            elif (
                event.type == pygame.MOUSEBUTTONDOWN
                and event.button == 1
                and self.state is GameState.PLAYING
            ):
                # melee attacks trigger on left click, exactly like ranged
                self._melee_attack_queued = True
            elif (
                event.type == pygame.KEYDOWN
                and event.key == pygame.K_SPACE
                and self.state is GameState.PLAYING
            ):
                self._melee_dash_queued = True
            elif (
                event.type == pygame.KEYDOWN
                and event.key == pygame.K_f
                and self.state is GameState.PLAYING
            ):
                self.level.switch_weapon()
            elif (
                event.type == pygame.KEYDOWN
                and event.key == pygame.K_TAB
                and self.state is GameState.PLAYING
            ):
                self._melee_preview = True
            elif event.type == pygame.KEYUP and event.key == pygame.K_TAB:
                self._melee_preview = False
            elif (
                event.type == pygame.KEYDOWN
                and event.key == pygame.K_n
                and self.state is GameState.VICTORY
            ):
                self.start_next_level()

    def update(self, delta_time: float) -> None:
        """Advance game logic only while the level is active."""
        if self.state is GameState.PLAYING:
            if self.input_state.has_focus:
                self.input_state.sync_from_keyboard()
            movement_direction = self.level.player.movement_direction(
                left=self.input_state.is_pressed(pygame.K_a),
                right=self.input_state.is_pressed(pygame.K_d),
                up=self.input_state.is_pressed(pygame.K_w),
                down=self.input_state.is_pressed(pygame.K_s),
            )
            mouse_x, mouse_y = pygame.mouse.get_pos()
            # Aim in the larger world viewport while UI input stays in window pixels.
            mouse_screen_position = pygame.Vector2(
                mouse_x * self.world_surface.get_width() / self.screen.get_width(),
                mouse_y * self.world_surface.get_height() / self.screen.get_height(),
            )
            self.level.update(
                delta_time,
                movement_direction,
                mouse_screen_position,
                self.input_state.is_mouse_pressed(1),
                self._melee_attack_queued,
                self._melee_dash_queued,
            )
# Start battle music in combat; stop it outside combat or after settlement.
            if self.level.combat_active:
                play_battle_bgm()
            else:
                stop_battle_bgm()
            bgm_tick()
            self._melee_attack_queued = False
            self._melee_dash_queued = False
# The hidden window leads directly to level four (survival mode).
            if getattr(self.level, "secret_level4_entered", False):
                # hidden window in level three: enter the survival level
                self.level.secret_level4_entered = False
                self.current_level_number = settings.LEVEL_4_NUMBER
                self.restart_level()
                return
            if getattr(self.level, "wave_finished", False):
                self.finish_level(GameState.VICTORY)
                return
            if self.level.secret_passage_entered:
                # hidden rest-area passage: jump straight to level three
                self.level.secret_passage_entered = False
                self.current_level_number = settings.SECRET_PASSAGE_TARGET_LEVEL
                self.restart_level()
                return
            if not self.level.player.is_alive:
                self.finish_level(GameState.DEFEAT)
            elif self.level.victory_achieved:
                self.finish_level(GameState.VICTORY)

    def render(self) -> None:
        """Render the world first and the screen-space HUD last."""
        if self.state is GameState.CHARACTER_SELECT:
            self.character_select.render(self.screen)
            return
        self.screen.fill(settings.BACKGROUND_COLOR)
        self.level.render(
            self.world_surface,
            self.debug_visible,
            melee_preview=self._melee_preview and self.level.melee_enabled,
        )
        pygame.transform.scale(
            self.world_surface, self.screen.get_size(), self.screen
        )
        self.hud.render(
            self.screen,
            self.state,
            self.clock.get_fps(),
            self.level.player.position,
            self.level.player.velocity,
            self.level.camera.offset,
            self.level.mouse_world_position,
            self.level.path_history.point_count,
            self.level.path_history.total_length,
            self.debug_visible,
            self.level.squad.member_count,
            self.level.rescued_count,
            sum(not target.rescued for target in self.level.rescue_targets),
            self.level.remaining_enemy_count,
            self.level.projectile_pool.active_count,
            self.level.projectile_pool.capacity,
            self.level.projectile_pool.ink_reveal_count,
            sum(enemy.successful_attacks for enemy in self.level.enemies),
            self.level.player.health.current_health,
            self.level.player.health.max_health,
            self.stress_test,
            self.level.level_number,
            settings.LEVEL_COUNT,
            self.level.elite_enemy_count,
            self.level.elite_barrage.bullet_count,
            settings.BOSS_NAME if self.level.boss is not None else None,
            self.level.boss_health,
            self.level.boss_barrage.bullet_count,
            self.level.squad.formation_index,
            self.level.squad.formation_count,
            self.level.squad.formation_name,
            self.level.squad.formation_cooldown_remaining,
            self.level.squad.player_speed_multiplier,
            self.level.player.weapon_kind,
            self.level.player.has_sword,
            self.level.melee_status_line(),
            self.level.melee.dash_remaining(),
            self._area_hint(),
            self.level.player.shield,
            show_params=self.params_visible,
            basket_eggs=getattr(self.level, "egg_bank", 0),
        )

        self.settings_ui.render(self.screen)

        # Camera shake after melee swings (world plus HUD, like the source).
        # Only while playing: the shake decays inside the level update, so a
        # leftover value would keep jittering pause/victory screens forever.
        if self.state is GameState.PLAYING and self.level.melee.shake > 0.0:
            ratio = self.level.melee.shake / settings.MELEE_SHAKE_TIME
            dx = random.uniform(-1.0, 1.0) * settings.MELEE_SHAKE_MAG * ratio
            dy = random.uniform(-1.0, 1.0) * settings.MELEE_SHAKE_MAG * ratio
            shaken = self.screen.copy()
            self.screen.fill(settings.BACKGROUND_COLOR)
            self.screen.blit(shaken, (round(dx), round(dy)))

    def finish_level(self, result: GameState) -> bool:
        """Enter a terminal state once and reject repeated settlement."""
        if self.state is not GameState.PLAYING:
            return False
        if result not in (GameState.VICTORY, GameState.DEFEAT):
            raise ValueError("result must be VICTORY or DEFEAT")
        self.state = result
        stop_battle_bgm()
        # a finishing melee blow leaves shake pending: clear it so the
        # result screen does not tremble after the level update stops
        self.level.melee.shake = 0.0
        self.input_state.clear()
        return True

    def restart_level(self) -> None:
        """Recreate all mutable level state from its initial configuration."""
        stop_battle_bgm()
        avatar = None
        selected_character = getattr(self, "selected_character", None)
        if selected_character is not None:
            avatar = self.character_select.battle_avatar(
                selected_character,
                round(settings.PLAYER_RADIUS * 2),
            )
        self.level = Level(
            stress_test=self.stress_test,
            player_avatar=avatar,
            player_sprite=getattr(self, "selected_sprite", "player"),
            level_number=getattr(self, "current_level_number", 1),
        )
        self.state = GameState.PLAYING
        self.input_state.clear()
        # Recover keys that are physically held (e.g. W held while clicking
        # the avatar or pressing R/N), whose KEYDOWN events already passed.
        self.input_state.sync_from_keyboard()

    def start_next_level(self) -> bool:
        """Advance after victory when another configured level exists."""
        current = getattr(self, "current_level_number", 1)
        if self.state is not GameState.VICTORY or current >= settings.LEVEL_COUNT:
            # level four is hidden: only the secret window can start it

            return False
        self.current_level_number = current + 1
        self.restart_level()
        return True

    def _select_character(self, index: int) -> None:
        """Apply one selected hero and start a fresh playable level."""
        if not 0 <= index < len(settings.PLAYER_CHARACTERS):
            return
        self.selected_character = index
        self.selected_sprite = settings.PLAYER_CHARACTERS[index][0]
        self.restart_level()

    def _area_hint(self) -> str | None:
        """Return the dungeon area hint for the HUD, or None."""
        if not self.level.dungeon_enabled:
            return None
        if not self.level.combat_active:
            return "休息区 · 触碰武器台选择武器 · 向右进入战斗区"
        if self.level.gate_locked:
            return "战斗区 · 击败所有敌人前无法离开"
        return None

    def _clear_melee_shake(self) -> None:
        """Stop camera shake when the level stops updating (pause/result)."""
        melee = getattr(self.level, "melee", None)
        if melee is not None:
            melee.shake = 0.0

    def _toggle_pause(self) -> None:
        """Switch between active play and pause without affecting end states."""
        if self.state is GameState.PLAYING:
            self.state = GameState.PAUSED
            self._clear_melee_shake()
            self.input_state.clear()
        elif self.state is GameState.PAUSED:
            self.state = GameState.PLAYING
            self.input_state.sync_from_keyboard()
