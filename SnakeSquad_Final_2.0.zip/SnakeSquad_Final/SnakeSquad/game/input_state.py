"""Event-driven keyboard state used by the main game loop."""

from dataclasses import dataclass, field

import pygame


MOVEMENT_KEYS = frozenset(
    (pygame.K_w, pygame.K_a, pygame.K_s, pygame.K_d)
)


@dataclass
class InputState:
    """Track held movement keys from KEYDOWN and KEYUP events."""

    pressed_keys: set[int] = field(default_factory=set)
    pressed_mouse_buttons: set[int] = field(default_factory=set)
    has_focus: bool = True

    def handle_event(self, event: pygame.event.Event) -> None:
        """Apply one keyboard or focus event to the held-key set."""
        if event.type == pygame.KEYDOWN and event.key in MOVEMENT_KEYS:
            self.pressed_keys.add(event.key)
        elif event.type == pygame.KEYUP and event.key in MOVEMENT_KEYS:
            self.pressed_keys.discard(event.key)
        elif event.type == pygame.MOUSEBUTTONDOWN:
            self.pressed_mouse_buttons.add(event.button)
        elif event.type == pygame.MOUSEBUTTONUP:
            self.pressed_mouse_buttons.discard(event.button)
        elif event.type == pygame.WINDOWFOCUSLOST:
            self.has_focus = False
            self.clear()
        elif event.type == pygame.WINDOWFOCUSGAINED:
            self.has_focus = True
            # The OS may have swallowed KEYUP events while unfocused;
            # rebuild the held-key set from the physical keyboard state.
            self.sync_from_keyboard()

    def sync_from_keyboard(self) -> None:
        """Rebuild held movement keys from the physical keyboard state.

        This repairs input whenever events were missed: after focus blips,
        after entering the game with a key already held down, or after any
        transition that cleared the tracked keys.
        """
        if not pygame.get_init():
            return
        try:
            pressed = pygame.key.get_pressed()
        except pygame.error:
            return
        self.pressed_keys = {
            key for key in MOVEMENT_KEYS if pressed[key]
        }

    def is_pressed(self, key: int) -> bool:
        """Return whether a key is currently considered held."""
        return key in self.pressed_keys

    def is_mouse_pressed(self, button: int) -> bool:
        """Return whether a mouse button is currently held."""
        return button in self.pressed_mouse_buttons

    def clear(self) -> None:
        """Release all tracked keys, such as when focus is lost."""
        self.pressed_keys.clear()
        self.pressed_mouse_buttons.clear()
