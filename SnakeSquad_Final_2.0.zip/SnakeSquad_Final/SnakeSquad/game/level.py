"""Level ownership, world updates, and camera-aware rendering."""

import math
import random

import pygame

from game import assets, settings
from game.camera import Camera
from game.combat.melee import MeleeKit
from game.combat.projectile_pool import ProjectilePool
from game.combat.elite_barrage import EliteBarrage
from game.combat.elite_bombs import EliteBombs
from game.combat.enemy_missile import MissileField
from game.entities.iron_ball import IronBallField
from game.combat.boss_barrage import BossBarrage
from game.entities.enemy import Enemy
from game.entities.elite_enemy import EliteEnemy
from game.entities.boss_enemy import BossEnemy
from game.entities.player import Player
from game.entities.slime_enemy import SlimeEnemy
from game.entities.rescue_target import RescueTarget
from game.entities.weapon_pickup import WeaponPickup
from game.entities.squad_member import SquadMember
from game.squad.path_history import PathHistory
from game.squad.squad_manager import SquadManager
from game.ui.melee_fx import render_melee
from game.ui.squad_portraits import SquadPortraitSet
from game.ui.enemy_portraits import EnemyPortraitSet


class Level:
    """Own map bounds, the player, and the stage camera."""

    def __init__(
        self,
        stress_test: bool = False,
        player_avatar: pygame.Surface | None = None,
        player_sprite: str = "player",
        level_number: int = 1,
    ) -> None:
        if not 1 <= level_number <= settings.LEVEL_COUNT + 1:
            raise ValueError(f"level_number must be between 1 and {settings.LEVEL_COUNT}")
        self.stress_test = stress_test
        self.level_number = level_number
# Hidden level four reuses level three and enables survival spawning.
        self.wave_mode = level_number == settings.LEVEL_4_NUMBER
        self.wave_time_left = (
            settings.LEVEL_4_DURATION if self.wave_mode else 0.0
        )
        self.wave_finished = False
        self.secret_level4_entered = False
        self.egg_count = 0
        self.egg_bank = 0  # every egg ever collected (basket settlement)
        self.eggs: list[pygame.Vector2] = []
        self._egg_timer = settings.LEVEL_4_EGG_INTERVAL
        self._spawn_timers = {
            "ranged": settings.LEVEL_4_RANGED_INTERVAL,
            "melee": settings.LEVEL_4_MELEE_INTERVAL,
            "elite": settings.LEVEL_4_ELITE_INTERVAL,
            "boss": settings.LEVEL_4_BOSS_INTERVAL,
        }
        self.bounds = pygame.Rect(
            0,
            0,
            settings.WORLD_WIDTH,
            settings.WORLD_HEIGHT,
        )
        self.player = Player(
            position=pygame.Vector2(settings.PLAYER_START),
            radius=settings.PLAYER_RADIUS,
            avatar=player_avatar,
            sprite_kind=player_sprite,
        )
        self.camera = Camera(
            settings.WORLD_VIEW_SIZE,
            self.bounds,
            settings.CAMERA_FOLLOW_SHARPNESS,
        )
        self.camera.snap_to(self.player.position)
        self.mouse_world_position = self.player.position.copy()
        self.melee = MeleeKit(self.player)
        self.path_history = PathHistory(
            self.player.position,
            settings.PATH_RECORD_SPACING,
            settings.PATH_MAX_POINTS,
            settings.PATH_MAX_LENGTH,
        )
        self.squad_portraits = SquadPortraitSet()
        self.enemy_portraits = EnemyPortraitSet()
        self.squad = SquadManager()
        squad_count = (
            settings.STRESS_SQUAD_COUNT
            if stress_test
            else settings.SQUAD_TEST_MEMBER_COUNT
        )
        self._create_test_squad(squad_count)
        self.rescue_targets = self._create_rescue_targets()
        self.rescued_count = 0
        self.weapon_pickups = self._create_weapon_pickups()
        # Dungeon layout: rest area -> corridor -> combat arena. The gate locks
        # until all enemies die. Stress mode uses the full map and skips these bounds.
        self.dungeon_enabled = not stress_test
        self.combat_active = not self.dungeon_enabled
        enemy_count = settings.STRESS_ENEMY_COUNT if stress_test else (
            settings.LEVEL_ONE_ENEMY_COUNT
            if level_number == 1
            else settings.LEVEL_TWO_ENEMY_COUNT
        )
        self.enemies = self._create_enemies(enemy_count)
        if not stress_test:
            self._create_slimes()
        if not stress_test and level_number >= 2:
            self._add_elite_enemies(settings.LEVEL_TWO_ELITE_COUNT)
        self.boss: BossEnemy | None = None
        content_level = 3 if self.wave_mode else level_number
        if not stress_test and content_level == 3:
            self.boss = BossEnemy(position=pygame.Vector2(1467.0, 838.0))
            self.enemies.append(self.boss)
        self.elite_barrage = EliteBarrage()
        self.elite_bombs = EliteBombs()
        self.iron_balls = IronBallField()
        self.enemy_missiles = MissileField()
        self.secret_passage_entered = False
        self.boss_barrage = BossBarrage()
        self.projectile_pool = ProjectilePool(
            settings.PROJECTILE_POOL_INITIAL_SIZE
        )

    # ---------------- hidden level four (survival) ----------------
    def _random_spawn_point(self) -> pygame.Vector2:
        margin = settings.LEVEL_4_SPAWN_MARGIN
        bounds = self.combat_bounds.inflate(-margin * 2, -margin * 2)
        return pygame.Vector2(
            random.uniform(bounds.left, bounds.right),
            random.uniform(bounds.top, bounds.bottom),
        )

    def _spawn_wave_enemy(self, kind: str) -> None:
        """Spawn one minion/elite/boss at a random arena position."""
        point = self._random_spawn_point()
        if kind == "ranged":
            self.enemies.append(Enemy(position=point))
        elif kind == "melee":
            self.enemies.append(SlimeEnemy(position=point))
        elif kind == "elite":
            self.enemies.append(EliteEnemy(position=point))
        elif kind == "boss":
            boss = BossEnemy(position=self.combat_bounds.center)
            self.enemies.append(boss)
            self.boss = boss

    def _add_wave_teammate(self) -> None:
        portrait_id = random.randrange(settings.SQUAD_PORTRAIT_COUNT)
        member = SquadMember(
            position=self.player.position.copy(),
            radius=settings.SQUAD_MEMBER_RADIUS,
            portrait_id=portrait_id,
        )
        member.avatar = self.squad_portraits.active_avatar(
            portrait_id, round(member.radius * 2)
        )
        member.neutral_avatar = self.squad_portraits.neutral_avatar(
            portrait_id, round(member.radius * 2)
        )
        if self.squad.add_member(member, self.path_history):
            self.rescued_count += 1

    def _update_wave_mode(self, delta_time: float) -> None:
        """Spawn waves, place eggs and settle the survival timer."""
        if not self.wave_mode or self.wave_finished or not self.combat_active:
            return
        self.wave_time_left = max(0.0, self.wave_time_left - delta_time)
        if self.wave_time_left <= 0.0:
            self.wave_finished = True
            return
        intervals = {
            "ranged": settings.LEVEL_4_RANGED_INTERVAL,
            "melee": settings.LEVEL_4_MELEE_INTERVAL,
            "elite": settings.LEVEL_4_ELITE_INTERVAL,
            "boss": settings.LEVEL_4_BOSS_INTERVAL,
        }
        for kind, interval in intervals.items():
            self._spawn_timers[kind] -= delta_time
            if self._spawn_timers[kind] <= 0.0:
                self._spawn_timers[kind] += interval
                self._spawn_wave_enemy(kind)

# Spawn a fish egg at a random arena position every seven seconds.
        self._egg_timer -= delta_time
        if self._egg_timer <= 0.0:
            self._egg_timer += settings.LEVEL_4_EGG_INTERVAL
            self.eggs.append(self._random_spawn_point())

# Pick up nearby eggs automatically, up to ten; also track the basket total.
        radius = settings.LEVEL_4_EGG_PICKUP_RADIUS
        remaining = []
        for egg in self.eggs:
            if (
                self.player.position.distance_to(egg) <= radius
                and self.egg_count < settings.LEVEL_4_EGG_MAX
            ):
                self.egg_count += 1
                self.egg_bank += 1
                continue
            remaining.append(egg)
        self.eggs = remaining

# Enter the centre counter: exchange more than two eggs for a teammate and 20 HP, then reset.
        center = pygame.Vector2(self.combat_bounds.center)
        if self.egg_rect().collidepoint(self.player.position):
            if self.egg_count > settings.LEVEL_4_SQUAD_EGG_COST:
                self._add_wave_teammate()
                self.player.health.heal(settings.LEVEL_4_SQUAD_HEAL)
            self.egg_count = 0

    def egg_rect(self) -> pygame.Rect:
        """Deposit area = a rectangle the size of the counter frame."""
        counter = assets.item("egg_counter")
        width = counter.get_width() if counter is not None else 103
        height = counter.get_height() if counter is not None else 120
        rect = pygame.Rect(0, 0, width, height)
        rect.center = self.combat_bounds.center
        return rect

    def _render_wave_eggs(self, surface: pygame.Surface) -> None:
        """Carried eggs: one on the protagonist tail, one per teammate, plus a
        small Arabic number for the count stacked on the protagonist."""
        if not self.wave_mode or self.egg_count <= 0:
            return
        egg = assets.item("fish_egg")
        if egg is None:
            return
        mini = pygame.transform.smoothscale(
            egg, (max(6, egg.get_width() * 2 // 3), max(6, egg.get_height() * 2 // 3))
        )
        members = [m for m in self.squad.members if getattr(m, "is_alive", False)]
        carried = min(len(members), max(0, self.egg_count - 1))
        for index in range(carried):
            member = members[index]
            screen = self.camera.world_to_screen(member.position)
            surface.blit(
                mini,
                mini.get_rect(center=(round(screen.x) - 16, round(screen.y) - 30)),
            )
        share = self.egg_count - carried
        if share <= 0:
            return
        base = self.camera.world_to_screen(self.player.position)
        try:
            facing = self.player._sprite_facing()
        except Exception:
            facing = pygame.Vector2(1.0, 0.0)
        side = -1 if facing.x >= 0 else 1  # the tail is behind the facing side
        for index in range(min(share, 4)):
            offset_x = side * (30 + index * 13)
            offset_y = 16 - index * 4
            surface.blit(
                mini,
                mini.get_rect(
                    center=(round(base.x + offset_x), round(base.y + offset_y))
                ),
            )
        font = pygame.font.Font(None, 20)  # smaller than the egg icon
        label = font.render(str(share), True, (255, 240, 160))
        surface.blit(
            label,
            label.get_rect(
                center=(round(base.x + side * 30), round(base.y + 30))
            ),
        )

    def _render_wave_mode(self, surface: pygame.Surface) -> None:
        """Draw fish eggs and the centre counter frame."""
        if not self.wave_mode:
            return
        egg_sprite = assets.item("fish_egg")
        for egg in self.eggs:
            screen = self.camera.world_to_screen(egg)
            if egg_sprite is not None:
                surface.blit(
                    egg_sprite,
                    egg_sprite.get_rect(center=(round(screen.x), round(screen.y))),
                )
            else:
                pygame.draw.circle(
                    surface, (255, 210, 90), (round(screen.x), round(screen.y)), 8
                )
        counter = assets.item("egg_counter")
        center = self.camera.world_to_screen(pygame.Vector2(self.combat_bounds.center))
        if counter is not None:
            surface.blit(
                counter,
                counter.get_rect(center=(round(center.x), round(center.y) - 40)),
            )
        font = pygame.font.Font(None, 26)
        label = font.render(
            "EGGS %d/%d   %02d:%02d"
            % (
                self.egg_count,
                settings.LEVEL_4_EGG_MAX,
                int(self.wave_time_left) // 60,
                int(self.wave_time_left) % 60,
            ),
            True,
            (255, 232, 140),
        )
        surface.blit(
            label, label.get_rect(center=(round(center.x), round(center.y) + 34))
        )
        if self.secret_level4_entered:
            return

    def _update_level4_window(self) -> None:
        """Hidden window in the level-three arena corner opens level four."""
        if self.wave_mode or self.level_number != settings.LEVEL_COUNT:
            return
        if not self.dungeon_enabled:
            return
        point = pygame.Vector2(
            settings.DUNGEON_WALL_WIDTH + 70.0,
            settings.DUNGEON_WALL_WIDTH + 70.0,
        )
        if self.player.position.distance_to(
            point
        ) <= settings.LEVEL_4_WINDOW_RADIUS:
            self.secret_level4_entered = True

    def update(
        self,
        delta_time: float,
        movement_direction: pygame.Vector2,
        mouse_screen_position: pygame.Vector2,
        firing: bool = False,
        attack_pressed: bool = False,
        dash_pressed: bool = False,
    ) -> None:
        """Move the player, follow it, then resolve world-space aiming."""
        # Resolve aiming first so melee starts use this frame's mouse target
        # instead of a stale one-frame-old direction.
        self.mouse_world_position = self.camera.screen_to_world(
            mouse_screen_position
        )
        self.player.update_aim(self.mouse_world_position)
        if self.player.is_alive:
            self.player.update_shield(delta_time)
            self.player.move_speed = (
                settings.PLAYER_SPEED * self.squad.player_speed_multiplier
            )
            # The dash kit runs for both weapons: the sword uses the full
            # dash, the pistol a half-distance dash at the same speed.
            self.melee.dash_distance_multiplier = (
                1.0 if self.melee_enabled else 0.5
            )
            self.melee.update(
                delta_time,
                movement_direction,
                self.player.aim_direction,
                attack_pressed if self.melee_enabled else False,
                dash_pressed,
                [
                    *self.enemies,
                    *self.iron_balls.balls,
                    *self.boss_barrage.ring_balls,
                ],
                self.squad.members,
            )
            if self.melee.movement_active:
                self.player.position += self.player.velocity * delta_time
                self.player.clamp_to_bounds(self.bounds)
            else:
                self.player.update_movement(
                    movement_direction,
                    delta_time,
                    self.bounds,
                )
            if not self.melee_enabled:
                # Pistol style: the player fires the same unified bullet as
                # the squad members, in any formation.
                self.player.weapon.update(delta_time)
                if firing:
                    self.player.weapon.try_fire_direction(
                        self.player,
                        self.player.aim_direction,
                        self.projectile_pool,
                    )
            self._update_dungeon_entrance()
            self._update_secret_passage()
            self._update_wave_mode(delta_time)
            self._update_level4_window()
            self._resolve_player_walls()
            if self.gate_locked:
                # Lock the arena gate until all enemies die; block retreat to the rest area.
                gate_inner = (
                    settings.DUNGEON_GATE_X
                    + settings.DUNGEON_WALL_WIDTH
                    + 2.0
                )
                self.player.position.x = max(
                    self.player.position.x, gate_inner
                )
            self.path_history.record(self.player.position)
        else:
            self.player.velocity.update(0.0, 0.0)
        self._update_rescues()
        self._update_weapon_pickups()
        self.squad.update(
            delta_time,
            self.path_history,
            self.player.aim_direction,
            self.player,
        )
        enemy_targets = [self.player, *self.squad.members]
        if self.combat_active:
            # Activate enemies after the player enters; keep them inside the arena.
            for enemy in tuple(self.enemies):
                enemy.update(
                    delta_time,
                    enemy_targets,
                    self.enemies,
                    self.combat_bounds,
                )
                if isinstance(enemy, BossEnemy):
                    enemy.update_barrage(
                        delta_time,
                        self.player.position,
                        self.boss_barrage,
                        self.iron_balls,
                    )
                elif isinstance(enemy, EliteEnemy):
                    # elites no longer fire bullet rings; they throw bombs
                    enemy.update_bombs(
                        delta_time,
                        self.player.position,
                        self.elite_bombs,
                    )
                elif isinstance(enemy, Enemy):
                    enemy.update_ranged_fire(
                        delta_time,
                        self.player.position,
                        self.projectile_pool,
                        self.enemy_missiles,
                    )
# Boss empowered iron balls and shockwaves affect only the protagonist.
        self.iron_balls.update(delta_time, self.combat_bounds, [self.player])
# Ranged-minion missiles track the player, then continue in a straight line.
        self.enemy_missiles.update(
            delta_time,
            [self.player, *self.squad.members],
            self.player.position,
        )
        self.elite_bombs.update(
            delta_time,
            [self.player, *self.squad.members],
        )
        self.boss_barrage.update(
            delta_time,
            [self.player, *self.squad.members],
        )
        # Sword style disables ranged attacks: the squad melees instead.
        if not self.melee_enabled:
            for member in tuple(self.squad.members):
                member.update_combat(
                    delta_time,
                    self.player.aim_direction,
                    self.projectile_pool,
                    firing,
                )
# Projectile targets: player, squad, rescue targets, enemies, boss balls and barrage centres.
        combat_targets = [
            self.player,
            *self.squad.members,
            *self.rescue_targets,
            *self.enemies,
            *self.iron_balls.balls,  # boss iron balls are damageable
            *self.boss_barrage.ring_balls,  # normal volley centre balls
        ]
        self.projectile_pool.update(
            delta_time,
            self.bounds,
            combat_targets,
            walls=self.wall_rects,
        )
        self.squad.flush_removals()
        self.camera.update(self.player.position, delta_time)

    def render(
        self,
        surface: pygame.Surface,
        debug_visible: bool = False,
        melee_preview: bool = False,
    ) -> None:
        """Draw visible world geometry and entities through the camera."""
        surface.fill(settings.GROUND_COLOR)

        left = int(self.camera.offset.x // settings.GRID_SIZE) * settings.GRID_SIZE
        top = int(self.camera.offset.y // settings.GRID_SIZE) * settings.GRID_SIZE
        right = min(
            self.bounds.right,
            int(self.camera.offset.x + surface.get_width()) + settings.GRID_SIZE,
        )
        bottom = min(
            self.bounds.bottom,
            int(self.camera.offset.y + surface.get_height()) + settings.GRID_SIZE,
        )

# Draw floor patches made from 16x16 tiles, with each patch spanning four cells.
        tile_size = settings.GRID_SIZE * 4  # 4x4 floor-tile mosaic
        tile_left = int(self.camera.offset.x // tile_size) * tile_size
        tile_top = int(self.camera.offset.y // tile_size) * tile_size
        floor_tile = assets.floor_tile(tile_size)
        if floor_tile is not None:
            for world_x in range(tile_left, right + tile_size, tile_size):
                for world_y in range(tile_top, bottom + tile_size, tile_size):
                    surface.blit(
                        floor_tile,
                        (
                            round(world_x - self.camera.offset.x),
                            round(world_y - self.camera.offset.y),
                        ),
                    )
        else:
            for world_x in range(tile_left, right + tile_size, tile_size):
                for world_y in range(tile_top, bottom + tile_size, tile_size):
                    if (world_x // tile_size + world_y // tile_size) % 2 == 0:
                        tile_screen = pygame.Rect(
                            round(world_x - self.camera.offset.x),
                            round(world_y - self.camera.offset.y),
                            tile_size,
                            tile_size,
                        )
                        pygame.draw.rect(surface, settings.GROUND_ALT_COLOR, tile_screen)

        # The whole map starts grey: a soft grey veil over the floor.
        if settings.MAP_GREY_VEIL[3] > 0:
            veil = pygame.Surface(surface.get_size(), pygame.SRCALPHA)
            veil.fill(settings.MAP_GREY_VEIL)
            surface.blit(veil, (0, 0))

        # The opaque ground is the upper map; shots permanently expose the
        # blue lower map before grid lines and game objects are drawn.
        self.projectile_pool.render_ink_layer(surface, self.camera)

        for x in range(left, right + 1, settings.GRID_SIZE):
            screen_x = round(x - self.camera.offset.x)
            pygame.draw.line(
                surface,
                settings.GRID_COLOR,
                (screen_x, 0),
                (screen_x, surface.get_height()),
            )
        for y in range(top, bottom + 1, settings.GRID_SIZE):
            screen_y = round(y - self.camera.offset.y)
            pygame.draw.line(
                surface,
                settings.GRID_COLOR,
                (0, screen_y),
                (surface.get_width(), screen_y),
            )

        pygame.draw.rect(
            surface,
            settings.BOUNDARY_COLOR,
            self.camera.world_rect_to_screen(self.bounds),
            settings.BOUNDARY_WIDTH,
        )
        self._render_dungeon(surface)
        self._render_secret_passage(surface)
        self._render_wave_mode(surface)
        if debug_visible:
            self._render_path_history(surface)
            self._render_rescue_ranges(surface)
        for target in self.rescue_targets:
            target.render_waiting(surface, self.camera)
        for pickup in self.weapon_pickups:
            pickup.render(
                surface,
                self.camera,
                selected=pickup.kind == self.player.weapon_kind,
            )
        # defeated bodies sit on the bottom layer so living enemies cover them
# Draw defeated bodies before living enemies so they remain underneath.
        dead = [e for e in self.enemies if not e.is_alive]
        alive = [e for e in self.enemies if e.is_alive]
        for enemy in dead:
            enemy.render(surface, self.camera)
        for enemy in alive:
            enemy.render(surface, self.camera)
        self._render_wave_eggs(surface)  # above bodies, below the squad
        self.elite_barrage.render(surface, self.camera)
        self.elite_bombs.render(surface, self.camera)
        self.iron_balls.render(surface, self.camera)
        self.enemy_missiles.render(surface, self.camera)
        self.boss_barrage.render(surface, self.camera)
        self.projectile_pool.render(surface, self.camera)
        for member in self.squad.members:
            member.render(surface, self.camera)
        self.player.render(surface, self.camera, self.melee)
        render_melee(surface, self.camera, self.melee, melee_preview)

    def _create_test_squad(self, member_count: int) -> None:
        """Create stage-four followers in initial queue order."""
        for index in range(member_count):
            distance = self.squad.follow_distance_for(index)
            row = index // 10
            column = index % 10
            member = SquadMember(
                position=self.player.position
                - pygame.Vector2(
                    min(distance, self.squad.follow_distance_for(column)),
                    -row * settings.SQUAD_MEMBER_SPACING,
                ),
                radius=settings.SQUAD_MEMBER_RADIUS,
                portrait_id=index % settings.SQUAD_PORTRAIT_COUNT,
            )
            member.avatar = self.squad_portraits.active_avatar(
                member.portrait_id,
                round(member.radius * 2),
            )
            self.squad.add_member(member)

    def _create_rescue_targets(self) -> list[RescueTarget]:
        """Create stationary stage-five friendlies at configured positions."""
        targets: list[RescueTarget] = []
        for index, position in enumerate(settings.RESCUE_TARGET_POSITIONS):
            portrait_id = index % settings.SQUAD_PORTRAIT_COUNT
            target = RescueTarget(
                position=pygame.Vector2(position),
                radius=settings.SQUAD_MEMBER_RADIUS,
                portrait_id=portrait_id,
            )
            diameter = round(target.radius * 2)
            target.avatar = self.squad_portraits.active_avatar(
                portrait_id,
                diameter,
            )
            target.neutral_avatar = self.squad_portraits.neutral_avatar(
                portrait_id,
                diameter,
            )
            targets.append(target)
        return targets

    def _create_weapon_pickups(self) -> list[WeaponPickup]:
        """Create configured one-time weapon pickups on the map."""
        return [
            WeaponPickup(kind, pygame.Vector2(x, y))
            for kind, x, y in settings.WEAPON_PICKUP_POSITIONS
        ]

    def _update_weapon_pickups(self) -> None:
        """Equip weapons when the protagonist touches rest-area stations."""
        for pickup in self.weapon_pickups:
            pickup.update(self.player)

    @property
    def secret_passage_position(self) -> pygame.Vector2:
        return pygame.Vector2(settings.SECRET_PASSAGE_POSITION)

    def _update_secret_passage(self) -> None:
        """Entering the hidden passage in the rest corner jumps to level 3."""
        if not self.dungeon_enabled or self.secret_passage_entered:
            return
        if self.level_number >= settings.SECRET_PASSAGE_TARGET_LEVEL:
            return
        if self.player.position.distance_to(
            self.secret_passage_position
        ) <= settings.SECRET_PASSAGE_RADIUS:
            self.secret_passage_entered = True

    def _render_secret_passage(self, surface: pygame.Surface) -> None:
        """Draw the passage only when the player is close (it is hidden)."""
        if not self.dungeon_enabled:
            return
        if self.level_number >= settings.SECRET_PASSAGE_TARGET_LEVEL:
            return
        distance = self.player.position.distance_to(self.secret_passage_position)
        if distance > settings.SECRET_PASSAGE_REVEAL_RANGE:
            return
        ratio = 1.0 - distance / settings.SECRET_PASSAGE_REVEAL_RANGE
        screen = self.camera.world_to_screen(self.secret_passage_position)
        center = (round(screen.x), round(screen.y))
        layer = pygame.Surface(surface.get_size(), pygame.SRCALPHA)
        alpha = int(60 + 150 * max(0.0, min(1.0, ratio)))
        pygame.draw.circle(
            layer, (*settings.SECRET_PASSAGE_COLOR, alpha),
            center, round(settings.SECRET_PASSAGE_RADIUS), 3,
        )
        pygame.draw.circle(
            layer, (*settings.SECRET_PASSAGE_COLOR, alpha // 3),
            center, round(settings.SECRET_PASSAGE_RADIUS * 0.55),
        )
        surface.blit(layer, (0, 0))

    def _update_dungeon_entrance(self) -> None:
        """Open combat when the player crosses the combat-area gate line."""
        if (
            self.dungeon_enabled
            and not self.combat_active
            and self.player.position.x >= settings.DUNGEON_GATE_X
        ):
            self.combat_active = True

    @property
    def combat_bounds(self) -> pygame.Rect:
        """Return the clamp rect that keeps combat actors inside the arena."""
        if not self.dungeon_enabled:
            return self.bounds
        wall = settings.DUNGEON_WALL_WIDTH
        return pygame.Rect(
            round(settings.DUNGEON_GATE_X + wall),
            round(wall),
            round(settings.WORLD_WIDTH - settings.DUNGEON_GATE_X - wall * 2),
            round(settings.WORLD_HEIGHT - wall * 2),
        )

    @property
    def wall_rects(self) -> tuple[pygame.Rect, ...]:
        """Return every dungeon wall rect (border, separator, corridor, gate).

        Bullets are stopped by these rects; the player is pushed out of them.
        The gate segment only exists while the combat gate is locked.
        """
        if not self.dungeon_enabled:
            return ()
        wall = round(settings.DUNGEON_WALL_WIDTH)
        top = round(settings.DUNGEON_CORRIDOR_TOP)
        bottom = round(settings.DUNGEON_CORRIDOR_BOTTOM)
        rest_right = round(settings.DUNGEON_REST_RIGHT)
        gate_x = round(settings.DUNGEON_GATE_X)
        width = round(settings.WORLD_WIDTH)
        height = round(settings.WORLD_HEIGHT)
        rects = [
            pygame.Rect(0, 0, width, wall),                    # top border
            pygame.Rect(0, height - wall, width, wall),        # bottom border
            pygame.Rect(0, 0, wall, height),                   # left border
            pygame.Rect(width - wall, 0, wall, height),        # right border
            pygame.Rect(rest_right, wall, wall, top - wall),   # rest wall upper
            pygame.Rect(                                    # rest wall lower
                rest_right, bottom, wall, height - bottom - wall
            ),
            pygame.Rect(                                    # corridor top band
                rest_right + wall, top - wall, gate_x - rest_right - wall, wall
            ),
            pygame.Rect(                                    # corridor bottom band
                rest_right + wall, bottom, gate_x - rest_right - wall, wall
            ),
            pygame.Rect(gate_x, wall, wall, top - wall),   # arena wall upper
            pygame.Rect(                                    # arena wall lower
                gate_x, bottom, wall, height - bottom - wall
            ),
        ]
        if self.gate_locked:
            rects.append(pygame.Rect(gate_x, top, wall, bottom - top))
        return tuple(rects)

    def _resolve_player_walls(self) -> None:
        """Push the player circle out of every wall rect it overlaps."""
        radius = self.player.radius
        position = self.player.position
        for rect in self.wall_rects:
            closest_x = min(max(position.x, rect.left), rect.right)
            closest_y = min(max(position.y, rect.top), rect.bottom)
            dx = position.x - closest_x
            dy = position.y - closest_y
            distance_sq = dx * dx + dy * dy
            if distance_sq > radius * radius:
                continue
            if distance_sq > 0.000001:
                distance = math.sqrt(distance_sq)
                position.x = closest_x + dx / distance * radius
                position.y = closest_y + dy / distance * radius
                continue
            # center is inside the wall: push out through the nearest edge
            edges = {
                "left": position.x - rect.left,
                "right": rect.right - position.x,
                "top": position.y - rect.top,
                "bottom": rect.bottom - position.y,
            }
            side = min(edges, key=edges.get)
            if side == "left":
                position.x = rect.left - radius
            elif side == "right":
                position.x = rect.right + radius
            elif side == "top":
                position.y = rect.top - radius
            else:
                position.y = rect.bottom + radius

    def switch_weapon(self) -> bool:
        """Toggle the active weapon between owned weapons; F key handler.

        The pistol is always owned; the sword must be picked up first.
        Returns True when the weapon actually changed.
        """
        player = self.player
        if player.weapon_kind == "pistol":
            if not player.has_sword:
                return False
            player.weapon_kind = "sword"
        else:
            player.weapon_kind = "pistol"
        return True

    def _create_enemies(self, enemy_count: int) -> list[Enemy]:
        """Create configured enemies or a deterministic stress-test grid."""
        positions = list(settings.ENEMY_PLACEHOLDER_POSITIONS[:enemy_count])
        index = len(positions)
        while len(positions) < enemy_count:
            # overflow grid stays inside the combat area (right of the gate)
            column = index % 4
            row = index // 4
            positions.append(
                (
                    settings.DUNGEON_GATE_X + 215.0 + column * 518.0,
                    240.0 + (row % 4) * 360.0,
                )
            )
            index += 1
        enemies: list[Enemy] = []
        for index, position in enumerate(positions):
            portrait_id = index % settings.ENEMY_PORTRAIT_COUNT
            enemy = Enemy(
                position=pygame.Vector2(position),
                radius=settings.ENEMY_RADIUS,
                portrait_id=portrait_id,
            )
            diameter = round(enemy.radius * 2)
            enemy.awake_avatar = self.enemy_portraits.awake_avatar(
                portrait_id,
                diameter,
            )
            enemy.defeated_avatar = self.enemy_portraits.defeated_avatar(
                portrait_id,
                diameter,
            )
            enemies.append(enemy)
        return enemies

    def _create_slimes(self) -> None:
        """Append red slime minions inside the combat area."""
        for index in range(settings.SLIME_COUNT_PER_LEVEL):
            position = settings.SLIME_POSITIONS[
                index % len(settings.SLIME_POSITIONS)
            ]
            self.enemies.append(
                SlimeEnemy(position=pygame.Vector2(position))
            )

    def _add_elite_enemies(self, count: int) -> None:
        """Append deterministic pure-color elite enemies for level two."""
        positions = (
            pygame.Vector2(1133.0, 586.0),
            pygame.Vector2(2134.0, 586.0),
            pygame.Vector2(1300.0, 250.0),
            pygame.Vector2(1300.0, 1342.0),
        )
        for index in range(count):
            self.enemies.append(
                EliteEnemy(position=positions[index % len(positions)].copy())
            )

    @property
    def elite_enemy_count(self) -> int:
        """Return the number of living elite enemies."""
        return sum(
            isinstance(enemy, EliteEnemy) and enemy.is_alive
            for enemy in self.enemies
        )

    @property
    def boss_health(self) -> tuple[int, int] | None:
        """Return current and maximum boss health when level three has a boss."""
        if self.boss is None:
            return None
        return (self.boss.health.current_health, self.boss.health.max_health)

    @property
    def remaining_enemy_count(self) -> int:
        """Return the number of living enemies."""
        return sum(enemy.is_alive for enemy in self.enemies)

    @property
    def gate_locked(self) -> bool:
        """Return whether the combat-area gate blocks retreat."""
        return (
            self.dungeon_enabled
            and self.combat_active
            and self.remaining_enemy_count > 0
        )

    @property
    def melee_enabled(self) -> bool:
        """Return whether the melee kit is armed by the protagonist's sword.

        Attack style is weapon-bound, not formation-bound: the player starts
        with a pistol (ranged) and melees only after picking up a sword.
        """
        return self.player.weapon_kind == "sword"

    def melee_status_line(self) -> str | None:
        """Return a HUD status string for the melee kit, or None when off."""
        if not self.melee_enabled:
            return None
        kit = self.melee
        parts: list[str] = []
        if kit.dashing:
            parts.append("DASHING")
        if kit.invincible > 0.0:
            parts.append("INVINCIBLE")
        if kit.attack == "melee" and kit.attack_phase is not None:
            label = "COMBO %d/%d" % (
                kit.combo_idx + 1, settings.MELEE_COMBO_COUNT
            )
            if kit.is_final_hit:
                label += " FINAL"
            if kit.combo_buffered:
                label += " [BUFFER]"
            parts.append(label)
        elif kit.attack == "dash_attack" and kit.attack_phase is not None:
            parts.append("DASH-ATK " + kit.attack_phase.upper())
        elif kit.dash_window > 0.0:
            parts.append("DASH-ATK OK")
        return " | ".join(parts) if parts else "READY"

    @property
    def victory_achieved(self) -> bool:
        """Evaluate the configured level objectives without changing state."""
        if getattr(self, "wave_mode", False):
            # survival level: only the three-minute timer ends the level
            return bool(self.wave_finished)
        enemies_complete = self.remaining_enemy_count == 0
        rescues_complete = (
            self.rescued_count >= settings.VICTORY_RESCUE_COUNT
        )
        required_results: list[bool] = []
        if settings.VICTORY_REQUIRE_ALL_ENEMIES:
            required_results.append(enemies_complete)
        if settings.VICTORY_REQUIRE_RESCUES:
            required_results.append(rescues_complete)
        return bool(required_results) and all(required_results)

    def _update_rescues(self) -> None:
        """Rescue nearby waiting friendlies and append them to the queue."""
        for target in self.rescue_targets:
            if target.try_rescue(
                self.player.position,
                player_alive=self.player.is_alive,
            ):
                if self.squad.add_member(target, self.path_history):
                    self.rescued_count += 1

    def _render_rescue_ranges(self, surface: pygame.Surface) -> None:
        """Draw waiting targets' rescue radii in debug mode."""
        for target in self.rescue_targets:
            if target.rescued:
                continue
            screen_position = self.camera.world_to_screen(target.position)
            pygame.draw.circle(
                surface,
                settings.RESCUE_MARKER_COLOR,
                (round(screen_position.x), round(screen_position.y)),
                round(target.rescue_radius),
                1,
            )

    def _render_dungeon(self, surface: pygame.Surface) -> None:
        """Draw every dungeon wall tiled with the Soul Knight wall tiles."""
        if not self.dungeon_enabled:
            return
        tile = assets.wall_tile(round(settings.DUNGEON_WALL_WIDTH))
        for rect in self.wall_rects:
            self._draw_tiled_rect(surface, rect, tile)
        if self.gate_locked:
            gate_rect = pygame.Rect(
                round(settings.DUNGEON_GATE_X),
                round(settings.DUNGEON_CORRIDOR_TOP),
                round(settings.DUNGEON_WALL_WIDTH),
                round(
                    settings.DUNGEON_CORRIDOR_BOTTOM
                    - settings.DUNGEON_CORRIDOR_TOP
                ),
            )
            screen_gate = self.camera.world_rect_to_screen(gate_rect)
            overlay = pygame.Surface(screen_gate.size, pygame.SRCALPHA)
            overlay.fill(settings.DUNGEON_GATE_LOCKED_COLOR + (150,))
            surface.blit(overlay, screen_gate)
            pygame.draw.rect(
                surface, settings.DUNGEON_WALL_EDGE_COLOR, screen_gate, 3
            )
        elif self.combat_active:
            for y0, y1 in (
                (settings.DUNGEON_CORRIDOR_TOP - settings.DUNGEON_WALL_WIDTH,
                 settings.DUNGEON_CORRIDOR_TOP),
                (settings.DUNGEON_CORRIDOR_BOTTOM,
                 settings.DUNGEON_CORRIDOR_BOTTOM + settings.DUNGEON_WALL_WIDTH),
            ):
                stub = pygame.Rect(
                    round(settings.DUNGEON_GATE_X),
                    round(y0),
                    round(settings.DUNGEON_WALL_WIDTH),
                    round(y1 - y0),
                )
                screen_stub = self.camera.world_rect_to_screen(stub)
                pygame.draw.rect(
                    surface, settings.DUNGEON_GATE_COLOR, screen_stub
                )

    def _draw_tiled_rect(
        self, surface: pygame.Surface, rect: pygame.Rect, tile
    ) -> None:
        """Fill a world-space rect by tiling one wall texture tile."""
        screen_rect = self.camera.world_rect_to_screen(rect)
        visible = screen_rect.clip(surface.get_rect())
        if visible.width <= 0 or visible.height <= 0:
            return
        if tile is None:
            pygame.draw.rect(surface, settings.DUNGEON_WALL_COLOR, visible)
            pygame.draw.rect(
                surface, settings.DUNGEON_WALL_EDGE_COLOR, visible, 2
            )
            return
        tile_w, tile_h = tile.get_size()
        start_x = screen_rect.x + (
            (visible.x - screen_rect.x) // tile_w
        ) * tile_w
        start_y = screen_rect.y + (
            (visible.y - screen_rect.y) // tile_h
        ) * tile_h
        y = start_y
        while y < visible.bottom:
            x = start_x
            while x < visible.right:
                surface.blit(tile, (x, y))
                x += tile_w
            y += tile_h

    def _render_path_history(self, surface: pygame.Surface) -> None:
        """Draw retained path samples after converting them to screen space."""
        screen_points = [
            self.camera.world_to_screen(position)
            for position in self.path_history.positions()
        ]
        if len(screen_points) >= 2:
            pygame.draw.lines(
                surface,
                settings.PATH_DEBUG_COLOR,
                False,
                screen_points,
                3,
            )
        for point in screen_points:
            pygame.draw.circle(
                surface,
                settings.PATH_DEBUG_POINT_COLOR,
                (round(point.x), round(point.y)),
                3,
            )
