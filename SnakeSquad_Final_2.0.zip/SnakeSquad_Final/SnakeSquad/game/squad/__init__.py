"""Squad formation and leader-path systems.

Public classes are imported directly from their defining modules so package
loading remains independent of entity initialization order.
"""
