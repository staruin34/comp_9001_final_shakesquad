"""Ordered formation definitions and diamond (wing) slot math."""

from dataclasses import dataclass
from enum import Enum
from math import atan2, cos, sin

import pygame

from game import settings


class FormationType(Enum):
    """Selectable squad formations in cycle order."""

    SNAKE = "SNAKE"
    WING = "WING"
    RESERVE = "RESERVE"


# The switch cycle follows this order; Q steps backward and E steps forward.
FORMATION_CYCLE: tuple[FormationType, ...] = (
    FormationType.SNAKE,
    FormationType.WING,
    FormationType.RESERVE,
)


@dataclass(frozen=True)
class FormationProfile:
    """Display and tuning values shared by every member of a formation."""

    display_name: str
    player_speed_multiplier: float


FORMATION_PROFILES: dict[FormationType, FormationProfile] = {
    # Formation 1 keeps the original snake path-following and adds the
    # +50% base move-speed bonus; member follow speed scales with it.
    FormationType.SNAKE: FormationProfile(
        "Snake", settings.FORMATION_SNAKE_SPEED_MULTIPLIER
    ),
    # Formation 2: sprint diamond without a speed bonus. The player is the
    # front tip aligned with the final movement direction; members fill the
    # diamond outline behind it, translate with the player, and rotate
    # around it at twice the base speed.
    FormationType.WING: FormationProfile("Wing", 1.0),
    # Formation 3 awaits its own design; it reuses snake movement for now.
    FormationType.RESERVE: FormationProfile(
        "Reserve", settings.FORMATION_SNAKE_SPEED_MULTIPLIER
    ),
}


def _from_angle(angle_radians: float, radius: float) -> pygame.Vector2:
    """Build a vector from one consistent angle convention."""
    return pygame.Vector2(
        cos(angle_radians) * radius,
        sin(angle_radians) * radius,
    )


def wing_local_offset(
    queue_index: int,
    spacing: float = settings.SQUAD_MEMBER_SPACING,
) -> pygame.Vector2:
    """Return the un-rotated diamond slot behind a leader facing +x.

    The player is the diamond's front tip. Members fill the diamond outline
    by ring (|dx| + |dy| = r), ordered by depth: the waist widens to the
    sides first and the tail closes behind, so with three members the squad
    forms a classic four-point diamond.
    """
    ring = 2
    positions: list[tuple[int, int]] = []
    while True:
        for depth in range(1, ring):
            side = ring - depth
            positions.append((side, depth))
            if side > 0:
                positions.append((-side, depth))
        positions.append((0, ring))
        if len(positions) > queue_index:
            break
        ring += 1
    side, depth = positions[queue_index]
    return pygame.Vector2(
        -depth * float(spacing),
        side * float(spacing),
    )


def wing_target_offset(
    forward: pygame.Vector2,
    queue_index: int,
    spacing: float = settings.SQUAD_MEMBER_SPACING,
) -> pygame.Vector2:
    """Return the local diamond slot rotated so the tip points along forward."""
    local = wing_local_offset(queue_index, spacing)
    combined = atan2(local.y, local.x) + atan2(forward.y, forward.x)
    return _from_angle(combined, local.length())


def wing_slot_position(
    player_position: pygame.Vector2,
    forward: pygame.Vector2,
    queue_index: int,
    spacing: float = settings.SQUAD_MEMBER_SPACING,
) -> pygame.Vector2:
    """Return the world slot for one member of the wing formation."""
    return pygame.Vector2(player_position) + wing_target_offset(
        forward, queue_index, spacing
    )
