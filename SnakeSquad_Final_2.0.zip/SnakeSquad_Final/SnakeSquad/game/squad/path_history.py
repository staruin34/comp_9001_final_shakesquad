"""Distance-sampled world-space history for snake-like followers."""

from collections import deque
from dataclasses import dataclass

import pygame


@dataclass(frozen=True)
class PathPoint:
    """A copied world position recorded along the leader's route."""

    position: pygame.Vector2


class PathHistory:
    """Store evenly spaced path points and query positions behind the leader."""

    def __init__(
        self,
        start_position: pygame.Vector2,
        record_spacing: float,
        max_points: int,
        max_length: float,
    ) -> None:
        if record_spacing <= 0.0:
            raise ValueError("record_spacing must be greater than zero")
        if max_points < 2:
            raise ValueError("max_points must be at least two")
        if max_length <= 0.0:
            raise ValueError("max_length must be greater than zero")

        self.record_spacing = float(record_spacing)
        self.max_points = int(max_points)
        self.max_length = float(max_length)
        self._points: deque[PathPoint] = deque(
            [PathPoint(pygame.Vector2(start_position))]
        )
        self._total_length = 0.0

    def record(self, position: pygame.Vector2) -> None:
        """Record enough interpolated points to cover movement to a position."""
        destination = pygame.Vector2(position)
        difference = destination - self._points[-1].position
        distance = difference.length()
        if distance < self.record_spacing:
            return

        direction = difference / distance
        while distance >= self.record_spacing:
            next_position = (
                self._points[-1].position
                + direction * self.record_spacing
            )
            self._append(next_position)
            difference = destination - self._points[-1].position
            distance = difference.length()
            if distance > 0.0:
                direction = difference / distance

        self._trim_old_points()

    def get_position_at_distance(
        self,
        distance_behind_leader: float,
    ) -> pygame.Vector2:
        """Interpolate a world position backward from the latest path point."""
        if distance_behind_leader <= 0.0:
            return self._points[-1].position.copy()

        remaining = float(distance_behind_leader)
        points = tuple(self._points)
        for index in range(len(points) - 1, 0, -1):
            newer = points[index].position
            older = points[index - 1].position
            segment_length = newer.distance_to(older)
            if segment_length <= 0.0:
                continue
            if remaining <= segment_length:
                return newer.lerp(older, remaining / segment_length)
            remaining -= segment_length

        return points[0].position.copy()

    @property
    def total_length(self) -> float:
        """Return the accumulated length of all retained segments."""
        return self._total_length

    @property
    def point_count(self) -> int:
        """Return the number of retained samples."""
        return len(self._points)

    def positions(self) -> tuple[pygame.Vector2, ...]:
        """Return copied positions for safe read-only iteration and drawing."""
        return tuple(point.position.copy() for point in self._points)

    def _append(self, position: pygame.Vector2) -> None:
        copied_position = pygame.Vector2(position)
        self._total_length += self._points[-1].position.distance_to(
            copied_position
        )
        self._points.append(PathPoint(copied_position))

    def _trim_old_points(self) -> None:
        while len(self._points) > self.max_points:
            self._remove_oldest_segment()
        while self._total_length > self.max_length and len(self._points) > 1:
            self._remove_oldest_segment()

    def _remove_oldest_segment(self) -> None:
        oldest = self._points.popleft()
        next_oldest = self._points[0]
        removed_length = oldest.position.distance_to(next_oldest.position)
        self._total_length = max(0.0, self._total_length - removed_length)
