"""Ordered squad ownership, formation cycling, and follower targets."""

import pygame

from game import settings
from game.entities.squad_member import SquadMember, SquadMemberState
from game.factions import Faction
from game.squad.formations import (
    FORMATION_CYCLE,
    FORMATION_PROFILES,
    FormationType,
    wing_target_offset,
)
from game.squad.path_history import PathHistory


class SquadManager:
    """Maintain member order and move followers by the active formation."""

    def __init__(
        self,
        first_member_distance: float = settings.SQUAD_FIRST_MEMBER_DISTANCE,
        member_spacing: float = settings.SQUAD_MEMBER_SPACING,
    ) -> None:
        self.first_member_distance = first_member_distance
        self.member_spacing = member_spacing
        self.members: list[SquadMember] = []
        self._pending_removals: set[int] = set()
        self.formation_index = 0
        self.formation_cooldown = 0.0
        self._wing_forward: pygame.Vector2 | None = None

    def add_member(
        self,
        member: SquadMember,
        path_history: PathHistory | None = None,
    ) -> bool:
        """Append a living member once and assign its queue index."""
        if member.state is SquadMemberState.DEAD:
            return False
        if any(existing is member for existing in self.members):
            return False

        member.state = SquadMemberState.FOLLOWING
        member.faction = Faction.PLAYER_SQUAD
        member.queue_index = len(self.members)
        self.members.append(member)
        if path_history is not None:
            follow_distance = self.follow_distance_for(member.queue_index)
            if path_history.total_length >= follow_distance:
                member.position = path_history.get_position_at_distance(
                    follow_distance
                )
        return True

    def mark_for_removal(self, member: SquadMember) -> None:
        """Queue a member for removal after iteration finishes."""
        if any(existing is member for existing in self.members):
            self._pending_removals.add(id(member))

    def flush_removals(self) -> None:
        """Remove queued or dead members and restore contiguous indices."""
        if self._pending_removals or any(
            member.state is SquadMemberState.DEAD for member in self.members
        ):
            self.members = [
                member
                for member in self.members
                if id(member) not in self._pending_removals
                and member.state is not SquadMemberState.DEAD
            ]
            self._pending_removals.clear()
            self._reindex()

    @property
    def formation_type(self) -> FormationType:
        """Return the currently selected formation."""
        return FORMATION_CYCLE[self.formation_index]

    @property
    def formation_count(self) -> int:
        """Return the number of formations in the switch cycle."""
        return len(FORMATION_CYCLE)

    @property
    def formation_name(self) -> str:
        """Return the display name of the current formation."""
        return FORMATION_PROFILES[self.formation_type].display_name

    @property
    def player_speed_multiplier(self) -> float:
        """Return the leader move-speed multiplier for this formation."""
        return FORMATION_PROFILES[self.formation_type].player_speed_multiplier

    @property
    def formation_cooldown_remaining(self) -> float:
        """Return the seconds remaining before the next switch is allowed."""
        return self.formation_cooldown

    def switch_formation(self, step: int) -> bool:
        """Cycle by +1 (next) or -1 (previous) when the cooldown permits."""
        if step == 0 or self.formation_cooldown > 0.0:
            return False
        self.formation_index = (
            self.formation_index + step
        ) % len(FORMATION_CYCLE)
        self.formation_cooldown = settings.FORMATION_SWITCH_COOLDOWN
        return True

    def update(
        self,
        delta_time: float,
        path_history: PathHistory,
        fallback_aim_direction: pygame.Vector2,
        player: object | None = None,
    ) -> None:
        """Tick the switch cooldown and move members by the active formation."""
        safe_delta = max(delta_time, 0.0)
        self.formation_cooldown = max(
            0.0, self.formation_cooldown - safe_delta
        )
        for member in tuple(self.members):
            if member.state is SquadMemberState.DEAD:
                self.mark_for_removal(member)

        if player is not None:
            velocity = getattr(player, "velocity", None)
            if velocity is not None and velocity.length_squared() > 0.000001:
                self._wing_forward = pygame.Vector2(velocity).normalize()

        if self.formation_type is FormationType.WING:
            self._update_wing(safe_delta, fallback_aim_direction, player)
        else:
            self._update_snake(
                safe_delta, path_history, fallback_aim_direction
            )

        self.flush_removals()

    def _update_snake(
        self,
        delta_time: float,
        path_history: PathHistory,
        fallback_aim_direction: pygame.Vector2,
    ) -> None:
        """Move each member to its own distance along the leader path."""
        for member in tuple(self.members):
            if member.state is SquadMemberState.DEAD:
                continue
            follow_distance = self.follow_distance_for(member.queue_index)
            if path_history.total_length < follow_distance:
                member.velocity.update(0.0, 0.0)
                continue
            target = path_history.get_position_at_distance(follow_distance)
            member.update_follow(
                target,
                delta_time,
                fallback_aim_direction,
                member.follow_speed * self.player_speed_multiplier,
            )

    def _update_wing(
        self,
        delta_time: float,
        fallback_aim_direction: pygame.Vector2,
        player: object | None,
    ) -> None:
        """Swing members into a movement-aligned diamond around the leader."""
        if player is None:
            return
        forward = self._resolve_wing_forward(player)
        player_position = pygame.Vector2(player.position)
        player_velocity = pygame.Vector2(
            getattr(player, "velocity", pygame.Vector2())
        )

        for member in tuple(self.members):
            if member.state is SquadMemberState.DEAD:
                continue
            target_offset = wing_target_offset(
                forward, member.queue_index, self.member_spacing
            )
            member.update_formation_slot(
                player_position,
                player_velocity,
                target_offset,
                delta_time,
                settings.FORMATION_WING_ROTATION_SPEED,
                fallback_aim_direction,
            )

    def _resolve_wing_forward(self, player: object) -> pygame.Vector2:
        """Return the last movement direction, falling back to the aim."""
        if self._wing_forward is not None:
            return pygame.Vector2(self._wing_forward)
        aim = pygame.Vector2(
            getattr(player, "aim_direction", pygame.Vector2(1.0, 0.0))
        )
        if aim.length_squared() > 0.000001:
            return aim.normalize()
        return pygame.Vector2(1.0, 0.0)

    def follow_distance_for(self, member_index: int) -> float:
        """Return the configured path distance for a queue position."""
        return self.first_member_distance + member_index * self.member_spacing

    @property
    def member_count(self) -> int:
        """Return the current number of active squad members."""
        return len(self.members)

    def _reindex(self) -> None:
        for index, member in enumerate(self.members):
            member.queue_index = index
