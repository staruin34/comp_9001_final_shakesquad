"""Application-level game states."""

from enum import Enum, auto


class GameState(Enum):
    """The mutually exclusive states of a running level."""

    CHARACTER_SELECT = auto()
    PLAYING = auto()
    VICTORY = auto()
    DEFEAT = auto()
    PAUSED = auto()
