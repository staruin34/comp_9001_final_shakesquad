"""Character selection screen: one colour-themed card per hero."""

from pathlib import Path

import pygame

from game import settings


class CharacterSelectScreen:
    """Two hero cards, each filled with its own avatar and colour theme.

    Cards show the hero avatar UI cropped to a circle, the idle body copy
    underneath and the hero name / hotkey in the accent colour.
    """

    CARD_WIDTH = 340
    CARD_HEIGHT = 430
    CARD_GAP = 70

    def __init__(self) -> None:
        if not pygame.font.get_init():
            pygame.font.init()
        self.project_root = Path(__file__).resolve().parents[2]
        self.entries = list(settings.PLAYER_CHARACTERS)
        self.avatars = [
            self._load_image(entry.avatar_image, entry.accent)
            for entry in self.entries
        ]
        self.portraits = self.avatars
        count = len(self.entries)
        total_width = self.CARD_WIDTH * count + self.CARD_GAP * (count - 1)
        start_x = (settings.SCREEN_WIDTH - total_width) // 2
        self.cards = [
            pygame.Rect(
                start_x + index * (self.CARD_WIDTH + self.CARD_GAP),
                150,
                self.CARD_WIDTH,
                self.CARD_HEIGHT,
            )
            for index in range(count)
        ]
        self.title_font = pygame.font.Font(None, 64)
        self.name_font = pygame.font.Font(None, 36)
        self.font = pygame.font.Font(None, 28)

    def _load_image(
        self, relative_path: str, accent: tuple[int, int, int]
    ) -> pygame.Surface:
        """Load one UI picture, falling back to a tinted placeholder."""
        try:
            image = pygame.image.load(str(self.project_root / relative_path))
            if pygame.display.get_surface() is not None:
                image = image.convert_alpha()
            return image
        except (pygame.error, OSError):
            placeholder = pygame.Surface((256, 256), pygame.SRCALPHA)
            placeholder.fill(accent)
            return placeholder

    def character_at_position(self, position: tuple[int, int]) -> int | None:
        """Return the zero-based card index under a mouse position."""
        for index, card in enumerate(self.cards):
            if card.collidepoint(position):
                return index
        return None

    @staticmethod
    def _circular(
        image: pygame.Surface,
        diameter: int,
        face_center: tuple[float, float] = (0.5, 0.5),
    ) -> pygame.Surface:
        """Crop a face-centred square into a filled circle."""
        width, height = image.get_size()
        side = max(8, min(int(min(width, height) * 0.9), min(width, height)))
        target_x = face_center[0] * width
        target_y = face_center[1] * height
        left = int(max(0, min(width - side, target_x - side / 2)))
        top = int(max(0, min(height - side, target_y - side / 2)))
        face = image.subsurface((left, top, side, side)).copy()
        scaled = pygame.transform.smoothscale(face, (diameter, diameter))
        portrait = pygame.Surface((diameter, diameter), pygame.SRCALPHA)
        portrait.blit(scaled, (0, 0))
        mask = pygame.Surface((diameter, diameter), pygame.SRCALPHA)
        mask.fill((255, 255, 255, 0))
        pygame.draw.circle(
            mask, (255, 255, 255, 255), (diameter // 2, diameter // 2), diameter // 2
        )
        portrait.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
        return portrait

    def battle_avatar(self, index: int, diameter: int) -> pygame.Surface:
        """Create a circular battle portrait for the selected character."""
        return self._circular(self.avatars[index], diameter)

    def render(self, surface: pygame.Surface) -> None:
        """Draw the selection menu and the colour-matched hero cards."""
        surface.fill(settings.BACKGROUND_COLOR)
        title = self.title_font.render(
            "SELECT YOUR HERO", True, settings.ACCENT_COLOR
        )
        surface.blit(title, title.get_rect(center=(surface.get_width() // 2, 70)))
        keys = " / ".join(str(i + 1) for i in range(len(self.cards)))
        prompt = self.font.render(
            "Click a portrait or press %s to deploy" % keys,
            True,
            settings.TEXT_COLOR,
        )
        surface.blit(prompt, prompt.get_rect(center=(surface.get_width() // 2, 115)))

        mouse_position = pygame.mouse.get_pos()
        for index, card in enumerate(self.cards):
            entry = self.entries[index]
            accent = entry.accent
            hovered = card.collidepoint(mouse_position)

            # colour-themed card body
            body = pygame.Surface(card.size, pygame.SRCALPHA)
            body.fill((*entry.panel, 235))
            surface.blit(body, card.topleft)
            border_width = 5 if hovered else 3
            border_color = accent if hovered else tuple(
                max(28, channel // 2) for channel in accent
            )
            pygame.draw.rect(surface, border_color, card, border_width, border_radius=16)

            # circular avatar UI (replaces the old static portrait picture)
            diameter = 240
            avatar = self._circular(
                self.avatars[index], diameter, entry.face_center
            )
            avatar_center = (card.centerx, card.y + 34 + diameter // 2)
            halo = pygame.Surface((diameter + 18, diameter + 18), pygame.SRCALPHA)
            pygame.draw.circle(
                halo, (*accent, 90),
                ((diameter + 18) // 2, (diameter + 18) // 2),
                (diameter + 18) // 2,
            )
            surface.blit(halo, halo.get_rect(center=avatar_center))
            surface.blit(avatar, avatar.get_rect(center=avatar_center))
            pygame.draw.circle(surface, accent, avatar_center, diameter // 2, 3)

            # name and hotkey in the hero accent colour
            # Trim excess whitespace from character names.
            label_text = entry.name.strip()  # never show stray whitespace
            name = self.name_font.render(label_text, True, accent)
            surface.blit(name, name.get_rect(center=(card.centerx, card.y + 340)))
            badge_center = (card.centerx, card.y + 374)
            pygame.draw.circle(surface, accent, badge_center, 14)
            key_label = self.font.render(str(index + 1), True, (16, 16, 16))
            surface.blit(key_label, key_label.get_rect(center=badge_center))
