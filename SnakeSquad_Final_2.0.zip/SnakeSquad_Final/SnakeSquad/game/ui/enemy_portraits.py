"""Matching awake and defeated portraits for enemy characters."""

from pathlib import Path

import pygame

from game import settings


class EnemyPortraitSet:
    """Extract adjacent awake/defeated pairs from the enemy sheet."""

    def __init__(self) -> None:
        project_root = Path(__file__).resolve().parents[2]
        sheet = pygame.image.load(str(project_root / settings.ENEMY_SERIES_IMAGE))
        self.awake_portraits, self.defeated_portraits = self._slice_pairs(sheet)

    @staticmethod
    def _slice_pairs(
        sheet: pygame.Surface,
    ) -> tuple[list[pygame.Surface], list[pygame.Surface]]:
        cell_size = sheet.get_width() // (settings.ENEMY_PORTRAIT_COUNT * 2)
        top_y = round(sheet.get_height() * 0.01)
        awake: list[pygame.Surface] = []
        defeated: list[pygame.Surface] = []
        for enemy_id in range(settings.ENEMY_PORTRAIT_COUNT):
            awake_x = enemy_id * cell_size * 2
            defeated_x = awake_x + cell_size
            awake.append(
                sheet.subsurface(
                    pygame.Rect(awake_x, top_y, cell_size, cell_size)
                ).copy()
            )
            defeated.append(
                sheet.subsurface(
                    pygame.Rect(defeated_x, top_y, cell_size, cell_size)
                ).copy()
            )
        return awake, defeated

    def awake_avatar(self, enemy_id: int, diameter: int) -> pygame.Surface:
        """Return the circular awake portrait for one enemy identity."""
        return self._circular_avatar(self.awake_portraits[enemy_id], diameter)

    def defeated_avatar(self, enemy_id: int, diameter: int) -> pygame.Surface:
        """Return the matching circular defeated portrait."""
        return self._circular_avatar(self.defeated_portraits[enemy_id], diameter)

    @staticmethod
    def _circular_avatar(source: pygame.Surface, diameter: int) -> pygame.Surface:
        scaled = pygame.transform.smoothscale(source, (diameter, diameter))
        avatar = pygame.Surface((diameter, diameter), pygame.SRCALPHA)
        avatar.blit(scaled, (0, 0))
        mask = pygame.Surface((diameter, diameter), pygame.SRCALPHA)
        mask.fill((255, 255, 255, 0))
        pygame.draw.circle(
            mask,
            (255, 255, 255, 255),
            (diameter // 2, diameter // 2),
            diameter // 2,
        )
        avatar.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
        return avatar
