"""Small world-entity health bar drawing helper."""

import pygame

from game import settings
from game.combat.health import Health


def draw_health_bar(
    surface: pygame.Surface,
    center: pygame.Vector2,
    health: Health,
    width: int,
    y_offset: float,
) -> None:
    """Draw a clamped health bar above a screen-space center point."""
    height = 6
    rect = pygame.Rect(0, 0, width, height)
    rect.midbottom = (round(center.x), round(center.y - y_offset))
    pygame.draw.rect(surface, settings.HEALTH_BAR_BACKGROUND, rect)
    fill = rect.copy()
    fill.width = round(rect.width * max(0.0, min(1.0, health.ratio)))
    if fill.width > 0:
        pygame.draw.rect(surface, settings.HEALTH_BAR_FOREGROUND, fill)
    pygame.draw.rect(surface, settings.HEALTH_BAR_OUTLINE, rect, 1)
