"""Heads-up display for game status and controls."""

import pygame

from game import assets, settings
from game.states import GameState


class HUD:
    """Render fixed screen-space information independently of the world."""

    def __init__(self) -> None:
        self.font = self._create_font(22)
        self.small_font = self._create_font(18)
        self.title_font = self._create_font(52, bold=True)

    @staticmethod
    def _create_font(size: int, bold: bool = False) -> pygame.font.Font:
        """Create a bundled Pygame font without querying system fonts."""
        font = pygame.font.Font(None, size)
        font.set_bold(bold)
        return font

    def render(
        self,
        surface: pygame.Surface,
        state: GameState,
        fps: float,
        player_position: pygame.Vector2,
        player_velocity: pygame.Vector2,
        camera_offset: pygame.Vector2,
        mouse_world_position: pygame.Vector2,
        path_point_count: int,
        path_length: float,
        debug_visible: bool,
        squad_count: int,
        rescued_count: int,
        waiting_count: int,
        enemy_count: int,
        active_projectiles: int,
        projectile_capacity: int,
        ink_reveal_count: int,
        enemy_attack_count: int,
        player_health: int,
        player_max_health: int,
        stress_test: bool,
        level_number: int,
        level_count: int,
        elite_enemy_count: int,
        elite_bullet_count: int,
        boss_name: str | None,
        boss_health: tuple[int, int] | None,
        boss_bullet_count: int,
        formation_index: int,
        formation_count: int,
        formation_name: str,
        formation_cooldown: float,
        formation_speed_multiplier: float,
        weapon_kind: str = "pistol",
        sword_owned: bool = False,
        melee_status: str | None = None,
        melee_dash_remaining: int | None = None,
        area_hint: str | None = None,
        player_shield: float = 0.0,
        show_params: bool = False,
        basket_eggs: int = 0,
    ) -> None:
        """Draw HUD data in screen coordinates."""
# Hide the parameter panel by default; reveal it with O.
        if show_params:
            panel = pygame.Surface((430, 620), pygame.SRCALPHA)
            panel.fill(settings.HUD_PANEL_COLOR)
            surface.blit(panel, (18, 18))

        lines = (
            (
                "SNAKE SQUAD // STRESS" if stress_test else "SNAKE SQUAD",
                self.font,
                settings.ACCENT_COLOR,
            ),
            (f"State: {state.name}", self.small_font, settings.TEXT_COLOR),
            (f"Level: {level_number} / {level_count}", self.small_font, settings.TEXT_COLOR),
            (
                f"Player health: {player_health} / {player_max_health}",
                self.small_font,
                settings.TEXT_COLOR,
            ),
            (f"FPS: {fps:5.1f}", self.small_font, settings.TEXT_COLOR),
            (
                f"Player world: ({player_position.x:.0f}, {player_position.y:.0f})",
                self.small_font,
                settings.TEXT_COLOR,
            ),
            (
                f"Velocity: ({player_velocity.x:.0f}, {player_velocity.y:.0f}) px/s",
                self.small_font,
                settings.TEXT_COLOR,
            ),
            (
                f"Camera offset: ({camera_offset.x:.0f}, {camera_offset.y:.0f})",
                self.small_font,
                settings.TEXT_COLOR,
            ),
            (
                f"Mouse world: ({mouse_world_position.x:.0f}, {mouse_world_position.y:.0f})",
                self.small_font,
                settings.TEXT_COLOR,
            ),
            (
                f"Path: {path_point_count} points / {path_length:.0f} px",
                self.small_font,
                settings.TEXT_COLOR,
            ),
            (
                f"Squad members: {squad_count}",
                self.small_font,
                settings.TEXT_COLOR,
            ),
            (
                f"Rescued: {rescued_count} / Waiting: {waiting_count}",
                self.small_font,
                settings.TEXT_COLOR,
            ),
            (
                f"Enemy targets: {enemy_count}",
                self.small_font,
                settings.TEXT_COLOR,
            ),
            (
                f"Elites: {elite_enemy_count} / Permanent barrage: {elite_bullet_count}",
                self.small_font,
                settings.TEXT_COLOR,
            ),
            (
                f"Projectiles: {active_projectiles} / Pool: {projectile_capacity}",
                self.small_font,
                settings.TEXT_COLOR,
            ),
            (
                f"Permanent ink reveals: {ink_reveal_count}",
                self.small_font,
                settings.TEXT_COLOR,
            ),
            (
                f"Enemy melee hits: {enemy_attack_count}",
                self.small_font,
                settings.TEXT_COLOR,
            ),
            (
                f"F1 debug path: {'ON' if debug_visible else 'OFF'}",
                self.small_font,
                settings.TEXT_COLOR,
            ),
            ("WASD: move   Mouse: aim", self.small_font, settings.TEXT_COLOR),
            ("Left mouse: fire / melee", self.small_font, settings.TEXT_COLOR),
            ("Space: dash   F: switch weapon", self.small_font, settings.TEXT_COLOR),
            ("Esc: pause   R: restart   F1: debug", self.small_font, settings.TEXT_COLOR),
        )

        if show_params:
            y = 31
            for text, font, color in lines:
                surface.blit(font.render(text, True, color), (32, y))
                y += 27

        self._render_weapon_panel(surface, weapon_kind, sword_owned)
# Persistent lower-left status: health, shield and dash meter.
        self._render_player_panel(
            surface,
            player_health,
            player_max_health,
            float(player_shield),
            melee_dash_remaining,
        )
        if boss_name is not None and boss_health is not None:
            self._render_boss_bar(
                surface,
                boss_name,
                boss_health[0],
                boss_health[1],
                boss_bullet_count,
            )

        if state is GameState.PAUSED:
            self._render_pause_overlay(surface)
        elif state in (GameState.VICTORY, GameState.DEFEAT):
            self._render_result_overlay(
                surface, state, level_number, level_count, basket_eggs
            )

    def _render_boss_bar(
        self,
        surface: pygame.Surface,
        boss_name: str,
        current_health: int,
        max_health: int,
        bullet_count: int,
    ) -> None:
        """Draw a fixed screen-space boss name and health bar at the bottom."""
        width = 680
        bar_rect = pygame.Rect(
            (surface.get_width() - width) // 2,
            surface.get_height() - 42,
            width,
            20,
        )
        label = self.font.render(
            f"{boss_name}   {current_health}/{max_health}   BULLETS {bullet_count}",
            True,
            settings.TEXT_COLOR,
        )
        surface.blit(label, label.get_rect(center=(surface.get_width() // 2, bar_rect.y - 15)))
        pygame.draw.rect(surface, settings.HEALTH_BAR_BACKGROUND, bar_rect)
        ratio = max(0.0, min(1.0, current_health / max_health))
        fill = bar_rect.copy()
        fill.width = round(bar_rect.width * ratio)
        pygame.draw.rect(surface, settings.BOSS_INNER_COLOR, fill)
        pygame.draw.rect(surface, settings.BOSS_OUTLINE_COLOR, bar_rect, 3)

    def _render_player_panel(
        self,
        surface: pygame.Surface,
        current_health: int,
        max_health: int,
        shield: float,
        dash_remaining: int | None,
    ) -> None:
        """Draw the protagonist status: HP value, shield value, dash bar."""
        panel_rect = pygame.Rect(
            18, settings.SCREEN_HEIGHT - 86 - 96, 232, 88
        )
        panel = pygame.Surface(panel_rect.size, pygame.SRCALPHA)
        panel.fill(settings.WEAPON_PANEL_COLOR)
        surface.blit(panel, panel_rect)

        title = self.small_font.render("PLAYER", True, settings.ACCENT_COLOR)
        surface.blit(title, (panel_rect.x + 12, panel_rect.y + 5))

        # first row: health value
        hp_text = self.small_font.render(
            "HP  %d / %d" % (int(current_health), int(max_health)),
            True,
            settings.TEXT_COLOR,
        )
        surface.blit(hp_text, (panel_rect.x + 12, panel_rect.y + 23))

        # second row: shield value
        shield_text = self.small_font.render(
            "SHIELD  %d / %d"
            % (round(shield), round(settings.PLAYER_SHIELD_MAX)),
            True,
            settings.PLAYER_SHIELD_COLOR,
        )
        surface.blit(shield_text, (panel_rect.x + 12, panel_rect.y + 43))

        # third row: dash bar
        dash_label = self.small_font.render(
            "DASH", True, settings.TEXT_COLOR
        )
        surface.blit(dash_label, (panel_rect.x + 12, panel_rect.y + 65))
        remaining = (
            settings.MELEE_MAX_DASH
            if dash_remaining is None
            else max(0, min(settings.MELEE_MAX_DASH, int(dash_remaining)))
        )
        segment_w, segment_h, gap = 26, 10, 6
        start_x = panel_rect.x + 72
        start_y = panel_rect.y + 67
        for index in range(settings.MELEE_MAX_DASH):
            segment = pygame.Rect(
                start_x + index * (segment_w + gap),
                start_y,
                segment_w,
                segment_h,
            )
            if index < remaining:
                pygame.draw.rect(surface, settings.ACCENT_COLOR, segment)
            pygame.draw.rect(
                surface, settings.WEAPON_BUTTON_COLOR, segment, 2
            )

    def _render_weapon_panel(
        self,
        surface: pygame.Surface,
        weapon_kind: str,
        sword_owned: bool,
    ) -> None:
        """Draw the weapon inventory with the switch-key annotation."""
        panel_rect = pygame.Rect(18, settings.SCREEN_HEIGHT - 86, 232, 68)
        panel = pygame.Surface(panel_rect.size, pygame.SRCALPHA)
        panel.fill(settings.WEAPON_PANEL_COLOR)
        surface.blit(panel, panel_rect)

        title = self.small_font.render(
            "WEAPON  [ " + settings.WEAPON_SWITCH_KEY_LABEL + " ] SWITCH",
            True,
            settings.ACCENT_COLOR,
        )
        surface.blit(title, (panel_rect.x + 12, panel_rect.y + 8))

        slots = [
            ("pistol", "weapon_pistol", True),
            ("sword", "weapon_sword", sword_owned),
        ]
        slot_size = 40
        for index, (kind, icon_key, owned) in enumerate(slots):
            slot_rect = pygame.Rect(
                panel_rect.x + 12 + index * (slot_size + 10),
                panel_rect.y + 26,
                slot_size,
                slot_size,
            )
            if kind == weapon_kind:
                pygame.draw.rect(
                    surface, settings.ACCENT_COLOR, slot_rect, 3
                )
            icon = assets.item(icon_key)
            if icon is None:
                icon = pygame.Surface((slot_size, slot_size), pygame.SRCALPHA)
                pygame.draw.circle(icon, (120, 120, 120), (20, 20), 14)
            else:
                icon = pygame.transform.scale(icon, (slot_size - 6, slot_size - 6))
            if not owned:
                icon = icon.copy()
                icon.set_alpha(60)
            surface.blit(
                icon,
                icon.get_rect(
                    center=(
                        slot_rect.centerx,
                        slot_rect.centery,
                    )
                ),
            )
            if not owned:
                lock = self.small_font.render("?", True, settings.TEXT_COLOR)
                surface.blit(lock, lock.get_rect(center=slot_rect.center))

        label = self.small_font.render(
            weapon_kind.upper(), True, settings.TEXT_COLOR
        )
        surface.blit(
            label,
            (panel_rect.x + 12 + 2 * (slot_size + 10) + 8, panel_rect.y + 38),
        )

    def _render_pause_overlay(self, surface: pygame.Surface) -> None:
        overlay = pygame.Surface(surface.get_size(), pygame.SRCALPHA)
        overlay.fill(settings.PAUSE_OVERLAY_COLOR)
        surface.blit(overlay, (0, 0))

        text = self.title_font.render("PAUSED", True, settings.TEXT_COLOR)
        prompt = self.font.render("Press Esc to continue", True, settings.ACCENT_COLOR)
        center_x = surface.get_width() // 2
        center_y = surface.get_height() // 2
        surface.blit(text, text.get_rect(center=(center_x, center_y - 22)))
        surface.blit(prompt, prompt.get_rect(center=(center_x, center_y + 38)))

    def _render_result_overlay(
        self,
        surface,
        state,
        level_number: int,
        level_count: int,
        basket_eggs: int = 0,
    ) -> None:
        """Result overlay; level four settles the fish-egg basket here."""
        self._render_result_text(
            surface, state, level_number, level_count, basket_eggs
        )

    def _render_result_text(
        self,
        surface: pygame.Surface,
        state: GameState,
        level_number: int,
        level_count: int,
        basket_eggs: int = 0,
    ) -> None:
        """Draw the terminal result while keeping restart input active."""
        victory = state is GameState.VICTORY
        overlay = pygame.Surface(surface.get_size(), pygame.SRCALPHA)
        overlay.fill(
            settings.VICTORY_OVERLAY_COLOR
            if victory
            else settings.DEFEAT_OVERLAY_COLOR
        )
        surface.blit(overlay, (0, 0))

        title = "VICTORY" if victory else "DEFEAT"
        color = (
            settings.VICTORY_TEXT_COLOR
            if victory
            else settings.DEFEAT_TEXT_COLOR
        )
        title_surface = self.title_font.render(title, True, color)
        prompt_text = (
            "Press N for the next level or R to restart"
            if victory and level_number < level_count
            else "Press R to restart the level"
        )
        prompt = self.font.render(
            prompt_text,
            True,
            settings.TEXT_COLOR,
        )
        center_x = surface.get_width() // 2
        center_y = surface.get_height() // 2
        surface.blit(
            title_surface,
            title_surface.get_rect(center=(center_x, center_y - 28)),
        )
        surface.blit(
            prompt,
            prompt.get_rect(center=(center_x, center_y + 38)),
        )
# Level-four result screen shows the cumulative number of eggs in the basket.
        if basket_eggs:
            # level-four item settlement: eggs stored in the counter basket
            panel = pygame.Rect(0, 0, 340, 76)
            panel.center = (center_x, center_y + 128)
            pygame.draw.rect(surface, settings.WEAPON_BUTTON_COLOR, panel)
            pygame.draw.rect(surface, (255, 214, 92), panel, 3)
            label = self.font.render(
                "FISH EGGS IN BASKET", True, settings.TEXT_COLOR
            )
            surface.blit(
                label, label.get_rect(center=(panel.centerx, panel.y + 22))
            )
            egg_sprite = assets.item("fish_egg")
            if egg_sprite is not None:
                surface.blit(
                    egg_sprite,
                    (panel.x + 22, panel.y + 40),
                )
            value = self.title_font.render(
                str(basket_eggs), True, (255, 214, 92)
            )
            surface.blit(
                value, value.get_rect(midleft=(panel.x + 96, panel.y + 52))
            )
