"""Visual layer for the wing-formation melee kit (camera-aware world space)."""

from math import atan2, cos, degrees, radians, sin, tan

import pygame

from game import assets, settings
from game.entities.player import weapon_orientation


def render_melee(surface, camera, kit, preview=False):
    """Draw hit effects: thrust slash, weapon ghost, sparks and dash fx.

    All attack range displays (parabola, dash-attack triangle) and the
    weapon sweep animation were removed. The preview flag is kept for API
    compatibility but no longer draws anything.
    """
    layer = pygame.Surface(surface.get_size(), pygame.SRCALPHA)
    _render_fx(layer, camera, kit)
    surface.blit(layer, (0, 0))


def _screen(camera, position):
    return camera.world_to_screen(position)


def _wedge(layer, camera, position, direction, radius, arc_deg, color, alpha):
    """Filled sector plus arc outline, shared by ranges and effects."""
    if radius <= 0 or alpha <= 0:
        return
    center = _screen(camera, position)
    base = atan2(direction.y, direction.x)
    half = radians(arc_deg / 2.0)
    points = [center]
    for i in range(25):
        a = base - half + 2 * half * i / 24
        points.append(center + pygame.Vector2(cos(a), sin(a)) * radius)
    pygame.draw.polygon(layer, (*color, int(alpha)), points)
    pygame.draw.lines(
        layer, (*color, min(255, int(alpha * 2))), False, points[1:], 3
    )


def _attack_shape(
    layer, camera, position, direction, arc_deg, radius_fn, color, alpha
):
    """Filled shape whose radius comes from radius_fn(offset angle in deg)."""
    if alpha <= 0:
        return
    center = _screen(camera, position)
    base = atan2(direction.y, direction.x)
    half = radians(arc_deg / 2.0)
    n = 25
    points = [center]
    for i in range(n + 1):
        a = base - half + 2 * half * i / n
        radius = max(1.0, radius_fn(degrees(a - base)))
        points.append(center + pygame.Vector2(cos(a), sin(a)) * radius)
    pygame.draw.polygon(layer, (*color, int(alpha)), points)
    pygame.draw.lines(
        layer, (*color, min(255, int(alpha * 2))), False, points[1:], 3
    )


def _render_weapon_ghost(layer, camera, fx):
    """Semi-transparent melee weapon afterimage for a slash effect.

    The ghost starts a third of the way into the thrust effect and fades
    out before the effect itself ends, so it always trails the slash.
    """
    duration = max(0.0001, fx["dur"])
    start = duration * 0.32
    end = duration * 0.74
    if fx["t"] < start or fx["t"] > end:
        return
    life = 1.0 - (fx["t"] - start) / max(0.0001, end - start)
    alpha = max(0, min(255, int(150 * life)))
    if alpha <= 0:
        return
    mid = _screen(camera, fx["pos"] + fx["dir"] * fx["range"] * 0.5)
    sword = assets.item_raw("weapon_sword")
    if sword is not None:
        length = max(10.0, fx["range"] * 0.9)
        width = max(8, int(length))
        height = max(8, int(length * sword.get_height() / sword.get_width()))
        ghost = pygame.transform.scale(sword, (width, height))
        flipped, angle = weapon_orientation(fx["dir"])
        ghost = pygame.transform.rotate(ghost, angle)
        if flipped:
            ghost = pygame.transform.flip(ghost, True, False)
        ghost.set_alpha(alpha)
        layer.blit(
            ghost,
            ghost.get_rect(center=(round(mid.x), round(mid.y))),
        )
        return
    # vector fallback: a translucent blade line along the thrust
    blade = pygame.Surface(layer.get_size(), pygame.SRCALPHA)
    root = _screen(camera, fx["pos"] + fx["dir"] * fx["range"] * 0.15)
    tip = _screen(camera, fx["pos"] + fx["dir"] * fx["range"] * 0.95)
    pygame.draw.line(
        blade, (*fx["color"], alpha), (root.x, root.y), (tip.x, tip.y), 5
    )
    layer.blit(blade, (0, 0))


def _render_fx(layer, camera, kit):
    """Swing fades, hit sparks, dash ghosts and smoke."""
    for fx in kit.fx:
        if fx["type"] == "slash":
            k = 1.0 - fx["t"] / fx["dur"]
            progress = 1.0 - k
            frame_index = min(2, int(progress * 3))
            sprite = assets.slash_frame(
                frame_index,
                fx["range"] * 1.6,
                gold=bool(fx.get("final")),
            )
            mid = _screen(
                camera, fx["pos"] + fx["dir"] * fx["range"] * 0.5
            )
            if sprite is not None:
                flipped, angle = weapon_orientation(fx["dir"])
                rotated = pygame.transform.rotate(sprite, angle)
                if flipped:
                    rotated = pygame.transform.flip(rotated, True, False)
                rotated.set_alpha(max(0, min(255, int(235 * k))))
                layer.blit(
                    rotated,
                    rotated.get_rect(
                        center=(round(mid.x), round(mid.y))
                    ),
                )
            elif fx.get("shape") == "parabola":
                half = fx["arc"] / 2.0
                curve = settings.MELEE_RANGE_CURVE

                def radius_fn(angle, half=half, curve=curve, fx=fx):
                    t = max(-1.0, min(1.0, angle / half))
                    return fx["range"] * (1.0 - curve * t * t)

                _attack_shape(
                    layer, camera, fx["pos"], fx["dir"], fx["arc"],
                    radius_fn, fx["color"], int(140 * k),
                )
            elif fx.get("shape") == "sector":
                _wedge(
                    layer, camera, fx["pos"], fx["dir"], fx["range"],
                    fx["arc"], fx["color"], int(140 * k),
                )
            else:
                _wedge(
                    layer, camera, fx["pos"], fx["dir"], fx["range"],
                    fx["arc"], fx["color"], int(140 * k),
                )
            # weapon afterimage: appears after the slash, gone before it ends
            _render_weapon_ghost(layer, camera, fx)
        elif fx["type"] == "spark":
            radius = max(1, int(fx["r"] * (1.0 - fx["t"] / fx["dur"])))
            center = _screen(camera, fx["pos"])
            pygame.draw.circle(
                layer, fx["color"],
                (int(center.x), int(center.y)), radius,
            )
        elif fx["type"] == "ghost":
            k = 1.0 - fx["t"] / fx["dur"]
            color = (
                int(60 + 170 * k),
                int(130 + 120 * k),
                int(190 + 65 * k),
            )
            center = _screen(camera, fx["pos"])
            pygame.draw.circle(
                layer, color,
                (int(center.x), int(center.y)), int(fx["radius"]), 2,
            )
        elif fx["type"] == "smoke":
            k = 1.0 - fx["t"] / fx["dur"]
            grow = 1.0 + (settings.MELEE_SMOKE_GROW - 1.0) * (1.0 - k)
            radius = max(1, int(fx["r"] * grow))
            gray = int(24 + 231 * k)
            center = _screen(camera, fx["pos"])
            pygame.draw.circle(
                layer, (gray, gray, gray),
                (int(center.x), int(center.y)), radius,
            )
