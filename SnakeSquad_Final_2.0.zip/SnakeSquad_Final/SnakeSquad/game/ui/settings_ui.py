"""Top-right settings panel with a draggable BGM volume slider."""

import pygame

from game import assets, settings
from game import audio


class SettingsUI:
    """Gear button in the top-right corner plus a Soul Knight style panel."""

    BUTTON_SIZE = 46
    PANEL_WIDTH = 318
    PANEL_HEIGHT = 148
    MARGIN = 18

    def __init__(self) -> None:
        self.visible = False
        self.dragging = False
        self.volume = audio.get_volume()
        width = settings.SCREEN_WIDTH
        self.button_rect = pygame.Rect(
            width - self.MARGIN - self.BUTTON_SIZE,
            self.MARGIN,
            self.BUTTON_SIZE,
            self.BUTTON_SIZE,
        )
        self.panel_rect = pygame.Rect(
            width - self.MARGIN - self.PANEL_WIDTH,
            self.button_rect.bottom + 8,
            self.PANEL_WIDTH,
            self.PANEL_HEIGHT,
        )
        # slider track sits inside the panel, below the title row
        self.track_rect = pygame.Rect(
            self.panel_rect.x + 26,
            self.panel_rect.y + 82,
            self.panel_rect.width - 52,
            14,
        )
        self.font = pygame.font.Font(None, 26)
        self.small = pygame.font.Font(None, 22)

    # ---------------- input ----------------
    def handle_event(self, event: pygame.event.Event) -> bool:
        """Consume mouse events for the button and slider; True if handled."""
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.button_rect.collidepoint(event.pos):
                self.visible = not self.visible
                return True
            if self.visible and self._slider_hit(event.pos):
                self.dragging = True
                self._apply_from_x(event.pos[0])
                return True
            if self.visible and self.panel_rect.collidepoint(event.pos):
                return True
            return False
        if event.type == pygame.MOUSEMOTION and self.dragging:
            self._apply_from_x(event.pos[0])
            return True
        if event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            if self.dragging:
                self.dragging = False
                return True
        return False

    def _slider_hit(self, pos) -> bool:
        """Generous hit box around the slider track (mouse friendly)."""
        return self.track_rect.inflate(0, 30).collidepoint(pos)

    def _apply_from_x(self, x: int) -> None:
        """Map a mouse x position to a 0..1 volume and apply it."""
        width = max(1, self.track_rect.width)
        ratio = (x - self.track_rect.x) / width
        self.volume = audio.set_volume(ratio)

    # ---------------- rendering ----------------
    def render(self, surface: pygame.Surface) -> None:
        """Draw the gear button and, when open, the volume panel."""
        self._render_button(surface)
        if self.visible:
            self._render_panel(surface)

    def _render_button(self, surface: pygame.Surface) -> None:
        hover = self.button_rect.collidepoint(pygame.mouse.get_pos())
        color = settings.WEAPON_BUTTON_SELECTED_COLOR if hover else settings.WEAPON_BUTTON_COLOR
        pygame.draw.rect(surface, color, self.button_rect, border_radius=10)
        pygame.draw.rect(surface, settings.ACCENT_COLOR, self.button_rect, 2, border_radius=10)
        # simple gear glyph: ring + four teeth
        center = self.button_rect.center
        pygame.draw.circle(surface, settings.ACCENT_COLOR, center, 10, 3)
        for dx, dy in ((0, -15), (0, 15), (-15, 0), (15, 0)):
            pygame.draw.line(
                surface, settings.ACCENT_COLOR, center,
                (center[0] + dx, center[1] + dy), 4,
            )

    def _render_panel(self, surface: pygame.Surface) -> None:
        panel = assets.item("settings_panel")
        if panel is not None:
            surface.blit(
                pygame.transform.smoothscale(
                    panel, (self.panel_rect.width, self.panel_rect.height)
                ),
                self.panel_rect.topleft,
            )
        else:
            pygame.draw.rect(
                surface, settings.WEAPON_BUTTON_COLOR, self.panel_rect,
                border_radius=12,
            )
        pygame.draw.rect(
            surface, settings.ACCENT_COLOR, self.panel_rect, 2, border_radius=12
        )
        title = self.font.render("SETTINGS", True, settings.ACCENT_COLOR)
        surface.blit(title, (self.panel_rect.x + 16, self.panel_rect.y + 12))
        label = self.small.render(
            "BGM Volume  %d%%" % round(self.volume * 100),
            True, settings.TEXT_COLOR,
        )
        surface.blit(label, (self.panel_rect.x + 16, self.panel_rect.y + 46))
        # slider: Soul Knight track + knob, with a filled portion behind it
        track = assets.item("slider_track")
        if track is not None:
            surface.blit(
                pygame.transform.smoothscale(
                    track, self.track_rect.size
                ),
                self.track_rect.topleft,
            )
        else:
            pygame.draw.rect(
                surface, (60, 70, 86), self.track_rect, border_radius=6
            )
        filled = self.track_rect.copy()
        filled.width = max(0, round(self.track_rect.width * self.volume))
        if filled.width > 2:
            fill_surface = pygame.Surface(filled.size, pygame.SRCALPHA)
            fill_surface.fill((*settings.ACCENT_COLOR, 120))
            surface.blit(fill_surface, filled.topleft)
        knob_x = self.track_rect.x + round(self.track_rect.width * self.volume)
        knob = assets.item("slider_knob")
        knob_rect = pygame.Rect(0, 0, 26, 26)
        knob_rect.center = (knob_x, self.track_rect.centery)
        if knob is not None:
            surface.blit(
                pygame.transform.smoothscale(knob, knob_rect.size),
                knob_rect.topleft,
            )
        else:
            pygame.draw.circle(
                surface, settings.ACCENT_COLOR, knob_rect.center, 9
            )
        hint = self.small.render(
            "Drag the slider to change music volume",
            True, (170, 178, 190),
        )
        surface.blit(hint, (self.panel_rect.x + 16, self.panel_rect.bottom - 26))
