"""Paired active and neutral portraits for squad characters."""

from pathlib import Path

import pygame

from game import settings


class SquadPortraitSet:
    """Extract matching upper/lower portrait pairs from a squad sheet."""

    def __init__(self) -> None:
        project_root = Path(__file__).resolve().parents[2]
        sheet = pygame.image.load(str(project_root / settings.SQUAD_SERIES_IMAGE))
        self.active_portraits, self.neutral_portraits = self._slice_pairs(sheet)

    @staticmethod
    def _slice_pairs(
        sheet: pygame.Surface,
    ) -> tuple[list[pygame.Surface], list[pygame.Surface]]:
        cell_size = sheet.get_width() // settings.SQUAD_PORTRAIT_COUNT
        top_y = round(sheet.get_height() * 0.067)
        bottom_y = round(sheet.get_height() * 0.45)
        active: list[pygame.Surface] = []
        neutral: list[pygame.Surface] = []
        for index in range(settings.SQUAD_PORTRAIT_COUNT):
            x = index * cell_size
            active.append(
                sheet.subsurface(pygame.Rect(x, top_y, cell_size, cell_size)).copy()
            )
            neutral.append(
                sheet.subsurface(pygame.Rect(x, bottom_y, cell_size, cell_size)).copy()
            )
        return active, neutral

    def active_avatar(self, portrait_id: int, diameter: int) -> pygame.Surface:
        """Return the upper-row circular portrait for an active member."""
        return self._circular_avatar(self.active_portraits[portrait_id], diameter)

    def neutral_avatar(self, portrait_id: int, diameter: int) -> pygame.Surface:
        """Return the matching lower-row portrait for a waiting member."""
        return self._circular_avatar(self.neutral_portraits[portrait_id], diameter)

    @staticmethod
    def _circular_avatar(source: pygame.Surface, diameter: int) -> pygame.Surface:
        avatar = pygame.transform.smoothscale(source, (diameter, diameter))
        if avatar.get_flags() & pygame.SRCALPHA == 0:
            converted = pygame.Surface((diameter, diameter), pygame.SRCALPHA)
            converted.blit(avatar, (0, 0))
            avatar = converted
        mask = pygame.Surface((diameter, diameter), pygame.SRCALPHA)
        mask.fill((255, 255, 255, 0))
        pygame.draw.circle(
            mask,
            (255, 255, 255, 255),
            (diameter // 2, diameter // 2),
            diameter // 2,
        )
        avatar.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
        return avatar
