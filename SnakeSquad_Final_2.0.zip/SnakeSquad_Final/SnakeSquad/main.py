# Run this file: python main.py (desktop Pygame GUI; see README.txt).
"""Snake Squad prototype entry point with startup diagnostics."""

from pathlib import Path
import sys
import traceback


def main() -> None:
    """Create and run the game application."""
    from game.game import Game

    Game(stress_test="--stress-test" in sys.argv[1:]).run()


def report_startup_error(error: BaseException) -> None:
    """Persist and display an unexpected startup error."""
    report = "".join(
        traceback.format_exception(type(error), error, error.__traceback__)
    )
    report_path = Path(__file__).with_name("crash_report.txt")

    try:
        report_path.write_text(report, encoding="utf-8")
    except OSError:
        pass

    print("Snake Squad failed to start.")
    print(report)
    print(f"Crash report: {report_path}")

    try:
        import tkinter.messagebox

        tkinter.messagebox.showerror(
            "Snake Squad - Startup Error",
            "The game could not start.\n\n"
            f"A diagnostic report was saved to:\n{report_path}\n\n"
            f"{type(error).__name__}: {error}",
        )
    except Exception:
        pass


if __name__ == "__main__":
    try:
        main()
    except BaseException as startup_error:
        report_startup_error(startup_error)
        raise SystemExit(1) from startup_error
